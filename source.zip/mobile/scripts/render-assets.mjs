import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import sharp from "sharp";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const assets = path.join(root, "assets");

async function render(source, target, size) {
  const svg = await readFile(path.join(assets, source));
  await sharp(svg).resize(size, size).png().toFile(path.join(assets, target));
}

await Promise.all([
  render("icon.svg", "icon.png", 1024),
  render("adaptive-icon.svg", "adaptive-icon.png", 1024),
  render("notification-icon.svg", "notification-icon.png", 96),
  render("splash-icon.svg", "splash-icon.png", 512),
  render("icon.svg", "favicon.png", 64),
]);
