param(
  [Parameter(Mandatory = $true)]
  [string]$BuildId,

  [Parameter(Mandatory = $true)]
  [string]$OutputDirectory,

  [string]$FilePrefix = "RezolvatAzi-Pro"
)

$ErrorActionPreference = "Stop"
$projectDirectory = Split-Path -Parent $PSScriptRoot
$logPath = Join-Path $OutputDirectory "eas-build-$BuildId.log"
$apkPath = Join-Path $OutputDirectory "$FilePrefix-$BuildId.apk"

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

while ($true) {
  try {
    $previousErrorPreference = $ErrorActionPreference
    $ErrorActionPreference = "SilentlyContinue"
    $raw = npx eas-cli@21.0.2 build:view $BuildId --json 2>$null | Out-String
    $cliExitCode = $LASTEXITCODE
    $ErrorActionPreference = $previousErrorPreference
    if ($cliExitCode -ne 0) {
      throw "EAS status command exited with code $cliExitCode."
    }
    $build = $raw | ConvertFrom-Json
    "$(Get-Date -Format o) $($build.status)" | Add-Content -LiteralPath $logPath

    if ($build.status -eq "FINISHED") {
      $artifactUrl = $build.artifacts.buildUrl
      if (-not $artifactUrl) {
        throw "Build finished without an APK URL."
      }

      if (-not (Test-Path -LiteralPath $apkPath)) {
        Invoke-WebRequest -Uri $artifactUrl -OutFile $apkPath -UseBasicParsing
      }

      "$(Get-Date -Format o) DOWNLOADED $apkPath" | Add-Content -LiteralPath $logPath
      exit 0
    }

    if ($build.status -in @("ERRORED", "CANCELED")) {
      "$(Get-Date -Format o) TERMINAL $($build.status)" | Add-Content -LiteralPath $logPath
      exit 1
    }
  }
  catch {
    "$(Get-Date -Format o) CHECK_FAILED $($_.Exception.Message)" | Add-Content -LiteralPath $logPath
  }

  Start-Sleep -Seconds 60
  Set-Location -LiteralPath $projectDirectory
}
