import { useEffect, useRef, useState } from "react";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import {
  getPlaceDetails,
  getPlaceSuggestions,
  type PlacePurpose,
  type PlaceSelection,
  type PlaceSuggestion,
} from "@/src/googlePlaces";
import { colors } from "@/src/theme";

type Props = {
  value: string;
  onChangeText: (text: string) => void;
  onSelectCoordinates?: (coords: { latitude: number; longitude: number }) => void;
  onSelectPlace?: (place: PlaceSelection) => void;
  purpose?: PlacePurpose;
  placeholder?: string;
};

export function CityAutocompleteInput({
  value,
  onChangeText,
  onSelectCoordinates,
  onSelectPlace,
  purpose = "area",
  placeholder = "Ex: București, Sector 3",
}: Props) {
  const [suggestions, setSuggestions] = useState<PlaceSuggestion[]>([]);
  const [focused, setFocused] = useState(false);
  const [loading, setLoading] = useState(false);
  const blurTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const canSuggest = focused && value.trim().length >= 2;

  useEffect(() => {
    let active = true;
    if (!canSuggest) return;

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const results = await getPlaceSuggestions(value, purpose);
        if (active) setSuggestions(results);
      } finally {
        if (active) setLoading(false);
      }
    }, 180);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [canSuggest, purpose, value]);

  useEffect(() => () => {
    if (blurTimer.current) clearTimeout(blurTimer.current);
  }, []);

  async function handleSelect(suggestion: PlaceSuggestion) {
    if (blurTimer.current) clearTimeout(blurTimer.current);
    const fallbackLabel = suggestion.description.replace(/,\s*România\s*$/i, "").trim();
    // Choosing a row must always close the menu. Details are useful for exact
    // coordinates, but an unavailable third-party place service must not make
    // the picker look frozen.
    setSuggestions([]);
    setFocused(false);
    const fallback: PlaceSelection = {
      fullLabel: fallbackLabel,
      areaLabel: fallbackLabel,
      latitude: null,
      longitude: null,
      placeId: suggestion.placeId,
    };
    // Reflect the user's choice before the optional detail lookup begins.
    onChangeText(purpose === "address" ? fallback.fullLabel : fallback.areaLabel);
    onSelectPlace?.(fallback);
    let details: PlaceSelection | null = null;
    try {
      details = suggestion.placeId ? await getPlaceDetails(suggestion.placeId) : null;
    } catch {
      details = null;
    }
    // The fallback has already updated the parent. Only replace it if we did
    // obtain more precise data.
    if (!details) return;
    const selected = details;
    onChangeText(purpose === "address" ? selected.fullLabel : selected.areaLabel);
    onSelectPlace?.(selected);
    if (selected.latitude !== null && selected.longitude !== null) {
      onSelectCoordinates?.({ latitude: selected.latitude, longitude: selected.longitude });
    }
  }

  return (
    <View style={styles.container}>
      <View style={[styles.inputWrap, focused && styles.inputFocused]}>
        <MaterialCommunityIcons name="map-marker-outline" size={18} color={focused ? colors.accent : colors.muted} style={{ marginRight: 8 }} />
        <TextInput
          value={value}
          onChangeText={onChangeText}
          onFocus={() => {
            if (blurTimer.current) clearTimeout(blurTimer.current);
            setFocused(true);
          }}
          onBlur={() => {
            blurTimer.current = setTimeout(() => {
              setFocused(false);
              setSuggestions([]);
            }, 180);
          }}
          placeholder={placeholder}
          placeholderTextColor="#99A19A"
          autoCorrect={false}
          style={styles.input}
        />
        {canSuggest && loading ? <MaterialCommunityIcons name="dots-horizontal" size={18} color={colors.muted} /> : null}
        {value.length > 0 ? (
          <Pressable accessibilityLabel="Șterge locația" onPress={() => { onChangeText(""); setSuggestions([]); }} style={{ padding: 4 }}>
            <MaterialCommunityIcons name="close-circle" size={16} color={colors.muted} />
          </Pressable>
        ) : null}
      </View>

      {canSuggest && suggestions.length > 0 ? (
        <ScrollView
          nestedScrollEnabled
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator
          style={styles.dropdown}
        >
          {suggestions.map((item) => (
              <Pressable
                accessibilityLabel={`Alege locația ${item.description}`}
                accessibilityRole="button"
                key={item.placeId ?? `custom:${item.description}`}
                style={({ pressed }) => [styles.suggestionRow, pressed && styles.suggestionPressed]}
                onPress={() => void handleSelect(item)}
              >
                <MaterialCommunityIcons name={item.isCustom ? "pencil-outline" : "map-marker-check"} size={16} color={colors.mintDark} />
                <View style={styles.suggestionCopy}>
                  <Text style={styles.suggestionText}>{item.description}</Text>
                  {item.isCustom ? <Text style={styles.customHint}>Folosește adresa scrisă și o verificăm înainte de publicare</Text> : null}
                </View>
              </Pressable>
            ))}
            {suggestions.some((suggestion) => suggestion.source === "google") ? (
              <View style={styles.googleAttribution}>
                <Text style={styles.attributionText}>powered by Google</Text>
              </View>
            ) : null}
        </ScrollView>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { zIndex: 90 },
  inputWrap: {
    minHeight: 52,
    backgroundColor: colors.paper,
    borderWidth: 1.5,
    borderColor: colors.line,
    borderRadius: 13,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 13,
  },
  inputFocused: { borderColor: colors.accent },
  input: { flex: 1, minHeight: 50, color: colors.text, fontSize: 14, paddingVertical: 10 },
  dropdown: {
    maxHeight: 260,
    marginTop: 6,
    backgroundColor: colors.paper,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.line,
    elevation: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 10,
    zIndex: 99,
    overflow: "hidden",
    boxShadow: "0px 6px 16px rgba(0,0,0,0.12)",
  },
  suggestionRow: {
    minHeight: 48,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#F0F2EF",
  },
  suggestionPressed: { backgroundColor: colors.cream },
  suggestionCopy: { flex: 1 },
  suggestionText: { color: colors.ink, fontSize: 13, fontWeight: "700" },
  customHint: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  googleAttribution: {
    alignItems: "flex-end",
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: "#F7F8F6",
  },
  attributionText: { color: colors.muted, fontSize: 11, fontWeight: "600" },
});
