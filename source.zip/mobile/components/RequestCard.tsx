import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import React from "react";
import { router } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { colors, shadow } from "@/src/theme";
import { ServiceRequest } from "@/src/types";
import { workOrderDetailChips } from "@/src/workOrderDetails";

function minutesRemaining(expiresAt: string) {
  const minutes = Math.max(0, Math.round((new Date(expiresAt).getTime() - Date.now()) / 60_000));
  return minutes > 180 ? `${Math.ceil(minutes / 60)}h` : `${minutes} min`;
}

export const RequestCard = React.memo(function RequestCard({ request, compact = false, onClose }: { request: ServiceRequest; compact?: boolean; onClose?: () => void }) {
  const urgent = request.urgency === "Acum";
  const solutionLabel = request.workOrder?.solutionKind === "team"
    ? "Echipă"
    : request.workOrder?.solutionKind === "hourly"
      ? "La oră"
      : request.workOrder?.solutionKind === "recurring"
        ? "Recurent"
        : request.workOrder?.solutionKind === "assessment"
          ? "Constatare"
          : request.workOrder
            ? "Oferte"
            : null;
  const detailChips = workOrderDetailChips(request.workOrder?.structuredDetailsJson);
  return (
    <Pressable
      accessibilityRole="button"
      accessible={true}
      accessibilityLabel={`Categorie: ${request.category}, Urgență: ${request.urgency}, Oraș: ${request.city}`}
      accessibilityHint="Apasă pentru detalii"
      onPress={() => router.push({
        pathname: "/request/[id]",
        params: {
          id: request.id,
          ...(request.matchedEarningProfileId ? { earningProfileId: request.matchedEarningProfileId } : {}),
        },
      })}
      style={({ pressed }) => [styles.card, compact && styles.compact, pressed && styles.pressed]}
    >
      <View style={styles.topRow}>
        <View style={[styles.urgency, urgent ? styles.urgent : styles.today]}>
          <View style={[styles.liveDot, urgent ? styles.urgentDot : styles.todayDot]} />
          <Text style={[styles.urgencyText, urgent ? styles.urgentText : styles.todayText]}>{urgent ? "Urgență: " : "Termen: "}{request.urgency}</Text>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <View style={styles.timer}>
            <MaterialCommunityIcons name="clock-outline" size={12} color={colors.muted} />
            <Text style={styles.timerText}>Valabil: {minutesRemaining(request.expiresAt)}</Text>
          </View>
          {onClose && (
            <Pressable onPress={(e) => { e.stopPropagation(); onClose(); }} hitSlop={15}>
              <MaterialCommunityIcons name="close-circle" size={24} color={colors.ink} />
            </Pressable>
          )}
        </View>
      </View>
      <Text style={styles.category}>{request.category}</Text>
      <Text style={styles.description} numberOfLines={compact ? 2 : 3}>{request.description}</Text>
      {request.workOrder ? (
        <View style={styles.intentRow}>
          {solutionLabel ? <Text style={styles.intentBadge}>{solutionLabel}</Text> : null}
          {request.workOrder.requiredParticipants > 1 ? <Text style={styles.intentBadge}>{request.workOrder.requiredParticipants} persoane</Text> : null}
          {request.workOrder.recurrenceLabel ? <Text style={styles.intentBadge}>{request.workOrder.recurrenceLabel}</Text> : null}
          {detailChips.map((detail) => <Text key={detail} style={styles.intentBadge}>{detail}</Text>)}
        </View>
      ) : null}
      {request.match && request.match.reasons.length ? (
        <View style={styles.matchBox}>
          <View style={styles.matchHeader}>
            <MaterialCommunityIcons name="target" size={15} color={colors.mintDark} />
            <Text style={styles.matchScore}>POTRIVIRE {request.match.score}%</Text>
          </View>
          {request.match.reasons.slice(0, 2).map((reason) => <Text key={reason} style={styles.matchReason}>✓ {reason}</Text>)}
          {request.match.cautions.slice(0, 1).map((caution) => <Text key={caution} style={styles.matchCaution}>! {caution}</Text>)}
          {request.match.publicHourlyRateLei && request.workOrder?.pricingModel === "hourly" ? (
            <Text style={styles.matchRate}>Tariful tău public: {request.match.publicHourlyRateLei} lei/oră</Text>
          ) : null}
        </View>
      ) : null}
      <View style={styles.footer}>
        <View style={styles.location}>
          <MaterialCommunityIcons name="map-marker-outline" size={16} color={colors.muted} />
          <Text style={styles.locationText} numberOfLines={1}>{request.distanceKm ? `${request.distanceKm} km · ` : ""}{request.city}</Text>
        </View>
        {(request.workOrder?.budgetBani || request.clientPrice) ? (
          <View style={[styles.budget, { flexShrink: 1 }]}>
            <MaterialCommunityIcons name="wallet-outline" size={15} color={colors.muted} />
            <Text style={styles.budgetText} numberOfLines={1}>{request.workOrder?.budgetBani ? request.workOrder.budgetBani / 100 : request.clientPrice} RON{request.workOrder?.pricingModel === "hourly" ? "/oră" : ""}</Text>
          </View>
        ) : null}
        <View style={styles.open}><Text style={styles.openText}>Detalii</Text><MaterialCommunityIcons name="arrow-right" size={16} color={colors.accent} /></View>
      </View>
    </Pressable>
  );
});

const styles = StyleSheet.create({
  card: { backgroundColor: colors.paper, borderRadius: 19, padding: 17, borderWidth: 1, borderColor: colors.line, marginBottom: 12, ...shadow },
  compact: { marginBottom: 0 },
  pressed: { transform: [{ scale: 0.99 }], opacity: 0.9 },
  topRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 },
  urgency: { flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, gap: 6 },
  urgent: { backgroundColor: colors.dangerSoft },
  today: { backgroundColor: "#FFF7E0" },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  urgentDot: { backgroundColor: colors.accentDark, shadowColor: colors.accent, shadowOpacity: 0.5, shadowRadius: 4, shadowOffset: { width: 0, height: 0 }, elevation: 4 },
  todayDot: { backgroundColor: "#A46D00" },
  urgencyText: { fontSize: 12, fontWeight: "900", letterSpacing: 0.4, textTransform: "uppercase" },
  urgentText: { color: colors.accentDark },
  todayText: { color: "#A46D00" },
  timer: { flexDirection: "row", alignItems: "center", gap: 4 },
  timerText: { color: colors.muted, fontSize: 12, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.4 },
  category: { color: colors.ink, fontSize: 17, fontWeight: "800", letterSpacing: -0.25, marginTop: 14 },
  description: { color: colors.muted, fontSize: 13, lineHeight: 19, marginTop: 6 },
  intentRow: { flexDirection: "row", flexWrap: "wrap", gap: 5, marginTop: 9 },
  intentBadge: { color: colors.mintDark, backgroundColor: colors.mint, borderRadius: 99, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 5, fontSize: 12, fontWeight: "800" },
  matchBox: { backgroundColor: "#F1FAF3", borderWidth: 1, borderColor: "#C7E1CE", borderRadius: 12, padding: 10, marginTop: 10 },
  matchHeader: { flexDirection: "row", alignItems: "center", gap: 5, marginBottom: 5 },
  matchScore: { color: colors.mintDark, fontSize: 12, fontWeight: "900", letterSpacing: 0.4 },
  matchReason: { color: colors.ink, fontSize: 12, lineHeight: 18, marginTop: 2 },
  matchCaution: { color: "#8A5A00", fontSize: 12, lineHeight: 18, marginTop: 3 },
  matchRate: { color: colors.mintDark, fontSize: 12, fontWeight: "800", marginTop: 5 },
  footer: { borderTopWidth: 1, borderTopColor: colors.line, marginTop: 14, paddingTop: 12, flexDirection: "row", alignItems: "center", gap: 10, flexWrap: "wrap" },
  location: { flexDirection: "row", alignItems: "center", gap: 3, flexShrink: 1 },
  locationText: { color: colors.muted, fontSize: 12, fontWeight: "600" },
  budget: { flexDirection: "row", alignItems: "center", gap: 3, flexShrink: 1 },
  budgetText: { color: colors.muted, fontSize: 12, fontWeight: "700" },
  open: { marginLeft: "auto", flexDirection: "row", alignItems: "center", gap: 4, flexShrink: 0 },
  openText: { color: colors.accent, fontSize: 12, fontWeight: "800" },
});
