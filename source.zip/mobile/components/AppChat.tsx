import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioPlayer,
  useAudioPlayerStatus,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import { useVideoPlayer, VideoView } from "expo-video";
import { useEffect, useMemo, useRef, useState } from "react";
import { AppState, FlatList, Image, Keyboard, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import {
  authenticatedChatMediaSource,
  deleteChatMessage,
  fetchChatMessages,
  reportChatParticipant,
  sendChatMessage,
  uploadChatAttachment,
} from "@/src/api";
import { useAuth } from "@/src/AuthContext";
import { triggerFeedback } from "@/src/feedback";
import { colors } from "@/src/theme";
import type { ChatMessage } from "@/src/types";
import {
  pickChatMediaFromGallery,
  recordChatVideo,
  takeChatPhoto,
  type PickedMediaAsset,
} from "@/src/mediaPicker";
import { showAppAlert } from "@/src/alerts";

type Props = {
  requestId: string;
  offerId?: string | null;
  userRole?: "client" | "neighbor" | "professional" | "hobby";
  title?: string;
  preAcceptance?: boolean;
  standalone?: boolean;
};

type LocalChatMessage = ChatMessage & { sendStatus?: "sending" | "failed" };
type FailedPayload = {
  content: string;
  asset: PickedMediaAsset | null;
  replyToMessageId?: string;
  clientNonce: string;
};

function mergeMessages(current: LocalChatMessage[], incoming: ChatMessage[]) {
  const byId = new Map(current.map((message) => [message.id, message]));
  for (const message of incoming) {
    const optimistic = current.find((item) => item.clientNonce && item.clientNonce === message.clientNonce);
    if (optimistic) byId.delete(optimistic.id);
    byId.set(message.id, message);
  }
  return [...byId.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

function formatDuration(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const minutes = Math.floor(seconds / 60);
  return `${minutes}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
}

function ChatAudioBubble({ url, isMe }: { url: string; isMe: boolean }) {
  const source = useMemo(() => authenticatedChatMediaSource(url), [url]);
  const player = useAudioPlayer(source, { updateInterval: 250, downloadFirst: true });
  const status = useAudioPlayerStatus(player);
  return (
    <Pressable
      onPress={(event) => {
        event.stopPropagation();
        if (status.playing) player.pause();
        else player.play();
      }}
      style={[styles.audioPlayer, isMe && styles.audioPlayerMe]}
    >
      <MaterialCommunityIcons name={status.playing ? "pause-circle" : "play-circle"} size={30} color={isMe ? colors.mintDark : colors.ink} />
      <View style={styles.audioWaveform}>
        {[8, 14, 20, 11, 17, 9, 15, 7].map((height, index) => <View key={index} style={[styles.audioBar, { height }, isMe && styles.audioBarMe]} />)}
      </View>
      <Text style={[styles.audioDuration, isMe && styles.audioDurationMe]}>{formatDuration(status.duration || status.currentTime)}</Text>
    </Pressable>
  );
}

function ChatVideoPlayer({ url }: { url: string }) {
  const source = useMemo(() => ({ ...authenticatedChatMediaSource(url), useCaching: true }), [url]);
  const player = useVideoPlayer(source);
  return <VideoView player={player} style={styles.fullVideo} nativeControls contentFit="contain" />;
}

export function AppChat({ requestId, offerId = null, userRole = "client", title, standalone = false }: Props) {
  const { provider } = useAuth();
  const [messages, setMessages] = useState<LocalChatMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [sending, setSending] = useState(false);
  const [attachedAssets, setAttachedAssets] = useState<PickedMediaAsset[]>([]);
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);
  const [previewVideoUrl, setPreviewVideoUrl] = useState<string | null>(null);
  const [replyingTo, setReplyingTo] = useState<ChatMessage | null>(null);
  const [failedPayloads, setFailedPayloads] = useState<Record<string, FailedPayload>>({});
  const [readOnlyReason, setReadOnlyReason] = useState<string | null>(null);
  const scrollRef = useRef<FlatList<LocalChatMessage>>(null);
  const wasRecording = useRef(false);
  const knownMessageIds = useRef(new Set<string>());
  const hasCompletedInitialChatSync = useRef(false);
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder, 150);
  const recorderUri = recorder.uri;

  function addAttachments(assets: PickedMediaAsset | PickedMediaAsset[]) {
    const incoming = Array.isArray(assets) ? assets : [assets];
    if (!incoming.length) return;
    setAttachedAssets((current) => [...current, ...incoming].slice(0, 6));
  }

  useEffect(() => {
    knownMessageIds.current.clear();
    hasCompletedInitialChatSync.current = false;
  }, [offerId, requestId]);

  useEffect(() => {
    if (wasRecording.current && !recorderState.isRecording && recorderUri) {
      void setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true }).catch(() => undefined);
      addAttachments({
        uri: recorderUri,
        name: `mesaj-vocal-${Date.now()}.m4a`,
        type: Platform.OS === "web" ? "audio/webm" : "audio/mp4",
        mediaType: "audio",
      });
    }
    wasRecording.current = recorderState.isRecording;
  }, [recorderState.isRecording, recorderUri]);

  useEffect(() => {
    let active = true;
    let running = false;
    let failures = 0;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const schedule = (delay: number) => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => void sync(), delay);
    };
    async function sync() {
      if (running || AppState.currentState !== "active") return;
      running = true;
      try {
        const data = await fetchChatMessages(requestId, offerId);
        failures = 0;
        if (active) {
          const hasInitialSnapshot = hasCompletedInitialChatSync.current;
          const receivedFromOtherPerson = data.messages.some((message) =>
            hasInitialSnapshot
            && !knownMessageIds.current.has(message.id)
            && message.senderId !== provider?.id,
          );
          data.messages.forEach((message) => knownMessageIds.current.add(message.id));
          setMessages((current) => mergeMessages(current, data.messages));
          setReadOnlyReason(data.readOnlyReason ?? null);
          hasCompletedInitialChatSync.current = true;
          // A message received while this screen is open is already visible.
          // Sound belongs to the operating system notification when the app
          // is in the background; a second in-app chime is distracting.
          void receivedFromOtherPerson;
        }
      } catch {
        // Păstrăm mesajele locale și reducem încercările pe rețele slabe.
        failures = Math.min(failures + 1, 4);
      } finally {
        running = false;
        if (active && AppState.currentState === "active") {
          schedule(failures ? 2_000 * 2 ** failures : 2_000);
        }
      }
    }
    void sync();
    const appStateSubscription = AppState.addEventListener("change", (state) => {
      if (state === "active") {
        failures = 0;
        if (timer) clearTimeout(timer);
        void sync();
      }
    });
    return () => {
      active = false;
      if (timer) clearTimeout(timer);
      appStateSubscription.remove();
    };
  }, [offerId, provider?.id, requestId]);

  // Pe iOS, keyboardWillShow apare înainte ca ecranul să fie redimensionat.
  // Dacă facem scroll atunci, ultimul mesaj ajunge din nou sub tastatură.
  // Așteptăm layoutul final (keyboardDidShow), apoi îl ducem la composer.
  useEffect(() => {
    const scrollAfterKeyboardLayout = () => {
      requestAnimationFrame(() => {
        setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 40);
      });
    };
    const shown = Keyboard.addListener("keyboardDidShow", scrollAfterKeyboardLayout);
    const frameChanged = Platform.OS === "ios"
      ? Keyboard.addListener("keyboardDidChangeFrame", scrollAfterKeyboardLayout)
      : null;
    return () => {
      shown.remove();
      frameChanged?.remove();
    };
  }, []);

  async function deliver(payload: FailedPayload, optimisticId: string, manageSending = true) {
    if (manageSending) setSending(true);
    try {
      const uploaded = payload.asset
        ? await uploadChatAttachment(requestId, offerId, payload.asset)
        : null;
      const message = await sendChatMessage({
        requestId,
        offerId,
        content: payload.content,
        attachmentId: uploaded?.id,
        replyToMessageId: payload.replyToMessageId,
        clientNonce: payload.clientNonce,
      });
      setMessages((current) => mergeMessages(current.filter((item) => item.id !== optimisticId), [message]));
      setFailedPayloads((current) => {
        const next = { ...current };
        delete next[optimisticId];
        return next;
      });
      triggerFeedback("success");
    } catch {
      setMessages((current) => current.map((message) => message.id === optimisticId ? { ...message, sendStatus: "failed" } : message));
      setFailedPayloads((current) => ({ ...current, [optimisticId]: payload }));
    } finally { if (manageSending) setSending(false); }
  }

  function retryMessage(messageId: string) {
    const payload = failedPayloads[messageId];
    if (payload) void deliver(payload, messageId);
  }

  async function handleSend() {
    if (!inputText.trim() && !attachedAssets.length) return;
    const content = inputText.trim();
    const assets = attachedAssets.length ? attachedAssets : [null];
    const batchId = `${provider?.id ?? "local"}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    const batch = assets.map((asset, index) => {
      const clientNonce = `${batchId}-${index}`;
      const payload: FailedPayload = {
        content: index === 0 ? content : "",
        asset,
        replyToMessageId: index === 0 ? replyingTo?.id : undefined,
        clientNonce,
      };
      const optimistic: LocalChatMessage = {
        id: `pending-${clientNonce}`,
        requestId,
        offerId,
        senderName: provider?.name ?? "Eu",
        senderRole: userRole,
        senderId: provider?.id,
        messageType: asset?.mediaType ?? "text",
        content: payload.content,
        photoUrl: asset?.mediaType === "image" ? asset.uri : undefined,
        videoUrl: asset?.mediaType === "video" ? asset.uri : undefined,
        audioUrl: asset?.mediaType === "audio" ? asset.uri : undefined,
        replyToMessageId: payload.replyToMessageId,
        replyToSenderName: index === 0 ? replyingTo?.senderName : undefined,
        replyToContent: index === 0 ? replyingTo?.content : undefined,
        clientNonce,
        sendStatus: "sending",
        createdAt: new Date().toISOString(),
      };
      return { payload, optimistic };
    });
    setMessages((current) => [...current, ...batch.map((item) => item.optimistic)]);
    setInputText("");
    setAttachedAssets([]);
    setReplyingTo(null);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 60);
    setSending(true);
    try {
      for (const item of batch) await deliver(item.payload, item.optimistic.id, false);
    } finally { setSending(false); }
  }

  async function takePhoto() {
    const asset = await takeChatPhoto();
    if (asset) addAttachments(asset);
  }

  async function recordVideo() {
    const asset = await recordChatVideo();
    if (asset) addAttachments(asset);
  }

  async function pickChatMedia() {
    addAttachments(await pickChatMediaFromGallery());
  }

  function chooseChatAttachments() {
    if (Platform.OS === "web") {
      void pickChatMedia();
      return;
    }
    const options = Platform.OS === "android"
      ? [
          { text: "Fotografii sau filmări", onPress: () => void pickChatMedia() },
          { text: "Fă o poză", onPress: () => void takePhoto() },
          { text: "Filmează", onPress: () => void recordVideo() },
        ]
      : [
          { text: "Renunță", style: "cancel" as const },
          { text: "Fotografii sau filmări", onPress: () => void pickChatMedia() },
          { text: "Fă o poză", onPress: () => void takePhoto() },
          { text: "Filmează", onPress: () => void recordVideo() },
        ];
    showAppAlert("Adaugă în conversație", "Alege până la 6 fotografii sau filmări odată, ori creează una acum.", options);
  }

  async function toggleRecording() {
    try {
      if (recorderState.isRecording) {
        await recorder.stop();
        return;
      }
      const permission = await requestRecordingPermissionsAsync();
      if (!permission.granted) {
        showAppAlert("Microfon indisponibil", "Permite accesul la microfon pentru a trimite un mesaj vocal.");
        return;
      }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record({ forDuration: 120 });
    } catch {
      showAppAlert("Înregistrare indisponibilă", "Mesajul vocal nu a putut fi pornit.");
    }
  }

  function confirmDeleteMessage(messageId: string) {
    showAppAlert("Ștergi mesajul?", "Mesajul va rămâne marcat ca șters pentru toți participanții.", [
      { text: "Renunță", style: "cancel" },
      {
        text: "Șterge mesajul",
        style: "destructive",
        onPress: async () => {
          await deleteChatMessage(messageId);
          setMessages((current) => current.map((message) => message.id === messageId ? {
            ...message,
            isDeleted: true,
            messageType: "deleted",
            content: "Acest mesaj a fost șters",
            photoUrl: undefined,
            videoUrl: undefined,
            audioUrl: undefined,
          } : message));
        },
      },
    ]);
  }

  function reportMessage(message: ChatMessage) {
    if (!message.senderId || message.senderId === provider?.id) return;
    const submit = async (block: boolean) => {
      try {
        await reportChatParticipant({
          requestId,
          offerId,
          targetProviderId: message.senderId!,
          block,
          details: `Raportare inițiată din mesajul ${message.id}.`,
        });
        showAppAlert(
          "Raportarea a fost trimisă",
          block ? "Contul a fost blocat și nu îți mai poate trimite mesaje." : "Echipa va verifica această conversație.",
        );
        if (block) setReadOnlyReason("Conversația este blocată. Istoricul rămâne vizibil.");
      } catch (caught) {
        showAppAlert("Raportarea nu a fost trimisă", caught instanceof Error ? caught.message : "Încearcă din nou.");
      }
    };
    showAppAlert("Raportezi acest mesaj?", "Echipa va primi legătura cu cererea și persoana care a trimis mesajul.", [
      { text: "Renunță", style: "cancel" },
      { text: "Doar raportează", onPress: () => void submit(false) },
      { text: "Raportează și blochează", style: "destructive", onPress: () => void submit(true) },
    ]);
  }

  return (
    <View style={[styles.card, standalone && styles.cardStandalone]}>
      {!standalone ? (
        <View style={styles.header}>
          <View style={styles.headerIcon}><MaterialCommunityIcons name={offerId ? "account-lock-outline" : "account-group-outline"} size={19} color={colors.mintDark} /></View>
          <View style={styles.headerCopy}><Text style={styles.headerTitle}>{title ?? (offerId ? "Discuție cu prestatorul" : "Discuția lucrării")}</Text></View>
        </View>
      ) : null}

      <Modal visible={Boolean(previewPhotoUrl)} transparent animationType="fade" onRequestClose={() => setPreviewPhotoUrl(null)}>
        <Pressable style={styles.modalOverlay} onPress={() => setPreviewPhotoUrl(null)}>
          <Pressable style={styles.modalCloseButton} onPress={() => setPreviewPhotoUrl(null)}><MaterialCommunityIcons name="close" size={26} color={colors.paper} /></Pressable>
          {previewPhotoUrl ? <Image source={authenticatedChatMediaSource(previewPhotoUrl)} style={styles.fullImage} resizeMode="contain" /> : null}
        </Pressable>
      </Modal>

      <Modal visible={Boolean(previewVideoUrl)} transparent animationType="fade" onRequestClose={() => setPreviewVideoUrl(null)}>
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalCloseButton} onPress={() => setPreviewVideoUrl(null)}><MaterialCommunityIcons name="close" size={26} color={colors.paper} /></Pressable>
          {previewVideoUrl ? <ChatVideoPlayer key={previewVideoUrl} url={previewVideoUrl} /> : null}
        </View>
      </Modal>

      <FlatList
        ref={scrollRef}
        style={[styles.messageList, standalone && styles.messageListStandalone]}
        contentContainerStyle={styles.messageListContent}
        automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
        keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
        keyboardShouldPersistTaps="handled"
        data={messages}
        keyExtractor={(message) => message.id}
        ListEmptyComponent={<Text style={styles.emptyText}>Conversația este goală. Poți trimite un mesaj, o fotografie, o filmare sau un mesaj vocal.</Text>}
        onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}
        renderItem={({ item: message }) => {
          const isMe = Boolean(provider?.id && message.senderId === provider.id) || message.id.startsWith("pending-");
          return (
            <View style={[styles.bubbleWrap, isMe ? styles.myWrap : styles.otherWrap]}>
              <View style={styles.bubbleHeader}>
                {!isMe ? <Text style={styles.senderLabel}>{message.senderName}</Text> : <View />}
                {!message.isDeleted && !message.sendStatus ? (
                  <View style={styles.bubbleActions}>
                    <Pressable onPress={() => setReplyingTo(message)} hitSlop={6}><MaterialCommunityIcons name="reply-outline" size={16} color={colors.muted} /></Pressable>
                    {isMe ? <Pressable onPress={() => confirmDeleteMessage(message.id)} hitSlop={6}><MaterialCommunityIcons name="trash-can-outline" size={15} color={colors.muted} /></Pressable> : null}
                    {!isMe && message.senderId ? <Pressable accessibilityLabel="Raportează mesajul" onPress={() => reportMessage(message)} hitSlop={6}><MaterialCommunityIcons name="shield-alert-outline" size={16} color={colors.accentDark} /></Pressable> : null}
                  </View>
                ) : null}
              </View>
              <Pressable disabled={Boolean(message.isDeleted)} onPress={() => setReplyingTo(message)} style={[styles.bubble, isMe ? styles.myBubble : styles.otherBubble, message.sendStatus === "failed" && styles.failedBubble]}>
                {message.isDeleted ? <Text style={styles.deletedText}>⊘ Acest mesaj a fost șters</Text> : (
                  <>
                    {message.replyToSenderName ? <View style={[styles.quoteBox, isMe && styles.quoteBoxMe]}><Text style={[styles.quoteSender, isMe && styles.myText]}>↩ {message.replyToSenderName}</Text><Text style={[styles.quoteText, isMe && styles.myText]} numberOfLines={1}>{message.replyToContent || "Atașament"}</Text></View> : null}
                    {message.photoUrl ? <Pressable onPress={() => setPreviewPhotoUrl(message.photoUrl!)}><Image source={message.id.startsWith("pending-") ? { uri: message.photoUrl } : authenticatedChatMediaSource(message.photoUrl)} style={styles.chatImage} resizeMode="cover" /></Pressable> : null}
                    {message.videoUrl ? <Pressable onPress={() => setPreviewVideoUrl(message.videoUrl!)} style={styles.videoCard}><MaterialCommunityIcons name="play-circle" size={44} color={colors.paper} /><Text style={styles.videoHint}>Redă filmarea</Text></Pressable> : null}
                    {message.audioUrl ? <ChatAudioBubble url={message.audioUrl} isMe={isMe} /> : null}
                    {message.content ? <Text style={[styles.bubbleText, isMe && styles.myText]}>{message.content}</Text> : null}
                    <View style={styles.deliveryRow}>
                      {message.sendStatus === "sending" ? <><MaterialCommunityIcons name="clock-outline" size={12} color={isMe ? colors.mintDark : colors.muted} /><Text style={[styles.deliveryText, isMe && styles.deliveryTextMe]}>Se trimite…</Text></> : null}
                      {message.sendStatus === "failed" ? <Pressable onPress={() => retryMessage(message.id)} style={styles.retryButton}><MaterialCommunityIcons name="alert-circle-outline" size={13} color={colors.accentDark} /><Text style={styles.retryText}>Nu s-a trimis · Reîncearcă</Text></Pressable> : null}
                      {!message.sendStatus && isMe ? <MaterialCommunityIcons name={(message.readByCount ?? 0) > 0 ? "check-all" : "check"} size={14} color={colors.mintDark} /> : null}
                    </View>
                  </>
                )}
              </Pressable>
            </View>
          );
        }}
      />

      {attachedAssets.length ? (
        <View style={styles.attachmentPreview}>
          <View style={styles.attachmentList}>
            {attachedAssets.map((asset, index) => (
              <View key={`${asset.uri}-${index}`} style={styles.attachmentItem}>
                {asset.mediaType === "image" ? <Image source={{ uri: asset.uri }} style={styles.attachmentImage} /> : <MaterialCommunityIcons name={asset.mediaType === "video" ? "video-outline" : "microphone-outline"} size={22} color={colors.accentDark} />}
                <Pressable accessibilityLabel={`Elimină atașamentul ${index + 1}`} onPress={() => setAttachedAssets((current) => current.filter((_, itemIndex) => itemIndex !== index))} style={styles.attachmentRemove}><MaterialCommunityIcons name="close" size={13} color={colors.paper} /></Pressable>
              </View>
            ))}
          </View>
          <View style={styles.attachmentCopy}><Text style={styles.attachmentTitle}>{attachedAssets.length === 1 ? "Atașament pregătit" : `${attachedAssets.length} atașamente pregătite`}</Text><Text style={styles.attachmentText} numberOfLines={1}>{attachedAssets.map((asset) => asset.mediaType === "image" ? "foto" : asset.mediaType === "video" ? "video" : "vocal").join(" · ")}</Text></View>
          <Pressable accessibilityLabel="Elimină toate atașamentele" onPress={() => setAttachedAssets([])}><MaterialCommunityIcons name="close-circle" size={21} color={colors.muted} /></Pressable>
        </View>
      ) : null}

      {replyingTo ? (
        <View style={styles.replyBanner}>
          <MaterialCommunityIcons name="reply" size={16} color={colors.accent} />
          <View style={styles.replyCopy}><Text style={styles.replyTitle}>Răspunzi lui {replyingTo.senderName}</Text><Text style={styles.replyText} numberOfLines={1}>{replyingTo.content || "Atașament"}</Text></View>
          <Pressable onPress={() => setReplyingTo(null)}><MaterialCommunityIcons name="close-circle" size={18} color={colors.muted} /></Pressable>
        </View>
      ) : null}

      {recorderState.isRecording ? <View style={styles.recordingBanner}><View style={styles.recordingDot} /><Text style={styles.recordingText}>Se înregistrează · {formatDuration(recorderState.durationMillis / 1000)}</Text><Text style={styles.recordingHint}>maximum 2 minute</Text></View> : null}

      {readOnlyReason ? <View style={styles.readOnlyBanner}><MaterialCommunityIcons name="lock-outline" size={17} color={colors.muted} /><Text style={styles.readOnlyText}>{readOnlyReason}</Text></View> : <View style={styles.inputRow}>
        <Pressable accessibilityLabel="Adaugă fotografii sau filmări" onPress={chooseChatAttachments} style={styles.iconButton}><MaterialCommunityIcons name="plus" size={24} color={colors.ink} /></Pressable>
        <TextInput accessibilityLabel="Mesaj" value={inputText} onFocus={() => requestAnimationFrame(() => scrollRef.current?.scrollToEnd({ animated: true }))} onChangeText={setInputText} placeholder="Scrie un mesaj…" placeholderTextColor="#667269" multiline style={styles.textInput} />
        {!inputText.trim() && !attachedAssets.length ? (
          <Pressable accessibilityLabel={recorderState.isRecording ? "Oprește înregistrarea" : "Înregistrează mesaj vocal"} onPress={() => void toggleRecording()} style={[styles.voiceButton, recorderState.isRecording && styles.voiceButtonRecording]}><MaterialCommunityIcons name={recorderState.isRecording ? "stop" : "microphone"} size={20} color={colors.paper} /></Pressable>
        ) : (
          <Pressable accessibilityLabel="Trimite mesaj" disabled={sending} onPress={() => void handleSend()} style={[styles.sendButton, sending && { opacity: 0.6 }]}><MaterialCommunityIcons name="send" size={18} color={colors.paper} /></Pressable>
        )}
      </View>}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { minHeight: 430, backgroundColor: colors.paper, borderRadius: 20, borderWidth: 1, borderColor: colors.line, padding: 12, marginVertical: 12 },
  cardStandalone: { minHeight: 0, flex: 1, borderWidth: 0, borderRadius: 0, marginVertical: 0 },
  header: { flexDirection: "row", alignItems: "center", gap: 9, borderBottomWidth: 1, borderBottomColor: colors.line, paddingBottom: 10, marginBottom: 8 },
  headerIcon: { width: 36, height: 36, borderRadius: 11, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  headerCopy: { flex: 1 },
  headerTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" },
  messageList: { minHeight: 250, maxHeight: 430 },
  messageListStandalone: { minHeight: 0, maxHeight: undefined, flex: 1 },
  messageListContent: { gap: 9, paddingVertical: 5 },
  emptyText: { color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: "center", paddingHorizontal: 25, marginVertical: 28 },
  bubbleWrap: { maxWidth: "86%" },
  myWrap: { alignSelf: "flex-end" },
  otherWrap: { alignSelf: "flex-start" },
  bubbleHeader: { minHeight: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginHorizontal: 4 },
  senderLabel: { color: colors.muted, fontSize: 12, fontWeight: "800" },
  bubbleActions: { flexDirection: "row", alignItems: "center", gap: 10 },
  bubble: { borderRadius: 15, paddingHorizontal: 11, paddingVertical: 8 },
  myBubble: { backgroundColor: "#E8F5ED", borderWidth: 1, borderColor: "#B8DEC5" },
  otherBubble: { backgroundColor: "#F0F2EF", borderWidth: 1, borderColor: colors.line },
  failedBubble: { borderWidth: 1, borderColor: colors.accentDark },
  bubbleText: { color: colors.ink, fontSize: 13, lineHeight: 18 },
  myText: { color: colors.ink },
  deletedText: { color: "#26382C", fontSize: 13, lineHeight: 18, fontStyle: "italic", fontWeight: "800" },
  quoteBox: { backgroundColor: "rgba(0,0,0,.06)", borderLeftWidth: 3, borderLeftColor: colors.accent, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 7, marginBottom: 6 },
  quoteBoxMe: { backgroundColor: "#D6EEDE", borderLeftColor: colors.mintDark },
  quoteSender: { color: colors.ink, fontSize: 12, fontWeight: "900" },
  quoteText: { color: colors.text, fontSize: 12, marginTop: 1 },
  chatImage: { width: 185, height: 138, borderRadius: 10, marginBottom: 5 },
  videoCard: { width: 185, height: 118, borderRadius: 10, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center", marginBottom: 5 },
  videoHint: { color: colors.paper, fontSize: 12, fontWeight: "800", marginTop: 3 },
  audioPlayer: { minWidth: 190, flexDirection: "row", alignItems: "center", gap: 7, paddingVertical: 2 },
  audioPlayerMe: { backgroundColor: "#DDF2E5" },
  audioWaveform: { flex: 1, flexDirection: "row", alignItems: "center", gap: 3 },
  audioBar: { width: 3, borderRadius: 2, backgroundColor: colors.ink },
  audioBarMe: { backgroundColor: colors.mintDark },
  audioDuration: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  audioDurationMe: { color: colors.ink },
  deliveryRow: { minHeight: 14, flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 3, marginTop: 3 },
  deliveryText: { color: colors.muted, fontSize: 12 },
  deliveryTextMe: { color: colors.mintDark },
  retryButton: { flexDirection: "row", alignItems: "center", gap: 3, backgroundColor: colors.paper, borderRadius: 8, paddingHorizontal: 6, paddingVertical: 3 },
  retryText: { color: colors.accentDark, fontSize: 12, fontWeight: "900" },
  readOnlyBanner: { minHeight: 50, flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.cream, borderRadius: 12, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 12 },
  readOnlyText: { flex: 1, color: colors.muted, fontSize: 12, lineHeight: 18, fontWeight: "700" },
  attachmentPreview: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.cream, borderRadius: 11, padding: 8, marginBottom: 7 },
  attachmentList: { flexDirection: "row", gap: 5, maxWidth: 145 },
  attachmentItem: { width: 38, height: 42, borderRadius: 7, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center", overflow: "visible" },
  attachmentImage: { width: 38, height: 42, borderRadius: 7 },
  attachmentRemove: { position: "absolute", right: -5, top: -5, width: 17, height: 17, borderRadius: 9, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center" },
  attachmentCopy: { flex: 1 },
  attachmentTitle: { color: colors.ink, fontSize: 12, fontWeight: "900" },
  attachmentText: { color: colors.muted, fontSize: 12, marginTop: 2 },
  replyBanner: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.cream, borderLeftWidth: 3, borderLeftColor: colors.accent, borderRadius: 9, padding: 8, marginBottom: 7 },
  replyCopy: { flex: 1 },
  replyTitle: { color: colors.ink, fontSize: 12, fontWeight: "900" },
  replyText: { color: colors.muted, fontSize: 12, marginTop: 2 },
  recordingBanner: { minHeight: 35, flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: colors.dangerSoft, borderRadius: 10, paddingHorizontal: 10, marginBottom: 7 },
  recordingDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.accent },
  recordingText: { color: colors.accentDark, fontSize: 12, fontWeight: "900" },
  recordingHint: { color: colors.muted, fontSize: 12, marginLeft: "auto" },
  inputRow: { flexDirection: "row", alignItems: "flex-end", gap: 6 },
  iconButton: { width: 44, height: 44, borderRadius: 13, backgroundColor: "#F0F2EF", alignItems: "center", justifyContent: "center" },
  textInput: { flex: 1, maxHeight: 95, minHeight: 44, backgroundColor: "#FAFAF7", borderWidth: 1, borderColor: colors.line, borderRadius: 12, paddingHorizontal: 11, paddingVertical: 10, fontSize: 15, color: colors.ink },
  sendButton: { width: 44, height: 44, borderRadius: 13, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
  voiceButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
  voiceButtonRecording: { backgroundColor: colors.accentDark },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,.92)", alignItems: "center", justifyContent: "center" },
  modalCloseButton: { position: "absolute", top: 48, right: 18, zIndex: 3, width: 42, height: 42, borderRadius: 21, backgroundColor: "rgba(0,0,0,.55)", alignItems: "center", justifyContent: "center" },
  fullImage: { width: "94%", height: "82%" },
  fullVideo: { width: "94%", height: "78%" },
});
