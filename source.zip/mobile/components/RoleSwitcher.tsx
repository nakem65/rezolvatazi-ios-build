import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useMode } from "@/src/ModeContext";
import { colors } from "@/src/theme";
import { AppMode } from "@/src/types";

const modes: Array<{ id: AppMode; label: string; caption: string; icon: React.ComponentProps<typeof MaterialCommunityIcons>["name"] }> = [
  { id: "client", label: "Am nevoie", caption: "Public o lucrare", icon: "clipboard-text-outline" },
  { id: "professional", label: "Vreau lucrări", caption: "Primesc oportunități", icon: "briefcase-outline" },
];

export function RoleSwitcher() {
  const { activeMode, setActiveMode } = useMode();

  return (
    <View style={styles.shell}>
      <Text style={styles.prompt}>CE VREI SĂ FACI?</Text>
      <View style={styles.wrapper} accessibilityRole="tablist">
        {modes.map((mode) => {
          const active = mode.id === activeMode;
          return (
            <Pressable
              key={mode.id}
              accessibilityRole="tab"
              accessibilityState={{ selected: active }}
              onPress={() => setActiveMode(mode.id)}
              style={({ pressed }) => [styles.item, active && styles.itemActive, pressed && styles.pressed]}
            >
              <View style={[styles.icon, active && styles.iconActive]}>
                <MaterialCommunityIcons name={mode.icon} size={17} color={active ? colors.ink : colors.muted} />
              </View>
              <View style={styles.copy}>
                <Text numberOfLines={1} style={[styles.label, active && styles.labelActive]}>{mode.label}</Text>
                <Text style={[styles.caption, active && styles.captionActive]}>{mode.caption}</Text>
              </View>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  shell: { marginBottom: 18 },
  prompt: { color: colors.muted, fontSize: 11, fontWeight: "900", letterSpacing: 0.8, marginBottom: 7, marginLeft: 2 },
  wrapper: { flexDirection: "row", backgroundColor: colors.paper, borderRadius: 18, padding: 5, gap: 4, borderWidth: 1, borderColor: colors.line },
  item: { flex: 1, minHeight: 56, borderRadius: 14, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7, paddingHorizontal: 5 },
  itemActive: { backgroundColor: colors.ink },
  icon: { width: 28, height: 28, borderRadius: 9, alignItems: "center", justifyContent: "center", backgroundColor: colors.cream },
  iconActive: { backgroundColor: colors.lime },
  copy: { flexShrink: 1 },
  label: { color: colors.ink, fontSize: 12, fontWeight: "900" },
  labelActive: { color: colors.paper },
  caption: { color: colors.muted, fontSize: 11, marginTop: 2 },
  captionActive: { color: "#AFC2B6" },
  pressed: { opacity: 0.75 },
});
