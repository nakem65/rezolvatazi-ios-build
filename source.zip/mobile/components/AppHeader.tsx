import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { AccessibilityInfo, Image, Pressable, StyleSheet, Text, View } from "react-native";
import { useProvider } from "@/src/ProviderContext";
import { triggerFeedback } from "@/src/feedback";
import { colors } from "@/src/theme";
import { useMode } from "@/src/ModeContext";

type Props = { eyebrow?: string; title: string; source?: "demo" | "live"; hideRoleSwitcher?: boolean; hideSupport?: boolean };

import { showAppAlert } from "@/src/alerts";

import { useAuth } from "@/src/AuthContext";

export function AppHeader({ eyebrow, title, hideSupport = false }: Props) {
  const { notificationEnabled, toggleNotifications } = useProvider();
  const { provider } = useAuth();
  const { activeMode } = useMode();
  
  async function handleNotificationPress() {
    try {
      triggerFeedback("selection");
      const result = await toggleNotifications();
      if (!result.changed) {
        showAppAlert(
          "Notificările nu au fost modificate",
          result.message
        );
        return;
      }
      // The bell and its dot immediately show the new state. A blocking native
      // alert here forced people to dismiss a message just to return to work.
      AccessibilityInfo.announceForAccessibility(
        result.enabled ? "Notificări activate" : "Notificări dezactivate"
      );
    } catch {
      showAppAlert("Notificări indisponibile", "Nu am putut modifica alertele acum. Încearcă din nou.");
    }
  }

  return (
    <View>
      <View style={styles.row}>
        {/* eslint-disable-next-line @typescript-eslint/no-require-imports */}
        <Image source={require("../assets/icon.png")} style={styles.logo} alt="RezolvatAzi" />
        <View style={styles.copy}>
          {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
          <Text style={styles.title}>{activeMode !== "professional" && provider?.clientName ? provider.clientName : title}</Text>
        </View>
        {!hideSupport ? (
          <Pressable accessibilityLabel="Ajutor și suport" onPress={() => router.push("/support" as never)} style={({ pressed }) => [styles.support, pressed && { opacity: 0.6 }]}>
            <MaterialCommunityIcons name="chat-question-outline" size={21} color={colors.ink} />
          </Pressable>
        ) : null}
        <Pressable accessibilityLabel="Notificări" onPress={() => void handleNotificationPress()} style={({ pressed }) => [styles.notification, pressed && { opacity: 0.6 }]}>
          <MaterialCommunityIcons name={notificationEnabled ? "bell-ring-outline" : "bell-outline"} size={22} color={notificationEnabled ? colors.accent : colors.ink} />
          {notificationEnabled ? <View style={styles.dot} /> : null}
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { minHeight: 58, flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 10 },
  logo: { width: 38, height: 38, borderRadius: 12 },
  copy: { flex: 1 },
  eyebrow: { color: colors.muted, fontSize: 12, fontWeight: "700", marginBottom: 1 },
  title: { color: colors.ink, fontSize: 21, fontWeight: "900", letterSpacing: -0.5 },
  support: { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  notification: { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  dot: { position: "absolute", right: 9, top: 9, width: 7, height: 7, borderRadius: 4, backgroundColor: colors.accent, borderWidth: 1, borderColor: colors.paper },
  mode: { paddingHorizontal: 9, paddingVertical: 7, backgroundColor: "#E7E8E3", borderRadius: 8 },
  modeText: { color: colors.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.8 },
  live: { backgroundColor: colors.mint },
  liveText: { color: colors.mintDark },
});
