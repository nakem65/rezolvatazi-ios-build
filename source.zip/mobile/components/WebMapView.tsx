import { memo, useEffect, useMemo, useRef } from "react";
import { StyleSheet, View } from "react-native";
import { ServiceRequest } from "@/src/types";

type Props = {
  latitude: number;
  longitude: number;
  requests: ServiceRequest[];
  selectedRequestId: string | null;
  onSelectRequest: (id: string | null) => void;
};

export const WebMapView = memo(function WebMapView({ latitude, longitude, requests, selectedRequestId, onSelectRequest }: Props) {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // We serialize the data to inject into the leaflet HTML template
  // Notice we don't include selectedRequestId here, to avoid iframe reloads on selection!
  const mapDataStr = useMemo(() => JSON.stringify({
    centerLat: latitude,
    centerLng: longitude,
    requests: requests.map((r) => {
      return {
        id: r.id,
        lat: r.latitude ? Number(r.latitude) : latitude,
        lng: r.longitude ? Number(r.longitude) : longitude,
        category: r.category,
        price: r.clientPrice
      };
    })
  }), [latitude, longitude, requests]);

  const htmlContent = useMemo(() => `
    <!DOCTYPE html>
    <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
        <style>
          body { margin: 0; padding: 0; background-color: #F5F3EE; }
          #map { height: 100vh; width: 100vw; background-color: #F5F3EE; }
          @keyframes pulse-glow {
            0% { box-shadow: 0 0 0 0 rgba(240, 100, 73, 0.7); transform: scale(0.95); }
            50% { box-shadow: 0 0 0 8px rgba(240, 100, 73, 0); transform: scale(1.1); }
            100% { box-shadow: 0 0 0 0 rgba(240, 100, 73, 0); transform: scale(0.95); }
          }
          .custom-marker { 
            width: 28px !important; 
            height: 42px !important; 
            display: flex;
            align-items: flex-start;
            justify-content: center;
          }
          .pin-base {
            width: 28px;
            height: 42px;
            /* Thin, elegant SVG map pin filled with logo green #68B880 */
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 24 36' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M12 0C5.37258 0 0 5.37258 0 12C0 21 12 36 12 36C12 36 24 21 24 12C24 5.37258 18.6274 0 12 0Z' fill='%2368B880'/%3E%3C/svg%3E");
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
            position: relative;
            filter: drop-shadow(0px 4px 6px rgba(19, 38, 27, 0.4));
            transition: all 0.2s ease;
          }
          .pin-head {
            width: 14px;
            height: 14px;
            background: radial-gradient(circle at 30% 30%, #FFD6C9 0%, #F06449 40%, #C43B22 100%);
            border-radius: 50%;
            position: absolute;
            top: 7px;
            left: 7px;
            animation: pulse-glow 2s infinite ease-in-out;
          }
          .custom-marker.selected .pin-base {
            /* Selected state uses "mintDark" #17623A */
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 24 36' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M12 0C5.37258 0 0 5.37258 0 12C0 21 12 36 12 36C12 36 24 21 24 12C24 5.37258 18.6274 0 12 0Z' fill='%2317623A'/%3E%3C/svg%3E");
            transform: scale(1.15) translateY(-4px);
            filter: drop-shadow(0px 6px 12px rgba(23, 98, 58, 0.5));
          }
          .custom-marker.selected .pin-head {
            animation: none !important;
            background: #fff !important;
            box-shadow: none !important;
          }
          .my-location {
            background: #2563EB;
            border: 3px solid #fff;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            box-shadow: 0 0 15px rgba(37, 99, 235, 0.6);
          }
          .leaflet-control-center {
            background: #fff;
            padding: 8px 12px;
            border-radius: 20px;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            font-size: 13px;
            font-weight: 700;
            color: #111;
            text-align: center;
          }
          .leaflet-control-center:hover { background: #f9f9f9; transform: scale(1.02); }
        </style>
      </head>
      <body>
        <div id="map"></div>
        <script>
          const data = ${mapDataStr};
          let currentSelectedId = null;
          
          const map = L.map('map', { 
            zoomControl: false,
            attributionControl: false,
            maxBounds: [[43.6, 20.2], [48.3, 29.7]],
            maxBoundsViscosity: 1.0
          }).setView([data.centerLat, data.centerLng], 14);
          
          L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
            maxZoom: 20,
            subdomains: 'abcd'
          }).addTo(map);

          // Add My Location Marker
          const myIcon = L.divIcon({ className: 'my-location', iconSize: [16, 16] });
          L.marker([data.centerLat, data.centerLng], { icon: myIcon }).addTo(map).bindPopup("Locația ta");

          // Keep invalidating size to prevent top-left corner bug on resize or slow load
          setInterval(() => { map.invalidateSize(); }, 1500);

          // Add Request Markers (with Clustering)
          const markersCluster = L.markerClusterGroup({ disableClusteringAtZoom: 16, maxClusterRadius: 40 });
          data.requests.forEach(req => {
            if (!req.lat || !req.lng) return;
            const icon = L.divIcon({ 
              className: 'custom-marker',
              iconSize: [28, 42],
              iconAnchor: [14, 42],
              html: '<div class="pin-base" id="marker-inner-' + req.id + '"><div class="pin-head"></div></div>'
            });
            const marker = L.marker([req.lat, req.lng], { icon });
            
            // We set the marker ID on the outer container after it's added
            marker.on('add', function() {
              if (marker._icon) marker._icon.id = 'marker-' + req.id;
            });

            marker.on('click', () => {
              window.parent.postMessage({ type: 'SELECT_REQUEST', id: req.id }, '*');
            });
            markersCluster.addLayer(marker);
          });
          map.addLayer(markersCluster);

          // Add Recenter Control Button
          const CenterControl = L.Control.extend({
            options: { position: 'topright' },
            onAdd: function() {
              const div = L.DomUtil.create('div', 'leaflet-control-center');
              div.innerHTML = '📍 Locația mea';
              div.onclick = function() {
                map.flyTo([data.centerLat, data.centerLng], 14);
              };
              return div;
            }
          });
          map.addControl(new CenterControl());

          // Click on empty map area to deselect
          map.on('click', function() {
            window.parent.postMessage({ type: 'DESELECT_REQUEST' }, '*');
          });

          // Deselect on drag/slide
          map.on('dragstart', function() {
            window.parent.postMessage({ type: 'DESELECT_REQUEST' }, '*');
          });

          window.addEventListener('message', function(event) {
            if (event.data && event.data.type === 'SET_SELECTED') {
              // clear previous
              if (currentSelectedId) {
                const prev = document.getElementById('marker-' + currentSelectedId);
                if (prev) prev.classList.remove('selected');
              }
              currentSelectedId = event.data.id;
              if (currentSelectedId) {
                const next = document.getElementById('marker-' + currentSelectedId);
                if (next) next.classList.add('selected');
              }
            }
          });
        </script>
      </body>
    </html>
  `, [mapDataStr]);

  // We extract the iframe to a completely decoupled component so React doesn't touch srcDoc when selectedRequestId changes
  const PureIframe = useMemo(() => {
    return memo(function PureIframeComponent({ html }: { html: string }) {
      return (
        <iframe
          ref={iframeRef}
          srcDoc={html}
          style={{ width: "100%", height: "100%", border: 0, borderRadius: 14 }}
          title="Harta interactivă RezolvatAzi"
        />
      );
    });
  }, []);

  // Avoid updating iframe completely if only selection changes.
  // We use postMessage to update selection without reloading iframe.
  useEffect(() => {
    if (iframeRef.current && iframeRef.current.contentWindow) {
      iframeRef.current.contentWindow.postMessage({ type: 'SET_SELECTED', id: selectedRequestId }, '*');
    }
  }, [selectedRequestId]);

  useEffect(() => {
    function handleMessage(event: MessageEvent) {
      if (event.data && event.data.type === 'SELECT_REQUEST') {
        onSelectRequest(event.data.id);
      } else if (event.data && event.data.type === 'DESELECT_REQUEST') {
        onSelectRequest(null);
      }
    }
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onSelectRequest]);

  return (
    <View style={styles.container}>
      <PureIframe html={htmlContent} />
    </View>
  );
});

const styles = StyleSheet.create({
  container: { flex: 1, width: "100%", height: "100%", position: "relative" },
});
