import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useState } from "react";
import { Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import {
  estimatePricingDraftTotal,
  materialsModeOptions,
  pricingUnitOptions,
  travelModeOptions,
  vatModeOptions,
} from "@/src/pricing";
import type { OfferPricingDraft } from "@/src/types";
import { colors } from "@/src/theme";

type Props = {
  value: OfferPricingDraft;
  onChange: (value: OfferPricingDraft) => void;
  requiredParticipants: number;
};

function numberValue(value: string) {
  if (!value.trim()) return 0;
  const parsed = Number(value.replace(",", "."));
  return Number.isFinite(parsed) ? parsed : 0;
}

function formatPreviewLei(value: number) {
  return new Intl.NumberFormat("ro-RO", {
    minimumFractionDigits: value % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(value);
}

export function OfferPricingComposer({ value, onChange, requiredParticipants }: Props) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const selectedUnit = pricingUnitOptions.find((option) => option.value === value.unit) ?? pricingUnitOptions[0];
  const total = estimatePricingDraftTotal(value);

  function update(patch: Partial<OfferPricingDraft>) {
    onChange({ ...value, ...patch });
  }

  return (
    <View style={styles.card}>
      <Text style={styles.sectionTitle}>Cum calculezi prețul?</Text>
      <Pressable onPress={() => setPickerOpen(true)} style={styles.selector}>
        <View>
          <Text style={styles.selectorLabel}>MOD DE CALCUL</Text>
          <Text style={styles.selectorValue}>{selectedUnit.label}</Text>
        </View>
        <MaterialCommunityIcons name="chevron-down" size={22} color={colors.muted} />
      </Pressable>

      <Modal
        visible={pickerOpen}
        transparent
        animationType="slide"
        onRequestClose={() => setPickerOpen(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setPickerOpen(false)}>
          <Pressable style={styles.modalCard} onPress={(event) => event.stopPropagation()}>
            <View style={styles.modalHeading}>
              <View><Text style={styles.modalKicker}>PREȚ</Text><Text style={styles.modalTitle}>Alege modul de calcul</Text></View>
              <Pressable onPress={() => setPickerOpen(false)} hitSlop={8}>
                <MaterialCommunityIcons name="close" size={24} color={colors.ink} />
              </Pressable>
            </View>
            <ScrollView>
              {pricingUnitOptions.map((option) => (
                <Pressable
                  key={option.value}
                  onPress={() => {
                    update({
                      unit: option.value,
                      estimatedQuantity: option.value === "job" ? 1 : Math.max(1, value.estimatedQuantity),
                      priceType: option.value === "job" ? value.priceType : "estimate",
                    });
                    setPickerOpen(false);
                  }}
                  style={[styles.unitOption, value.unit === option.value && styles.unitOptionActive]}
                >
                  <Text style={[styles.unitOptionText, value.unit === option.value && styles.unitOptionTextActive]}>{option.label}</Text>
                  {value.unit === option.value ? <MaterialCommunityIcons name="check" size={19} color={colors.paper} /> : null}
                </Pressable>
              ))}
            </ScrollView>
          </Pressable>
        </Pressable>
      </Modal>

      <Text style={styles.label}>{value.unit === "job" ? "Prețul lucrării" : `Tarif pe ${selectedUnit.short}`}</Text>
      <View style={styles.moneyInput}>
        <TextInput
          value={value.unitPriceLei ? String(value.unitPriceLei) : ""}
          onChangeText={(text) => update({ unitPriceLei: numberValue(text) })}
          inputMode="decimal"
          placeholder={value.unit === "job" ? "Ex: 350" : "Ex: 50"}
          placeholderTextColor="#A7AEA8"
          style={styles.moneyText}
        />
        <Text style={styles.currency}>{value.unit === "job" ? "LEI" : `LEI/${selectedUnit.short.toLocaleUpperCase("ro-RO")}`}</Text>
      </View>

      {value.unit !== "job" ? (
        <View style={styles.twoColumns}>
          <View style={styles.column}>
            <Text style={styles.label}>{value.unit === "person_hour" ? "Ore estimate" : `Cantitate estimată (${selectedUnit.short})`}</Text>
            <TextInput
              value={value.estimatedQuantity ? String(value.estimatedQuantity) : ""}
              onChangeText={(text) => update({ estimatedQuantity: numberValue(text) })}
              inputMode="decimal"
              placeholder="Ex: 3"
              placeholderTextColor="#A7AEA8"
              style={styles.smallInput}
            />
          </View>
          <View style={styles.column}>
            <Text style={styles.label}>Preț minim (opțional)</Text>
            <TextInput
              value={value.minimumPriceLei ? String(value.minimumPriceLei) : ""}
              onChangeText={(text) => update({ minimumPriceLei: numberValue(text) })}
              inputMode="decimal"
              placeholder="0 lei"
              placeholderTextColor="#A7AEA8"
              style={styles.smallInput}
            />
          </View>
        </View>
      ) : null}

      {requiredParticipants > 1 ? (
        <View style={styles.participants}>
          <View style={styles.participantsCopy}>
            <Text style={styles.label}>Câte persoane asiguri?</Text>
            <Text style={styles.hint}>Clientul are nevoie de {requiredParticipants}. Poți oferi un loc sau o echipă.</Text>
          </View>
          <View style={styles.counter}>
            <Pressable onPress={() => update({ includedParticipants: Math.max(1, value.includedParticipants - 1) })} style={styles.counterButton}><Text style={styles.counterButtonText}>−</Text></Pressable>
            <Text style={styles.counterValue}>{value.includedParticipants}</Text>
            <Pressable onPress={() => update({ includedParticipants: Math.min(requiredParticipants, value.includedParticipants + 1) })} style={styles.counterButton}><Text style={styles.counterButtonText}>+</Text></Pressable>
          </View>
        </View>
      ) : null}

      <Text style={styles.label}>Cât de exact este prețul?</Text>
      <View style={styles.segmentRow}>
        {([
          { value: "fixed", label: "Preț fix" },
          { value: "estimate", label: "Estimare" },
        ] as const).map((option) => (
          <Pressable key={option.value} onPress={() => update({ priceType: option.value })} style={[styles.segment, value.priceType === option.value && styles.segmentActive]}>
            <Text style={[styles.segmentText, value.priceType === option.value && styles.segmentTextActive]}>{option.label}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={styles.label}>Deplasare</Text>
      <View style={styles.segmentRow}>
        {travelModeOptions.map((option) => (
          <Pressable key={option.value} onPress={() => update({ travelMode: option.value })} style={[styles.segment, value.travelMode === option.value && styles.segmentActive]}>
            <Text style={[styles.segmentText, value.travelMode === option.value && styles.segmentTextActive]}>{option.label}</Text>
          </Pressable>
        ))}
      </View>
      {value.travelMode === "fixed" ? (
        <TextInput value={value.travelFeeLei ? String(value.travelFeeLei) : ""} onChangeText={(text) => update({ travelFeeLei: numberValue(text) })} inputMode="decimal" placeholder="Taxă de deplasare în lei" placeholderTextColor="#A7AEA8" style={styles.fullInput} />
      ) : null}
      {value.travelMode === "per_km" ? (
        <View style={styles.twoColumns}>
          <View style={styles.column}><Text style={styles.hintLabel}>LEI/KM</Text><TextInput value={value.travelRateLei ? String(value.travelRateLei) : ""} onChangeText={(text) => update({ travelRateLei: numberValue(text) })} inputMode="decimal" placeholder="Ex: 2,5" placeholderTextColor="#A7AEA8" style={styles.smallInput} /></View>
          <View style={styles.column}><Text style={styles.hintLabel}>KM ESTIMAȚI</Text><TextInput value={value.estimatedTravelKm ? String(value.estimatedTravelKm) : ""} onChangeText={(text) => update({ estimatedTravelKm: numberValue(text) })} inputMode="decimal" placeholder="Ex: 20" placeholderTextColor="#A7AEA8" style={styles.smallInput} /></View>
        </View>
      ) : null}

      <Text style={styles.label}>Materiale</Text>
      <View style={styles.segmentRow}>
        {materialsModeOptions.map((option) => (
          <Pressable key={option.value} onPress={() => update({ materialsMode: option.value })} style={[styles.segment, value.materialsMode === option.value && styles.segmentActive]}>
            <Text style={[styles.segmentText, value.materialsMode === option.value && styles.segmentTextActive]}>{option.label}</Text>
          </Pressable>
        ))}
      </View>
      {value.materialsMode === "estimated" ? (
        <TextInput value={value.materialsCostLei ? String(value.materialsCostLei) : ""} onChangeText={(text) => update({ materialsCostLei: numberValue(text) })} inputMode="decimal" placeholder="Cost estimat al materialelor în lei" placeholderTextColor="#A7AEA8" style={styles.fullInput} />
      ) : null}

      <Text style={styles.label}>TVA</Text>
      <View style={styles.segmentWrap}>
        {vatModeOptions.map((option) => (
          <Pressable key={option.value} onPress={() => update({ vatMode: option.value, vatIncluded: option.value === "included" })} style={[styles.vatSegment, value.vatMode === option.value && styles.segmentActive]}>
            <Text style={[styles.segmentText, value.vatMode === option.value && styles.segmentTextActive]}>{option.label}</Text>
          </Pressable>
        ))}
      </View>

      <View style={styles.summary}>
        <View>
          <Text style={styles.summaryLabel}>CLIENTUL VA VEDEA</Text>
          <Text style={styles.summaryTitle}>{value.priceType === "estimate" ? "Aproximativ " : ""}{formatPreviewLei(total)} lei</Text>
        </View>
        <MaterialCommunityIcons name="calculator-variant-outline" size={25} color={colors.mintDark} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 14, marginBottom: 18 },
  sectionTitle: { color: colors.ink, fontSize: 16, fontWeight: "900", marginBottom: 12 },
  selector: { minHeight: 58, borderWidth: 1, borderColor: colors.line, borderRadius: 13, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: colors.cream, marginBottom: 13 },
  selectorLabel: { color: colors.muted, fontSize: 11, fontWeight: "900", letterSpacing: 0.4 },
  selectorValue: { color: colors.ink, fontSize: 14, fontWeight: "800", marginTop: 3 },
  label: { color: colors.ink, fontSize: 12, fontWeight: "800", marginBottom: 6, marginTop: 5 },
  moneyInput: { height: 54, borderWidth: 1, borderColor: colors.line, borderRadius: 12, flexDirection: "row", alignItems: "center", paddingHorizontal: 12, marginBottom: 11 },
  moneyText: { flex: 1, color: colors.ink, fontSize: 18, fontWeight: "800" },
  currency: { color: colors.muted, fontSize: 12, fontWeight: "900" },
  twoColumns: { flexDirection: "row", gap: 9, marginBottom: 10 },
  column: { flex: 1 },
  smallInput: { height: 47, borderWidth: 1, borderColor: colors.line, borderRadius: 11, paddingHorizontal: 11, color: colors.ink, backgroundColor: colors.cream, fontSize: 13 },
  fullInput: { height: 47, borderWidth: 1, borderColor: colors.line, borderRadius: 11, paddingHorizontal: 11, color: colors.ink, backgroundColor: colors.cream, fontSize: 13, marginBottom: 10 },
  hintLabel: { color: colors.muted, fontSize: 11, fontWeight: "900", marginBottom: 5 },
  segmentRow: { flexDirection: "row", gap: 6, marginBottom: 11 },
  segmentWrap: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 11 },
  segment: { flex: 1, minHeight: 42, alignItems: "center", justifyContent: "center", borderRadius: 10, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 5, backgroundColor: colors.cream },
  vatSegment: { width: "48%", minHeight: 42, alignItems: "center", justifyContent: "center", borderRadius: 10, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 5, backgroundColor: colors.cream },
  segmentActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  segmentText: { color: colors.muted, fontSize: 12, fontWeight: "800", textAlign: "center" },
  segmentTextActive: { color: colors.paper },
  participants: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: colors.line, borderRadius: 12, padding: 11, marginBottom: 10 },
  participantsCopy: { flex: 1, paddingRight: 10 },
  hint: { color: colors.muted, fontSize: 12, lineHeight: 17 },
  counter: { flexDirection: "row", alignItems: "center", gap: 8 },
  counterButton: { width: 34, height: 34, borderRadius: 9, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center" },
  counterButtonText: { color: colors.ink, fontSize: 20, fontWeight: "800" },
  counterValue: { color: colors.ink, fontSize: 16, fontWeight: "900", minWidth: 18, textAlign: "center" },
  summary: { backgroundColor: colors.mint, borderRadius: 13, padding: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 3 },
  summaryLabel: { color: colors.mintDark, fontSize: 11, fontWeight: "900" },
  summaryTitle: { color: colors.mintDark, fontSize: 18, fontWeight: "900", marginTop: 3 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" },
  modalCard: { maxHeight: "82%", backgroundColor: colors.paper, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 18, paddingBottom: 28 },
  modalHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  modalKicker: { color: colors.accent, fontSize: 11, fontWeight: "900" },
  modalTitle: { color: colors.ink, fontSize: 19, fontWeight: "900", marginTop: 3 },
  unitOption: { minHeight: 50, borderWidth: 1, borderColor: colors.line, borderRadius: 12, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 7 },
  unitOptionActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  unitOptionText: { color: colors.ink, fontSize: 13, fontWeight: "700" },
  unitOptionTextActive: { color: colors.paper },
});
