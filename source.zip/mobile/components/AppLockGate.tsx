import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { PropsWithChildren, useEffect, useRef, useState } from "react";
import { AppState, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { useAuth } from "@/src/AuthContext";
import {
  authenticateWithBiometrics,
  getBiometricLockEnabled,
  setBiometricLockEnabled,
  subscribeToBiometricLock,
  type BiometricAvailability,
} from "@/src/device-preferences";
import { triggerFeedback } from "@/src/feedback";
import { colors } from "@/src/theme";

function isSignedIn(status: ReturnType<typeof useAuth>["status"]) {
  return status === "ready" || status === "needsOnboarding";
}

export function AppLockGate({ children }: PropsWithChildren) {
  const { status } = useAuth();
  const [preferencesReady, setPreferencesReady] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [locked, setLocked] = useState(false);
  const [authenticating, setAuthenticating] = useState(false);
  const [availability, setAvailability] = useState<BiometricAvailability>({ available: false, label: "Biometrie" });
  const firstResolvedAuth = useRef(false);

  useEffect(() => {
    let active = true;
    void getBiometricLockEnabled().then((enabled) => {
      if (!active) return;
      setBiometricEnabled(enabled);
      setPreferencesReady(true);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => subscribeToBiometricLock((enabled) => {
    setBiometricEnabled(enabled);
    // The person has just confirmed the change in Settings. Lock only after
    // the next background/foreground transition, never in the middle of it.
    setLocked(false);
  }), []);

  useEffect(() => {
    if (!preferencesReady || status === "loading") return;
    if (!firstResolvedAuth.current) {
      firstResolvedAuth.current = true;
      if (biometricEnabled && isSignedIn(status)) setLocked(true);
      return;
    }
    if (!isSignedIn(status)) setLocked(false);
  }, [biometricEnabled, preferencesReady, status]);

  useEffect(() => {
    if (Platform.OS === "web") return;
    const subscription = AppState.addEventListener("change", (nextState) => {
      if (nextState === "active" && biometricEnabled && isSignedIn(status)) setLocked(true);
    });
    return () => subscription.remove();
  }, [biometricEnabled, status]);

  async function unlock() {
    setAuthenticating(true);
    const result = await authenticateWithBiometrics();
    setAvailability(result.availability);
    setAuthenticating(false);
    if (result.success) {
      triggerFeedback("success");
      setLocked(false);
      return;
    }
    // A user can remove Face ID/fingerprint from the phone after enabling the
    // option. Do not leave them trapped behind a setting that no longer works.
    if (!result.availability.available) {
      await setBiometricLockEnabled(false);
      setLocked(false);
    }
  }

  if (Platform.OS === "web" || !locked || !isSignedIn(status)) return <>{children}</>;

  return (
    <View style={styles.root}>
      {children}
      <View style={styles.lockOverlay} accessibilityViewIsModal>
        <View style={styles.lockCard}>
          <View style={styles.lockIcon}><MaterialCommunityIcons name="shield-lock-outline" size={29} color={colors.mintDark} /></View>
          <Text style={styles.lockTitle}>RezolvatAzi este blocată</Text>
          <Text style={styles.lockText}>Confirmă pe acest telefon pentru a-ți vedea cererile, mesajele și profilurile.</Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Deblochează cu ${availability.label}`}
            disabled={authenticating}
            onPress={() => void unlock()}
            style={({ pressed }) => [styles.unlockButton, pressed && styles.unlockButtonPressed, authenticating && styles.unlockButtonDisabled]}
          >
            <MaterialCommunityIcons name="face-recognition" size={19} color={colors.paper} />
            <Text style={styles.unlockText}>{authenticating ? "Se verifică…" : "Deblochează"}</Text>
          </Pressable>
          <Text style={styles.lockHint}>Folosește Face ID, Touch ID/amprenta sau codul telefonului.</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  lockOverlay: { ...StyleSheet.absoluteFill, zIndex: 1000, alignItems: "center", justifyContent: "center", padding: 24, backgroundColor: "rgba(19, 38, 27, 0.92)" },
  lockCard: { width: "100%", maxWidth: 390, alignItems: "center", borderRadius: 24, padding: 25, backgroundColor: colors.paper },
  lockIcon: { width: 58, height: 58, borderRadius: 18, alignItems: "center", justifyContent: "center", backgroundColor: colors.mint },
  lockTitle: { marginTop: 17, color: colors.ink, fontSize: 19, fontWeight: "900" },
  lockText: { marginTop: 8, color: colors.muted, fontSize: 13, lineHeight: 19, textAlign: "center" },
  unlockButton: { minHeight: 50, minWidth: 190, marginTop: 23, borderRadius: 14, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, backgroundColor: colors.ink },
  unlockButtonPressed: { opacity: 0.84 },
  unlockButtonDisabled: { opacity: 0.58 },
  unlockText: { color: colors.paper, fontSize: 13, fontWeight: "900" },
  lockHint: { marginTop: 14, color: colors.muted, fontSize: 10, lineHeight: 14, textAlign: "center" },
});
