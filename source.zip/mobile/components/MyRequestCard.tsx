import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { colors, shadow } from "@/src/theme";
import { MyRequest } from "@/src/types";

const statusCopy: Record<string, string> = { open: "Activă", matched: "Ajutor ales", completed: "Finalizată", cancelled: "Anulată", expired: "Expirată", cancelled_after_match: "Închisă", no_show: "Neprezentare", disputed: "Raportată" };

export function MyRequestCard({ request }: { request: MyRequest }) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={() => router.push({ pathname: "/my-request/[id]", params: { id: request.id } } as never)}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <View style={styles.top}>
        <View style={[styles.mode, { flexShrink: 1 }, request.status === "open" && styles.modeOpen, request.status === "expired" && styles.modeExpired]}>
          <MaterialCommunityIcons name="clipboard-check-outline" size={14} color={request.status === "open" ? colors.mintDark : request.status === "expired" ? "#A84E00" : colors.accentDark} />
          <Text style={[styles.modeText, request.status === "open" && styles.modeTextOpen, request.status === "expired" && styles.modeTextExpired]}>{request.status === "open" ? "ACTIVĂ" : request.status === "expired" ? "EXPIRATĂ" : request.workOrder?.solutionKind === "recurring" ? "RECURENT" : request.workOrder?.solutionKind === "team" ? "ECHIPĂ" : "LUCRARE"}</Text>
        </View>
        <Text style={[styles.status, request.status === "open" && styles.statusOpen, request.status === "expired" && styles.statusExpired]}>{statusCopy[request.status] ?? request.status}</Text>
      </View>
      <Text style={styles.title}>{request.category}</Text>
      <Text style={styles.description} numberOfLines={2}>{request.description}</Text>
      <View style={styles.footer}><Text style={styles.meta}>{request.city} · {request.offerCount} {request.offerCount === 1 ? "răspuns" : "răspunsuri"}</Text><MaterialCommunityIcons name="chevron-right" size={20} color={colors.accent} /></View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 16, marginBottom: 11, ...shadow }, pressed: { opacity: 0.82 },
  top: { flexDirection: "row", alignItems: "center" }, mode: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: colors.dangerSoft, borderRadius: 99, paddingHorizontal: 8, paddingVertical: 5 }, modeOpen: { backgroundColor: "#E5F4EA" }, modeExpired: { backgroundColor: "#FFF1E5" }, modeText: { color: colors.accentDark, fontSize: 8, fontWeight: "900" }, modeTextOpen: { color: colors.mintDark }, modeTextExpired: { color: "#A84E00" }, status: { marginLeft: "auto", color: colors.muted, fontSize: 10, fontWeight: "900" }, statusOpen: { color: colors.mintDark }, statusExpired: { color: "#A84E00" },
  title: { color: colors.ink, fontSize: 16, fontWeight: "900", marginTop: 12 }, description: { color: colors.muted, fontSize: 11, lineHeight: 17, marginTop: 5 }, footer: { borderTopWidth: 1, borderTopColor: colors.line, marginTop: 12, paddingTop: 10, flexDirection: "row", alignItems: "center" }, meta: { flex: 1, color: colors.muted, fontSize: 9 },
});
