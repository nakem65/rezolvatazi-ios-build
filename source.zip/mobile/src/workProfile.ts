import type { ProviderCapabilityLevel, ProviderEntityType, ProviderEquipmentId } from "./types";

export const providerEntityOptions: Array<{ value: ProviderEntityType; label: string; description: string }> = [
  { value: "individual", label: "Persoană fizică", description: "Lucrez în nume propriu." },
  { value: "pfa", label: "PFA / II / IF", description: "Pot emite documente prin forma autorizată." },
  { value: "company", label: "Firmă", description: "Lucrez prin SRL sau altă persoană juridică." },
];

export const capabilityLevelOptions: Array<{ value: ProviderCapabilityLevel; label: string }> = [
  { value: "can_do", label: "Pot face" },
  { value: "experienced", label: "Experimentat" },
  { value: "specialist", label: "Specialist" },
];

export const equipmentOptions: Array<{ value: ProviderEquipmentId; label: string; icon: string }> = [
  { value: "basic_tools", label: "Scule de bază", icon: "toolbox-outline" },
  { value: "power_tools", label: "Scule electrice", icon: "drill" },
  { value: "ladder", label: "Scară", icon: "ladder" },
  { value: "car", label: "Autoturism", icon: "car-outline" },
  { value: "van", label: "Dubă", icon: "van-utility" },
  { value: "garden_equipment", label: "Echipament grădină", icon: "grass" },
  { value: "cleaning_equipment", label: "Echipament curățenie", icon: "vacuum-outline" },
  { value: "protective_equipment", label: "Echipament protecție", icon: "hard-hat" },
];
