import { Platform } from "react-native";

export type NotificationResult = { enabled: boolean; token?: string; message?: string };

export async function registerForRequestAlerts(): Promise<NotificationResult> {
  if (Platform.OS === "web") {
    return { enabled: false, message: "Alertele push sunt disponibile în aplicația mobilă pentru Android și iPhone." };
  }
  const [{ default: Constants }, Device, Notifications] = await Promise.all([
    import("expo-constants"),
    import("expo-device"),
    import("expo-notifications"),
  ]);
  if (!Device.isDevice) {
    return { enabled: false, message: "Folosește un telefon fizic pentru alertele push." };
  }

  if (Platform.OS === "android") {
    await Promise.all([
      Notifications.setNotificationChannelAsync("cereri-urgente", {
        name: "Cereri urgente",
        importance: Notifications.AndroidImportance.MAX,
        sound: "default",
        vibrationPattern: [0, 250, 150, 250],
        lightColor: "#F06449",
      }),
      Notifications.setNotificationChannelAsync("cereri-standard", {
        name: "Cereri noi",
        importance: Notifications.AndroidImportance.HIGH,
        sound: "default",
        vibrationPattern: [0, 180],
        lightColor: "#F06449",
      }),
      Notifications.setNotificationChannelAsync("mesaje", {
        name: "Mesaje",
        importance: Notifications.AndroidImportance.HIGH,
        sound: "default",
        vibrationPattern: [0, 180],
        lightColor: "#2E7D5B",
      }),
    ]);
  }

  const existing = await Notifications.getPermissionsAsync();
  const permission = existing.status === "granted" ? existing : await Notifications.requestPermissionsAsync();
  if (permission.status !== "granted") {
    return { enabled: false, message: "Permisiunea pentru notificări nu a fost acordată." };
  }

  const projectId = Constants.expoConfig?.extra?.eas?.projectId ?? Constants.easConfig?.projectId;
  if (!projectId) {
    return { enabled: false, message: "Alertele push nu sunt disponibile momentan. Încearcă din nou mai târziu." };
  }

  const token = await Notifications.getExpoPushTokenAsync({ projectId });
  return { enabled: true, token: token.data };
}
