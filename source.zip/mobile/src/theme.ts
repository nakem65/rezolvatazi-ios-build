export const colors = {
  ink: "#17231D",
  inkSoft: "#12372A",
  accent: "#F15D47",
  accentDark: "#C94231",
  // Un verde foarte deschis păstrează contrastul cardurilor albe, dar evită
  // fundalul gri inert observat în testele pe iPhone.
  cream: "#F4FAF5",
  paper: "#FFFFFF",
  mint: "#EAF5EE",
  mintDark: "#286B47",
  lime: "#EAF5EE",
  yellow: "#F6F2E8",
  text: "#17231D",
  muted: "#6B756F",
  line: "#E1E5E2",
  dangerSoft: "#FBE9E5",
} as const;

export const shadow = Platform.select<ViewStyle>({
  web: { boxShadow: "0 12px 30px rgba(11, 33, 24, 0.09)" },
  default: {
    shadowColor: "#0B2118",
    shadowOpacity: 0.1,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 12 },
    elevation: 4,
  },
}) ?? {};
import { Platform, ViewStyle } from "react-native";
