const customPrefix = "Altele::";

export function createCustomCapabilityId(label: string) {
  const normalized = label.replace(/\s+/g, " ").trim().slice(0, 70);
  return normalized.length >= 3 ? `${customPrefix}${normalized}` : "";
}

export function customCapabilityLabel(categoryId: string) {
  return categoryId.startsWith(customPrefix) ? categoryId.slice(customPrefix.length).trim() : null;
}
