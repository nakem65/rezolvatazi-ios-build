export const ROMANIAN_CITIES = [
  "București",
  "Cluj-Napoca",
  "Timișoara",
  "Iași",
  "Constanța",
  "Brașov",
  "Craiova",
  "Galați",
  "Oradea",
  "Ploiești",
  "Brăila",
  "Arad",
  "Pitești",
  "Sibiu",
  "Bacău",
  "Târgu Mureș",
  "Baia Mare",
  "Buzău",
  "Botoșani",
  "Satu Mare",
  "Suceava",
  "Piatra Neamț",
  "Râmnicu Vâlcea",
  "Drobeta-Turnu Severin",
  "Târgoviște",
  "Focșani",
  "Târgu Jiu",
  "Tulcea",
  "Reșița",
  "Bistrița",
  "Slatina",
  "Călărași",
  "Giurgiu",
  "Deva",
  "Hunedoara",
  "Zalău",
  "Alba Iulia",
  "Sfântu Gheorghe",
  "Vaslui",
  "Roman",
  "Slobozia",
  "Turda",
  "Mediaș",
  "Alexandria",
  "Voluntari",
  "Popești-Leordeni",
  "Chiajna",
  "Toată țara"
];

const INVALID_GENERIC_WORDS = ["sector", "strada", "str", "bloc", "scara", "ap", "zona", "judet", "oras", "test", "demo", "nimic"];

export function isValidRomanianLocation(city: string): boolean {
  const normalized = city.trim().toLocaleLowerCase("ro-RO");
  if (normalized.length < 3) return false;
  if (!/[a-zăâîșț]/i.test(normalized) || INVALID_GENERIC_WORDS.includes(normalized)) return false;
  if (normalized === "toată țara") return false;

  if (/^sector\s*[1-6](\s*,?\s*bucurești)?$/i.test(normalized)) return true;

  const knownPlace = ROMANIAN_CITIES.some((c) => {
    const target = c.toLowerCase();
    return target === normalized || normalized.startsWith(target) || normalized.includes(target);
  });
  if (knownPlace) return true;

  // Satele, comunele, cartierele și adresele nu trebuie limitate la o listă
  // întreținută manual. Cerem totuși suficient context pentru a evita valori
  // precum „strada”, „test” sau o singură literă.
  return true;
}

export function isValidRomanianCity(city: string): boolean {
  return isValidRomanianLocation(city);
}
