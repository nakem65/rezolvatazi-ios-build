export function normalizeRomanianTaxId(value: string) {
  const digits = value.trim().toUpperCase().replace(/^RO\s*/u, "").replace(/\D/g, "");
  return digits ? `RO${digits}` : "";
}

export function isValidRomanianTaxId(value: string) {
  const digits = normalizeRomanianTaxId(value).slice(2);
  if (!/^\d{2,10}$/.test(digits)) return false;
  const controlDigit = Number(digits.at(-1));
  const body = digits.slice(0, -1).padStart(9, "0");
  const weights = "753217532";
  const sum = [...body].reduce((total, digit, index) => total + Number(digit) * Number(weights[index]), 0);
  const calculated = (sum * 10) % 11;
  return controlDigit === (calculated === 10 ? 0 : calculated);
}
