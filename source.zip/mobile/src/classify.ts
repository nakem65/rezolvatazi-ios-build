export const categories = [
  "Mutări & manipulare",
  "Curte & grădină",
  "Curățenie & dăunători",
  "Montaj & reparații mici",
  "Instalații sanitare",
  "Electrician",
  "Lăcătuș",
  "Aer condiționat",
  "Electrocasnice",
  "Auto & tractări",
  "Transport & livrări",
  "Ajutor temporar",
  "Altele",
] as const;

const rules = [
  ["Mutări & manipulare", ["mutare", "mă mut", "ma mut", "cărat", "carat", "încărc", "incarc", "descărc", "descarc", "mobilă grea", "mobila grea", "cutii"]],
  ["Curte & grădină", ["tuns iarba", "tăiat iarba", "tai iarba", "gazon", "curte", "grădin", "gradin", "gard viu", "frunze", "crengi"]],
  ["Curățenie & dăunători", ["curăț", "curata casa", "de curatat", "menaj", "spălat geam", "spalat geam", "gândac", "gandac", "șoarec", "soarec"]],
  ["Montaj & reparații mici", ["montaj", "montare", "asambl", "mobilier", "dulap", "raft", "galerie", "suport tv", "televizor pe perete"]],
  ["Instalații sanitare", ["țeav", "teava", "apă", "apa", "chiuvet", "wc", "robinet", "inunda"]],
  ["Electrician", ["curent", "priz", "siguran", "electric", "scurtcircuit"]],
  ["Lăcătuș", ["ușă", "usa", "yal", "cheie", "cheia", "chei", "broasc", "lacăt", "lacat", "blocat în afara", "blocat in afara"]],
  ["Aer condiționat", ["aer condiționat", "aer conditionat", "aerul condiționat", "aerul conditionat", "aparatul de aer", "climatiz", "freon", "unitatea externă", "unitatea externa", "aparat split", "aerul nu mai răcește", "aerul nu mai raceste"]],
  ["Electrocasnice", ["frigider", "mașina de spălat", "masina de spalat", "cuptor", "plită", "plita"]],
  ["Auto & tractări", ["mașin", "masin", "baterie auto", "pană", "pana", "tract", "motor"]],
  ["Transport & livrări", ["livrare", "livrez", "transport", "ridicat colet", "ridice colet", "dus pachet", "curier"]],
  ["Ajutor temporar", ["ajutor temporar", "personal temporar", "muncitor", "inventar", "aranjat marf", "descărcat marf", "descarcat marf", "eveniment", "târg", "targ", "instructaj", "pontaj", "coordonator de tură", "coordonator de tura"]],
] as const;

function matchesTerm(text: string, term: string) {
  if ([...term].length > 3 || term.includes(" ")) return text.includes(term);
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^\\p{L}])${escaped}($|[^\\p{L}])`, "u").test(text);
}

export function inferCategory(value: string) {
  const text = value.toLocaleLowerCase("ro-RO");
  let best: string = "Altele";
  let bestScore = 0;
  let bestFirstIndex = Number.POSITIVE_INFINITY;
  for (const [category, terms] of rules) {
    const matchedTerms = terms.filter((term) => matchesTerm(text, term));
    const matchIndexes = new Set(matchedTerms.map((term) => text.indexOf(term)).filter((index) => index >= 0));
    const score = matchIndexes.size;
    const firstIndex = matchIndexes.size ? Math.min(...matchIndexes) : Number.POSITIVE_INFINITY;
    if (score > bestScore || (score === bestScore && score > 0 && firstIndex < bestFirstIndex)) {
      best = category;
      bestScore = score;
      bestFirstIndex = firstIndex;
    }
  }
  return best;
}

export function hasEmergencyRisk(value: string) {
  const text = value.toLocaleLowerCase("ro-RO")
    .replace(/\b(?:fără|fara)\s+(?:niciun\s+|nicio\s+)?(?:fum|flacără|flacara|scântei|scantei|miros de gaz|scurgere de gaz)(?:\s*(?:sau|și|si)\s*(?:fum|flacără|flacara|scântei|scantei|miros de gaz|scurgere de gaz))*/gu, "")
    .replace(/\bnu\s+(?:există|exista|este|sunt|simt|se simte|miroase(?:\s+a)?)\s+(?:niciun\s+|nicio\s+)?(?:fum|flacără|flacara|scântei|scantei|miros de gaz|scurgere de gaz)(?:\s*(?:sau|și|si)\s*(?:fum|flacără|flacara|scântei|scantei|miros de gaz|scurgere de gaz))*/gu, "");
  return ["incendiu", "flacără", "flacara", "fum", "exploz", "miros de gaz", "scurgere de gaz", "electrocut", "scântei", "scantei", "rănit", "ranit", "sânger", "sanger", "inconștient", "inconstient", "nu respir", "durere în piept", "durere in piept", "suicid", "sinucid"].some((term) => text.includes(term));
}

const neighborBlockedTerms = ["gaz", "centrală", "centrala", "electric", "curent", "priz", "siguranț", "sigurant", "țeav", "teava", "scurger", "inunda", "robinet", "canaliz", "acoperiș", "acoperis", "scară înaltă", "scara inalta", "mașin", "masin", "motor", "tract", "frân", "fran", "medicament", "injecție", "injectie", "pansament", "îngrijire medicală", "ingrijire medicala", "copil singur", "babysit", "bonă", "bona", "bancomat", "card bancar", "cod pin", "împrumut bani", "imprumut bani", "retrage bani", "numerar", "baie asistată", "baie asistata", "casă goală", "casa goala", "apartament gol", "cheile de la casă", "cheile de la casa"];
const neighborAllowedTerms = ["cumpărăt", "cumparat", "magazin", "colet", "pachet", "ridic", "mut", "comod", "cuti", "mobilă mică", "mobila mica", "împrumut", "imprumut", "unealt", "bormaș", "bormas", "telefon", "laptop", "calculator", "imprimant", "wifi", "wi-fi", "internet", "aplicați", "aplicati", "setare", "document", "formular", "plant", "flori", "câine", "caine", "pisic", "animal", "etajer", "raft", "tablou", "șurub", "surub", "asambl", "montaj simplu", "traduc", "citit", "vecin", "ajutor digital"];

export function neighborSafetyCheck(value: string, category: string) {
  const text = value.toLocaleLowerCase("ro-RO");
  if (category !== "Altele") return { safe: false, reason: "Ajutorul de Vecin este disponibil momentan doar pentru sarcini simple din categoria Altele." };
  if (neighborBlockedTerms.some((term) => text.includes(term))) return { safe: false, reason: "Această sarcină poate implica un risc. Alege un prestator calificat sau serviciile de urgență potrivite." };
  if (!neighborAllowedTerms.some((term) => text.includes(term))) return { safe: false, reason: "Descrie o sarcină simplă: colet, obiect mic, plante, tehnologie sau un montaj ușor la nivelul solului." };
  return { safe: true, reason: "" };
}
