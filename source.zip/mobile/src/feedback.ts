import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

/**
 * Small, purposeful tactile acknowledgement for completed user actions.
 * We deliberately don't call this for scrolling, typing, polling, or every
 * touch: repeated feedback quickly becomes distracting in a marketplace app.
 */
export function triggerFeedback(kind: "selection" | "success" | "error" = "selection") {
  if (Platform.OS === "web") return;

  const action = kind === "success"
    ? Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)
    : kind === "error"
      ? Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error)
      : Haptics.selectionAsync();

  void action.catch(() => {
    // Haptics can be disabled by the device or unavailable in a simulator.
  });
}
