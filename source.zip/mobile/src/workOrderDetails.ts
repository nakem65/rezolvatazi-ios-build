const answerLabels: Record<string, Record<string, string>> = {
  transport_scope: {
    transport: "Doar transport",
    handling: "Doar ajutor fizic",
    both: "Transport și ajutor",
  },
  duration: {
    under_2h: "Durată: sub 2 ore",
    half_day: "Durată: jumătate de zi",
    full_day: "Durată: o zi",
    multiple_days: "Durată: mai multe zile",
  },
  safety_status: {
    safe: "Situație declarată stabilă",
  },
};

export function workOrderDetailChips(structuredDetailsJson?: string | null) {
  if (!structuredDetailsJson) return [];
  try {
    const parsed = JSON.parse(structuredDetailsJson) as { answers?: Record<string, unknown> };
    if (!parsed.answers || typeof parsed.answers !== "object") return [];
    const labelledAnswers = Object.entries(answerLabels).flatMap(([key, labels]) => {
      const answer = parsed.answers?.[key];
      if (typeof answer !== "string") return [];
      const label = labels[answer];
      return label ? [label] : [];
    });
    return [
      ...labelledAnswers,
      parsed.answers.price_negotiable === "yes" || parsed.answers.price_negotiable === true ? "BUGET NEGOCIABIL" : null,
    ].filter((value): value is string => Boolean(value));
  } catch {
    return [];
  }
}
