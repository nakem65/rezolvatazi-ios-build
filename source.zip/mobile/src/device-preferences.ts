import AsyncStorage from "@react-native-async-storage/async-storage";
import { Platform } from "react-native";

const biometricLockKey = "rezolvatazi_biometric_lock";
const inAppSoundsKey = "rezolvatazi_in_app_sounds";

type PreferenceListener = (enabled: boolean) => void;
const biometricLockListeners = new Set<PreferenceListener>();

export type BiometricAvailability = {
  available: boolean;
  label: "Face ID" | "Touch ID" | "Amprentă" | "Biometrie";
};

export async function getBiometricAvailability(): Promise<BiometricAvailability> {
  if (Platform.OS === "web") return { available: false, label: "Biometrie" };
  try {
    const LocalAuthentication = await import("expo-local-authentication");
    const [hasHardware, enrolled, types] = await Promise.all([
      LocalAuthentication.hasHardwareAsync(),
      LocalAuthentication.isEnrolledAsync(),
      LocalAuthentication.supportedAuthenticationTypesAsync(),
    ]);
    const label = types.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION)
      ? "Face ID"
      : Platform.OS === "ios" && types.includes(LocalAuthentication.AuthenticationType.FINGERPRINT)
        ? "Touch ID"
        : types.includes(LocalAuthentication.AuthenticationType.FINGERPRINT)
          ? "Amprentă"
          : "Biometrie";
    return { available: hasHardware && enrolled, label };
  } catch {
    return { available: false, label: "Biometrie" };
  }
}

export async function authenticateWithBiometrics() {
  const availability = await getBiometricAvailability();
  if (!availability.available) return { success: false as const, availability, error: "not_available" as const };
  try {
    const LocalAuthentication = await import("expo-local-authentication");
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: `Deblochează RezolvatAzi cu ${availability.label}`,
      cancelLabel: "Mai târziu",
      fallbackLabel: "Folosește codul telefonului",
      disableDeviceFallback: false,
      biometricsSecurityLevel: "strong",
    });
    return { ...result, availability };
  } catch {
    return { success: false as const, availability, error: "not_available" as const };
  }
}

export async function getBiometricLockEnabled() {
  return (await AsyncStorage.getItem(biometricLockKey)) === "true";
}

export async function setBiometricLockEnabled(enabled: boolean) {
  await AsyncStorage.setItem(biometricLockKey, enabled ? "true" : "false");
  biometricLockListeners.forEach((listener) => listener(enabled));
}

export function subscribeToBiometricLock(listener: PreferenceListener) {
  biometricLockListeners.add(listener);
  return () => { biometricLockListeners.delete(listener); };
}

export async function getInAppSoundsEnabled() {
  return (await AsyncStorage.getItem(inAppSoundsKey)) !== "false";
}

export async function setInAppSoundsEnabled(enabled: boolean) {
  await AsyncStorage.setItem(inAppSoundsKey, enabled ? "true" : "false");
}
