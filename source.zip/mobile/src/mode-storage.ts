import { Platform } from "react-native";
import { AppMode } from "./types";

const key = "rezolvatazi_active_mode";

export async function readStoredMode(): Promise<AppMode | null> {
  const value = Platform.OS === "web"
    ? (typeof localStorage === "undefined" ? null : localStorage.getItem(key))
    : await (await import("expo-secure-store")).getItemAsync(key);
  return value === "client" || value === "professional" ? value : null;
}

export async function storeMode(mode: AppMode) {
  if (Platform.OS === "web") { localStorage.setItem(key, mode); return; }
  await (await import("expo-secure-store")).setItemAsync(key, mode);
}
