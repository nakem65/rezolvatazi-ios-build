import { hasEmergencyRisk, inferCategory } from "./classify.ts";
import type { WorkSolutionKind } from "./types.ts";

export type { WorkSolutionKind } from "./types.ts";

export type WorkSolution = {
  kind: WorkSolutionKind;
  title: string;
  description: string;
};

export type WorkIntent = {
  ready: boolean;
  category: string;
  confidence: "scăzută" | "medie" | "ridicată";
  risk: "low" | "standard" | "regulated" | "emergency";
  summary: string;
  recommended: WorkSolutionKind;
  solutions: WorkSolution[];
  photoRecommended: boolean;
};

const recurringTerms = [
  "săptămân", "saptaman", "lunar", "în fiecare", "in fiecare", "periodic",
  "recurent", "abonament", "zilnic", "de două ori", "de doua ori",
];

const teamTerms = [
  "echip", "oameni", "persoane", "încărc", "incarc", "descărc", "descarc",
  "cărat", "carat", "mutare", "mutăm", "mutam", "greu", "moloz",
];

const hourlyTerms = [
  "pe oră", "pe ora", "lei/oră", "lei/ora", "câteva ore", "cateva ore",
  "ajutor", "muncitor", "manipul",
];

const fixedPriceTerms = ["preț total", "pret total", "preț fix", "pret fix", "la lucrare"];

const regulatedCategories = new Set([
  "Electrician",
  "Instalații sanitare",
  "Aer condiționat",
  "Lăcătuș",
]);

const photoFriendlyCategories = new Set([
  "Electrician",
  "Instalații sanitare",
  "Aer condiționat",
  "Lăcătuș",
  "Electrocasnice",
  "Montaj & reparații mici",
  "Mutări & manipulare",
  "Curte & grădină",
]);

const solutionCopy: Record<WorkSolutionKind, Omit<WorkSolution, "kind">> = {
  quotes: {
    title: "Primesc oferte",
    description: "Compar prețul, timpul și ratingurile înainte să aleg.",
  },
  hourly: {
    title: "Ajutor la oră",
    description: "Caut persoane disponibile și plătesc timpul lucrat.",
  },
  team: {
    title: "Formez o echipă",
    description: "Aleg câte persoane sunt necesare pentru aceeași lucrare.",
  },
  recurring: {
    title: "Se repetă periodic",
    description: "Cer o ofertă pentru o lucrare săptămânală sau lunară.",
  },
  assessment: {
    title: "Constatare întâi",
    description: "Un profesionist verifică problema înainte de prețul final.",
  },
};

function includesAny(text: string, terms: string[]) {
  return terms.some((term) => text.includes(term));
}

function asSolution(kind: WorkSolutionKind): WorkSolution {
  return { kind, ...solutionCopy[kind] };
}

function uniqueSolutions(kinds: WorkSolutionKind[]) {
  return [...new Set(kinds)].slice(0, 3).map(asSolution);
}

export function analyzeWorkIntent(description: string): WorkIntent {
  const normalized = description.trim().toLocaleLowerCase("ro-RO");
  const ready = normalized.length >= 8;
  const category = inferCategory(description);
  const emergency = hasEmergencyRisk(description);
  const recurring = includesAny(normalized, recurringTerms);
  const team = includesAny(normalized, teamTerms);
  const hourly = includesAny(normalized, hourlyTerms);
  const fixedPrice = includesAny(normalized, fixedPriceTerms);
  const regulated = regulatedCategories.has(category);

  let recommended: WorkSolutionKind = "quotes";
  let kinds: WorkSolutionKind[] = ["quotes", "hourly", "team"];

  if (emergency) {
    kinds = [];
  } else if (regulated) {
    recommended = "assessment";
    kinds = ["assessment", "quotes"];
  } else if (recurring) {
    recommended = "recurring";
    kinds = ["recurring", "quotes", "hourly"];
  } else if (team) {
    recommended = "team";
    kinds = ["team", "hourly", "quotes"];
  } else if (fixedPrice) {
    recommended = "quotes";
    kinds = ["quotes", "hourly", "team"];
  } else if (hourly) {
    recommended = "hourly";
    kinds = ["hourly", "quotes", "team"];
  } else if (category === "Curățenie & dăunători" || category === "Curte & grădină") {
    recommended = "quotes";
    kinds = ["quotes", "hourly", "recurring"];
  }

  const risk: WorkIntent["risk"] = emergency
    ? "emergency"
    : regulated
      ? "regulated"
      : category === "Altele"
        ? "standard"
        : "low";

  const confidence: WorkIntent["confidence"] = category === "Altele"
    ? "scăzută"
    : normalized.length >= 24
      ? "ridicată"
      : "medie";

  return {
    ready,
    category,
    confidence,
    risk,
    // The requester's own words are the only safe default summary. A generic
    // category sentence used to replace a perfectly good request such as
    // "am nevoie să tund iarba", which made the review screen feel broken.
    // Remote analysis can still provide optional classification metadata, but
    // it must never overwrite the work the person described.
    summary: description.trim(),
    recommended,
    solutions: uniqueSolutions(kinds),
    photoRecommended: photoFriendlyCategories.has(category),
  };
}
