import AsyncStorage from "@react-native-async-storage/async-storage";
import { requestJson } from "./api/core";

const draftVersion = 1;
const storagePrefix = "rezolvatazi:new-request-draft:v1";

function storageKey(ownerId?: string | null) {
  return `${storagePrefix}:${ownerId?.trim() || "anonymous"}`;
}

type DraftEnvelope<T> = {
  version: number;
  savedAt: string;
  data: T;
};

type DraftTombstone = {
  cleared: true;
  operationAt: string;
};

export type DraftLoadResult<T> =
  | { status: "loaded"; draft: T | null }
  | { status: "unavailable"; draft: null };

let lastMutationTime = 0;
const localMutationQueues = new Map<string, Promise<void>>();

function nextMutationTime() {
  const time = Math.max(Date.now(), lastMutationTime + 1);
  lastMutationTime = time;
  return new Date(time).toISOString();
}

async function mutateLocalDraft(key: string, mutation: () => Promise<void>) {
  const previous = localMutationQueues.get(key) ?? Promise.resolve();
  const next = previous.catch(() => undefined).then(mutation);
  localMutationQueues.set(key, next);
  try {
    await next;
  } finally {
    if (localMutationQueues.get(key) === next) localMutationQueues.delete(key);
  }
}

function parseEnvelope<T>(serialized: string): DraftEnvelope<T> | null {
  try {
    const parsed = JSON.parse(serialized) as DraftEnvelope<T>;
    if (parsed.version !== draftVersion || !parsed.data) return null;
    return parsed;
  } catch {
    return null;
  }
}

function parseTombstone(serialized: string): DraftTombstone | null {
  try {
    const parsed = JSON.parse(serialized) as Partial<DraftTombstone>;
    return parsed.cleared === true && typeof parsed.operationAt === "string"
      ? { cleared: true, operationAt: parsed.operationAt }
      : null;
  } catch {
    return null;
  }
}

async function removeLocalValueIfUnchanged(key: string, serialized: string) {
  await mutateLocalDraft(key, async () => {
    if (await AsyncStorage.getItem(key) === serialized) await AsyncStorage.removeItem(key);
  });
}

export async function loadRequestDraft<T>(ownerId?: string | null): Promise<DraftLoadResult<T>> {
  try {
    const key = storageKey(ownerId);
    let serialized = await AsyncStorage.getItem(key);
    const tombstone = serialized ? parseTombstone(serialized) : null;
    if (serialized && tombstone) {
      if (ownerId) {
        try {
          await requestJson<{ ok: true }>("/api/request-draft", {
            method: "DELETE",
            body: JSON.stringify({ operationAt: tombstone.operationAt }),
          });
          await removeLocalValueIfUnchanged(key, serialized);
        } catch {
          // Keep the pending deletion and never download the older server draft.
        }
      }
      return { status: "loaded", draft: null };
    }
    if (serialized && !parseEnvelope<T>(serialized)) {
      await AsyncStorage.removeItem(key);
      serialized = null;
    }
    if (!serialized && ownerId) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 2_500);
      try {
        const remote = await requestJson<{ draft: DraftEnvelope<T> | null }>("/api/request-draft", { signal: controller.signal });
        serialized = remote.draft ? JSON.stringify(remote.draft) : null;
        if (serialized) await AsyncStorage.setItem(storageKey(ownerId), serialized);
      } catch {
        return { status: "unavailable", draft: null };
      } finally {
        clearTimeout(timeout);
      }
    }
    if (!serialized) return { status: "loaded", draft: null };
    const parsed = parseEnvelope<T>(serialized);
    return { status: "loaded", draft: parsed?.data ?? null };
  } catch {
    return { status: "unavailable", draft: null };
  }
}

export async function saveRequestDraft<T>(data: T, ownerId?: string | null): Promise<boolean> {
  const savedAt = nextMutationTime();
  const key = storageKey(ownerId);
  const serialized = JSON.stringify({
    version: draftVersion,
    savedAt,
    data,
  } satisfies DraftEnvelope<T>);
  try {
    await mutateLocalDraft(key, () => AsyncStorage.setItem(key, serialized));
    if (ownerId) {
      try {
        await requestJson<{ ok: true }>("/api/request-draft", {
          method: "PUT",
          body: JSON.stringify({ draft: JSON.parse(serialized) as DraftEnvelope<T> }),
        });
      } catch {
        // The local draft remains available and can sync on the next edit.
      }
    }
    return true;
  } catch {
    // Draft persistence must never block the request flow.
    return false;
  }
}

export async function clearRequestDraft(ownerId?: string | null): Promise<void> {
  const operationAt = nextMutationTime();
  const key = storageKey(ownerId);
  if (!ownerId) {
    try {
      await mutateLocalDraft(key, () => AsyncStorage.removeItem(key));
    } catch {
      // A stale anonymous draft is preferable to blocking navigation.
    }
    return;
  }
  const serialized = JSON.stringify({ cleared: true, operationAt } satisfies DraftTombstone);
  try {
    await mutateLocalDraft(key, () => AsyncStorage.setItem(key, serialized));
  } catch {
    // Continue with the authenticated server deletion even if local storage fails.
  }
  try {
    await requestJson<{ ok: true }>("/api/request-draft", {
      method: "DELETE",
      body: JSON.stringify({ operationAt }),
    });
    await removeLocalValueIfUnchanged(key, serialized);
  } catch {
    // The local tombstone retries this deletion after the account signs in again.
  }
}

export async function clearAllRequestDrafts(): Promise<void> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const draftKeys = keys.filter((key) => key.startsWith(`${storagePrefix}:`));
    if (draftKeys.length) {
      await Promise.all(draftKeys.map((key) => mutateLocalDraft(key, async () => {
        const serialized = await AsyncStorage.getItem(key);
        if (!serialized || !parseTombstone(serialized)) await AsyncStorage.removeItem(key);
      })));
    }
  } catch {
    // Signing out must continue even if local storage is unavailable.
  }
}
