const rawUrl = process.env.EXPO_PUBLIC_API_URL?.trim().replace(/\/$/, "");
const captureDemo = process.env.EXPO_PUBLIC_DEMO_MODE === "1";
// Buildurile distribuite primesc URL-ul public din mediul EAS. În dezvoltare
// păstrăm explicit URL-ul local pentru a nu scrie accidental în producție.
export const configuredUrl = captureDemo ? "" : (rawUrl || "https://rezolvatazi.ro");
export let sessionToken = "";

// The distributable app always targets the production API. Demo fixtures are
// never mixed into a signed-in user's real feed.
export const apiConfigured = Boolean(configuredUrl);

export type ApiRequestInit = RequestInit & {
  /** SMS verification can take longer than normal API reads. */
  timeoutMs?: number;
};
export const apiMode: "demo" | "live" = apiConfigured ? "live" : "demo";

export function setSessionToken(token: string | null) {
  sessionToken = token ?? "";
}

export async function requestJson<T>(path: string, init?: ApiRequestInit): Promise<T> {
  if (!configuredUrl) throw new Error("API_URL_MISSING");
  const { timeoutMs = 8_000, ...requestInit } = init ?? {};
  const controller = new AbortController();
  const externalSignal = requestInit.signal;
  const abortFromCaller = () => controller.abort();
  if (externalSignal?.aborted) controller.abort();
  else externalSignal?.addEventListener("abort", abortFromCaller, { once: true });
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${configuredUrl}${path}`, {
      ...requestInit,
      signal: controller.signal,
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...(sessionToken ? { Authorization: `Bearer ${sessionToken}` } : {}),
        ...requestInit.headers,
      },
    });
    let payload: T & { error?: string };
    try {
      payload = (await response.json()) as T & { error?: string };
    } catch {
      const error = new Error(response.ok
        ? "Răspunsul serviciului nu a putut fi citit. Încearcă din nou."
        : `Serviciul nu a putut răspunde corect (${response.status}). Încearcă din nou.`) as Error & { status?: number };
      error.status = response.status;
      throw error;
    }
    if (!response.ok) {
      const error = new Error(payload.error ?? `HTTP ${response.status}`) as Error & { status?: number };
      error.status = response.status;
      throw error;
    }
    return payload;
  } catch (err) {
    if (err instanceof Error && err.message === 'API_URL_MISSING') throw err;
    if (externalSignal?.aborted) {
      const aborted = new Error("REQUEST_ABORTED");
      aborted.name = "AbortError";
      throw aborted;
    }
    if (err instanceof Error && (err.name === "AbortError" || /aborted|timeout/i.test(err.message))) {
      throw new Error("Conexiunea a durat prea mult. Verifică internetul și încearcă din nou.");
    }
    if (err instanceof Error && /fetch failed|network request failed|network error/i.test(err.message)) {
      throw new Error("Nu am putut contacta serviciul de autentificare. Verifică internetul și încearcă din nou.");
    }
    console.warn(`[API] Network error for ${path}:`, err);
    const error = new Error(err instanceof Error && err.message ? err.message : 'NETWORK_FALLBACK');
    throw error;
  } finally {
    clearTimeout(timeout);
    externalSignal?.removeEventListener("abort", abortFromCaller);
  }
}
