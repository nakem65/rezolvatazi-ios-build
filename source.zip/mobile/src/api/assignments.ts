import type { OfferAssignmentMember, WorkAssignment } from "../types";
import { requestJson } from "./core";

export async function fetchOfferAssignments(offerId: string) {
  return requestJson<{ canAssign: boolean; members: OfferAssignmentMember[] }>(`/api/offers/${encodeURIComponent(offerId)}/assignments`);
}

export async function assignOfferMember(offerId: string, memberAccountId: string) {
  return requestJson<{ assignment: { id: string; status: "assigned" | "accepted" } }>(`/api/offers/${encodeURIComponent(offerId)}/assignments`, {
    method: "POST",
    body: JSON.stringify({ memberAccountId }),
  });
}

export async function fetchWorkAssignments() {
  return requestJson<{ assignments: WorkAssignment[] }>("/api/work-assignments");
}

export async function acceptWorkAssignment(id: string) {
  return requestJson<{ assignment: { id: string; status: "accepted" } }>(`/api/work-assignments/${encodeURIComponent(id)}/accept`, {
    method: "POST",
  });
}
