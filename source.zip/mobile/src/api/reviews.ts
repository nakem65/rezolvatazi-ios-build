import { Review } from '../types';
import { requestJson, configuredUrl } from './core';

export function reportRequest(requestId: string, reason: 'unsafe_task' | 'harassment' | 'spam' | 'misleading' | 'other' = 'unsafe_task', block = true) {
  try {
    return requestJson<{ report: { id: string; status: string }; blocked: boolean }>('/api/reports', { method: 'POST', body: JSON.stringify({ requestId, reason, block }) });
  } catch (e) { if (configuredUrl) throw e;
    return Promise.resolve({ report: { id: 'demo-report', status: 'open' }, blocked: block });
  }
}

export function reportProvider(requestId: string, targetProviderId: string, reason: 'harassment' | 'spam' | 'misleading' | 'other' = 'misleading', block = true) {
  try {
    return requestJson<{ report: { id: string; status: string }; blocked: boolean }>('/api/reports', { method: 'POST', body: JSON.stringify({ requestId, targetProviderId, reason, block }) });
  } catch (e) { if (configuredUrl) throw e;
    return Promise.resolve({ report: { id: 'demo-report', status: 'open' }, blocked: block });
  }
}

export async function rateRequest(requestId: string, score: number, comment: string, mediaUrls?: string[], providerId?: string) {
  try {
    return await requestJson<{ rating: Review }>(`/api/customer/requests/${encodeURIComponent(requestId)}/rating`, { method: 'POST', body: JSON.stringify({ score, comment, mediaUrls, providerId }) });
  } catch (e) { if (configuredUrl) throw e;
    return { rating: { id: 'rating-' + Date.now(), requestId, reviewerId: 'me', reviewerName: 'Client', targetId: 'prov', targetName: 'Prestator', score, comment, mediaUrls, createdAt: new Date().toISOString() } as Review };
  }
}

export async function rateClient(offerId: string, score: number, comment: string, mediaUrls?: string[]) {
  try {
    return await requestJson<{ rating: Review }>(`/api/provider/offers/${encodeURIComponent(offerId)}/rating`, { method: 'POST', body: JSON.stringify({ score, comment, mediaUrls }) });
  } catch (e) { if (configuredUrl) throw e;
    return { rating: { id: 'rating-' + Date.now(), requestId: 'req1', reviewerId: 'me', reviewerName: 'Prestator', targetId: 'client', targetName: 'Client', score, comment, mediaUrls, createdAt: new Date().toISOString() } as Review };
  }
}

export async function fetchProviderReviews(providerId: string, profileId?: string): Promise<Review[]> {
  try {
    const profileQuery = profileId ? `?profileId=${encodeURIComponent(profileId)}` : "";
    const payload = await requestJson<{ reviews: Review[] }>(`/api/provider/${encodeURIComponent(providerId)}/reviews${profileQuery}`);
    return payload.reviews;
  } catch (e) { if (configuredUrl) throw e;
    return [];
  }
}

export async function fetchAccountProfileReviews(accountProfileId: string, role: "client" | "provider"): Promise<Review[]> {
  try {
    const query = new URLSearchParams({ accountProfileId, role }).toString();
    const payload = await requestJson<{ reviews: Review[] }>(`/api/provider/me/reviews?${query}`);
    return payload.reviews;
  } catch (e) { if (configuredUrl) throw e;
    return [];
  }
}

export async function replyToReview(reviewId: string, replyText: string, replyPhotoUrl?: string, replyVideoUrl?: string) {
  try {
    return await requestJson<{ success: boolean }>(`/api/reviews/${encodeURIComponent(reviewId)}/reply`, { method: 'POST', body: JSON.stringify({ replyText, replyPhotoUrl, replyVideoUrl }) });
  } catch (e) { if (configuredUrl) throw e;
    return { success: true };
  }
}
