import { configuredUrl, requestJson, sessionToken } from "./core";

export type SupportAttachment = {
  uri: string;
  name: string;
  mimeType: string;
};

export async function uploadSupportAttachment(file: SupportAttachment) {
  if (!configuredUrl || !sessionToken) throw new Error("Intră în cont înainte de a adăuga fișiere.");
  const form = new FormData();
  form.append("file", {
    uri: file.uri,
    name: file.name,
    type: file.mimeType,
  } as unknown as Blob);
  const response = await fetch(`${configuredUrl}/api/support/attachments`, {
    method: "POST",
    headers: { Authorization: `Bearer ${sessionToken}` },
    body: form,
  });
  const payload = await response.json() as { attachment?: { key: string }; error?: string };
  if (!response.ok || !payload.attachment) throw new Error(payload.error || "Fișierul nu a putut fi încărcat.");
  return payload.attachment;
}

export function createSupportTicket(input: {
  category: string;
  message: string;
  attachmentKeys: string[];
}) {
  return requestJson<{ ticket: { id: string; code: string; status: string } }>("/api/support/tickets", {
    method: "POST",
    body: JSON.stringify(input),
  });
}
