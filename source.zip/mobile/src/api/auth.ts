import { Provider } from '../types';
import { demoProvider } from '../demo';
import { requestJson, configuredUrl } from './core';

export async function requestLoginCode(phone: string) {
  try {
    return await requestJson<{ ok: true; phone: string; note?: string; retryAfterSeconds?: number }>('/api/auth/request-code', {
      method: 'POST',
      body: JSON.stringify({ phone }),
      // Twilio Verify may need a few seconds to hand the SMS to the carrier.
      timeoutMs: 20_000,
    });
  } catch (e) { if (configuredUrl) throw e;
    return { ok: true as const, phone };
  }
}

export async function verifyLoginCode(phone: string, code: string) {
  try {
    return await requestJson<{ token: string; provider: Provider }>('/api/auth/verify-code', {
      method: 'POST',
      body: JSON.stringify({ phone, code }),
      // Verification reaches the same carrier/Twilio path as sending the code.
      timeoutMs: 20_000,
    });
  } catch (e) { if (configuredUrl) throw e;
    return { token: 'demo-token-' + Date.now(), provider: { ...demoProvider, phone } };
  }
}

export async function logoutProvider() {
  if (!configuredUrl) return;
  try { await requestJson<{ ok: true }>('/api/auth/logout', { method: 'DELETE' }); } catch (e) { if (configuredUrl) throw e;}
}
