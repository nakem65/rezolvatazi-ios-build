import type { ChatInboxConversation, ChatMessage } from "../types";
import type { PickedMediaAsset } from "../mediaPicker";
import { requestJson, configuredUrl, sessionToken } from "./core";

export type ChatSyncResult = {
  messages: ChatMessage[];
  viewerId: string;
  serverTime: string;
  readOnly?: boolean;
  readOnlyReason?: string | null;
};

export type ChatInboxResult = {
  conversations: ChatInboxConversation[];
  totalUnread: number;
  serverTime: string;
};

export async function fetchChatInbox(): Promise<ChatInboxResult> {
  try {
    return await requestJson<ChatInboxResult>("/api/chat/inbox");
  } catch (caught) {
    if (configuredUrl) throw caught;
    return { conversations: [], totalUnread: 0, serverTime: new Date().toISOString() };
  }
}

export type UploadedChatAttachment = {
  id: string;
  mediaType: "image" | "video" | "audio";
  contentType: string;
  sizeBytes: number;
  url: string;
};

function chatQuery(requestId: string, offerId?: string | null, after?: string | null) {
  const params = new URLSearchParams({ requestId });
  if (offerId) params.set("offerId", offerId);
  if (after) params.set("after", after);
  return params.toString();
}

export async function fetchChatMessages(requestId: string, offerId?: string | null, after?: string | null): Promise<ChatSyncResult> {
  try {
    return await requestJson<ChatSyncResult>(`/api/chat?${chatQuery(requestId, offerId, after)}`);
  } catch (caught) {
    if (configuredUrl) throw caught;
    return {
      viewerId: "demo-provider",
      serverTime: new Date().toISOString(),
      messages: [
        {
          id: "msg-demo-1",
          requestId,
          offerId,
          senderName: "Instal Rapid 24",
          senderRole: "professional",
          senderId: "demo-professional",
          content: "Salut! Am plecat spre tine. Puteți opri robinetul general până ajung?",
          createdAt: new Date(Date.now() - 12 * 60_000).toISOString(),
        },
        {
          id: "msg-demo-2",
          requestId,
          offerId,
          senderName: "Eu (Client)",
          senderRole: "client",
          senderId: "demo-provider",
          content: "Salut! Am oprit robinetul și vă aștept.",
          readByCount: 1,
          createdAt: new Date(Date.now() - 5 * 60_000).toISOString(),
        },
      ],
    };
  }
}

export async function sendChatMessage(input: {
  requestId: string;
  offerId?: string | null;
  content?: string;
  attachmentId?: string;
  isPriceProposal?: boolean;
  proposedPrice?: number;
  replyToMessageId?: string;
  clientNonce: string;
}): Promise<ChatMessage> {
  try {
    const payload = await requestJson<{ message: ChatMessage }>("/api/chat", {
      method: "POST",
      body: JSON.stringify(input),
    });
    return payload.message;
  } catch (caught) {
    if (configuredUrl) throw caught;
    return {
      id: `msg-${Date.now()}`,
      requestId: input.requestId,
      offerId: input.offerId,
      senderName: "Eu",
      senderRole: "client",
      senderId: "demo-provider",
      content: input.content ?? "",
      attachmentId: input.attachmentId,
      replyToMessageId: input.replyToMessageId,
      isPriceProposal: input.isPriceProposal,
      proposedPrice: input.proposedPrice,
      proposalStatus: input.isPriceProposal ? "pending" : undefined,
      clientNonce: input.clientNonce,
      createdAt: new Date().toISOString(),
    };
  }
}

export async function uploadChatAttachment(
  requestId: string,
  offerId: string | null | undefined,
  asset: PickedMediaAsset,
): Promise<UploadedChatAttachment> {
  if (!configuredUrl) {
    return {
      id: `attachment-${Date.now()}`,
      mediaType: asset.mediaType,
      contentType: asset.type,
      sizeBytes: 1,
      url: asset.uri,
    };
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 60_000);
  try {
    const form = new FormData();
    form.append("requestId", requestId);
    if (offerId) form.append("offerId", offerId);
    const localResponse = await fetch(asset.uri);
    if (!localResponse.ok) throw new Error("Fișierul selectat nu a mai putut fi citit. Alege-l din nou.");
    const sourceBlob = await localResponse.blob();
    // iOS may return an empty Blob MIME type for a Photos/file URI. Preserve
    // the picker MIME type so the server can validate the actual bytes.
    const blob = sourceBlob.type === asset.type
      ? sourceBlob
      : new Blob([sourceBlob], { type: asset.type || sourceBlob.type });
    const maximumBytes = asset.mediaType === "video"
      ? 35 * 1024 * 1024
      : asset.mediaType === "audio"
        ? 12 * 1024 * 1024
        : 8 * 1024 * 1024;
    if (blob.size < 1 || blob.size > maximumBytes) {
      const limitMb = Math.round(maximumBytes / 1024 / 1024);
      throw new Error(`Fișierul trebuie să aibă cel mult ${limitMb} MB.`);
    }
    form.append("file", blob, asset.name);
    const response = await fetch(`${configuredUrl}/api/chat/attachments`, {
      method: "POST",
      signal: controller.signal,
      credentials: "include",
      headers: sessionToken ? { Authorization: `Bearer ${sessionToken}` } : undefined,
      body: form,
    });
    const payload = await response.json().catch(() => ({})) as { attachment?: UploadedChatAttachment; error?: string };
    if (!response.ok || !payload.attachment) throw new Error(payload.error || "Fișierul nu a putut fi încărcat.");
    return payload.attachment;
  } catch (caught) {
    if (controller.signal.aborted) throw new Error("Încărcarea a durat prea mult. Verifică internetul și încearcă din nou.");
    if (caught instanceof Error && /network request failed|fetch failed|network error/i.test(caught.message)) {
      throw new Error("Fișierul nu a putut fi încărcat. Verifică internetul și încearcă din nou.");
    }
    throw caught;
  } finally {
    clearTimeout(timeout);
  }
}

export function authenticatedChatMediaSource(path: string) {
  const uri = /^https?:\/\//i.test(path) ? path : `${configuredUrl}${path}`;
  return {
    uri,
    headers: sessionToken ? { Authorization: `Bearer ${sessionToken}` } : undefined,
  };
}

export async function deleteChatMessage(messageId: string): Promise<{ ok: true }> {
  try {
    return await requestJson<{ ok: true }>(`/api/chat/${encodeURIComponent(messageId)}`, { method: "DELETE" });
  } catch (caught) {
    if (configuredUrl) throw caught;
    return { ok: true };
  }
}

export async function reportChatParticipant(input: {
  requestId: string;
  offerId?: string | null;
  targetProviderId: string;
  block: boolean;
  details?: string;
}) {
  return requestJson<{ report: { id: string; status: string }; blocked: boolean }>("/api/reports", {
    method: "POST",
    body: JSON.stringify({
      ...input,
      reason: "harassment",
    }),
  });
}
