import type { WorkSolutionKind } from "../types";
import { requestJson } from "./core";

export type RemoteIntentClarification = {
  id: string;
  prompt: string;
  helpText?: string;
  type: "single_choice" | "number" | "short_text";
  options?: Array<{ value: string; label: string }>;
};

export type RemoteIntentAnalysis = {
  ready: boolean;
  emergency: boolean;
  intentSummary: string;
  categoryId: string;
  confidence: "scăzută" | "medie" | "ridicată";
  riskClass: "low" | "standard" | "regulated" | "emergency";
  templateId: string;
  missingFields: string[];
  eligibleSolutions: Array<{
    kind: WorkSolutionKind;
    title: string;
    description: string;
  }>;
  recommendedSolution: WorkSolutionKind | null;
  clarification: RemoteIntentClarification | null;
  reasonCodes: string[];
  photoRecommended: boolean;
  inferredParticipants?: number;
  suggestedUrgency: "Acum" | "Astăzi" | "În 24 de ore" | null;
  suggestedRecurrence: { value: string; label: string } | null;
  analysisVersion: string;
};

export type RemoteIntentAnswer = string | number | boolean;

export function analyzeWorkIntentRemote(
  input: {
    description: string;
    selectedCategory?: string;
    selectedSolution?: WorkSolutionKind;
    answers?: Record<string, RemoteIntentAnswer>;
  },
  signal?: AbortSignal,
) {
  return requestJson<{ analysis: RemoteIntentAnalysis }>("/api/v2/work-intent", {
    method: "POST",
    body: JSON.stringify(input),
    signal,
  }).then((result) => result.analysis);
}
