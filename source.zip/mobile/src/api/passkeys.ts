import * as Passkeys from "react-native-passkeys";
import { Platform } from "react-native";
import { configuredUrl, requestJson } from "./core";
import { Provider } from "../types";

type RegistrationOptions = { challengeId: string; options: Parameters<typeof Passkeys.create>[0]; nativeReady?: boolean };
type AuthenticationOptions = { challengeId: string; options: Parameters<typeof Passkeys.get>[0]; nativeReady?: boolean };

export function passkeysSupported() {
  try { return Boolean(configuredUrl) && Passkeys.isSupported(); } catch { return false; }
}

export async function registerDevicePasskey(label: string) {
  if (!passkeysSupported()) throw new Error("Acest dispozitiv nu poate crea încă o passkey. Folosește SMS-ul pentru conectare.");
  const setup = await requestJson<RegistrationOptions>("/api/auth/passkey/register/options", { method: "POST", body: JSON.stringify({ platform: Platform.OS }) });
  if (!setup.nativeReady) throw new Error("Passkey-ul pentru aplicația mobilă se activează după verificarea asocierii sigure a aplicației. Poți folosi SMS-ul până atunci.");
  const response = await Passkeys.create(setup.options);
  if (!response) throw new Error("Crearea passkey-ului a fost anulată.");
  await requestJson<{ ok: true }>("/api/auth/passkey/register/verify", {
    method: "POST",
    body: JSON.stringify({ challengeId: setup.challengeId, response, label }),
  });
}

export async function signInWithDevicePasskey() {
  if (!passkeysSupported()) throw new Error("Acest dispozitiv nu poate folosi o passkey. Conectează-te prin SMS.");
  const setup = await requestJson<AuthenticationOptions>("/api/auth/passkey/authenticate/options", { method: "POST", body: JSON.stringify({ platform: Platform.OS }) });
  if (!setup.nativeReady) throw new Error("Conectarea cu passkey se activează după verificarea asocierii sigure a aplicației. Folosește SMS-ul pentru moment.");
  const response = await Passkeys.get(setup.options);
  if (!response) throw new Error("Conectarea cu passkey a fost anulată.");
  return await requestJson<{ token: string; provider: Provider }>("/api/auth/passkey/authenticate/verify", {
    method: "POST",
    body: JSON.stringify({ challengeId: setup.challengeId, response }),
  });
}
