import { AppMode, ServiceRequest, RequestDraft, MyRequest, MyRequestDetail, StructuredWorkOrder } from '../types';
import { demoRequests } from '../demo';
import { requestJson, configuredUrl } from './core';
import { getDemoAcceptedOffers } from './offers';

export async function fetchOpenRequests(mode: Exclude<AppMode, 'client'> = 'professional'): Promise<ServiceRequest[]> {
  const mocks = demoRequests.filter((request) => request.requestMode === mode);
  try {
    const payload = await requestJson<{ requests: ServiceRequest[] }>(`/api/requests?mode=${mode}`);
    return payload.requests;
  } catch (e) { if (configuredUrl) throw e;
    return mocks;
  }
}

export async function fetchRequestById(id: string, earningProfileId?: string) {
  try {
    const query = earningProfileId ? `?earningProfileId=${encodeURIComponent(earningProfileId)}` : "";
    const payload = await requestJson<{ request: ServiceRequest }>(`/api/requests/${encodeURIComponent(id)}${query}`);
    return payload.request;
  } catch (e) { if (configuredUrl) throw e;
    const request = demoRequests.find((item) => item.id === id) ?? demoRequests[0];
    return request;
  }
}

export async function createRequest(draft: RequestDraft) {
  try {
    return await requestJson<{ request: ServiceRequest; workOrder?: StructuredWorkOrder; dispatch: { matchedProviders: number; notificationsQueued: number } }>('/api/requests', { method: 'POST', body: JSON.stringify(draft) });
  } catch (e) { if (configuredUrl) throw e;
    const newReq: ServiceRequest = {
      id: 'req-' + Date.now(),
      description: draft.description,
      category: draft.category,
      urgency: draft.urgency,
      city: draft.city,
      locationLabel: draft.locationLabel,
      contactName: 'Eu (Client)',
      contactPhone: '0722 123 456',
      status: 'open',
      selectedOfferId: null,
      requestMode: draft.requestMode,
      clientPrice: draft.clientPrice,
      latitude: draft.latitude,
      longitude: draft.longitude,
      photos: draft.photos ?? [],
      requiredParticipants: draft.requiredParticipants,
      acceptedParticipantIds: [],
      isDemo: true,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 86400000).toISOString(),
    };
    return { request: newReq, dispatch: { matchedProviders: 2, notificationsQueued: 2 } };
  }
}

export type RequestShare = {
  url: string;
  text: string;
  preview: {
    title: string;
    category: string;
    area: string | null;
    when: string;
    teamSize: number | null;
    budgetLabel: string | null;
  };
};

export async function createRequestShare(requestId: string) {
  return requestJson<{ share: RequestShare }>(`/api/requests/${encodeURIComponent(requestId)}/share`, {
    method: "POST",
    body: JSON.stringify({ confirmed: true }),
  });
}

export async function revokeRequestShare(requestId: string) {
  return requestJson<{ ok: true }>(`/api/requests/${encodeURIComponent(requestId)}/share`, { method: "DELETE" });
}

export async function fetchMyRequests(): Promise<MyRequest[]> {
  try {
    const payload = await requestJson<{ requests: MyRequest[] }>('/api/customer/requests');
    return payload.requests;
  } catch (e) { if (configuredUrl) throw e;
    const demoMyRequests: MyRequest[] = [
      {
        id: 'demo-1',
        description: 'Curge apă de sub chiuvetă în baie și nu reușesc să opresc robinetul colț.',
        category: 'Instalații Sanitare',
        city: 'București',
        urgency: 'Acum',
        contactName: 'Client verificat',
        contactPhone: '0722 123 456',
        status: 'open',
        selectedOfferId: null,
        requestMode: 'professional',
        clientPrice: 150,
        latitude: 44.4268,
        longitude: 26.1025,
        photos: [],
        isDemo: true,
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 86400000).toISOString(),
        offerCount: 2,
      }
    ];
    return demoMyRequests;
  }
}

export function fetchMyRequest(id: string) {
  if (id === 'demo-1' || !configuredUrl) {
    return Promise.resolve({
      request: {
        id: 'demo-1',
        description: 'Curge apă de sub chiuvetă în baie și nu reușesc să opresc robinetul colț.',
        category: 'Instalații Sanitare',
        city: 'București',
        urgency: 'Acum',
        clientPrice: 150,
        latitude: 44.4268,
        longitude: 26.1025,
        status: getDemoAcceptedOffers().size > 0 ? 'matched' : 'open',
        createdAt: new Date().toISOString(),
        requestMode: 'professional'
      },
      offers: [
        {
          id: 'offer-1',
          providerId: 'prov-1',
          providerName: 'Mihai Stanciu',
          providerTrustLabel: 'Telefon confirmat',
          providerRating: 49,
          providerReviewCount: 128,
          price: 250,
          etaMinutes: 20,
          priceType: 'fixed',
          visitFee: 0,
          materialsIncluded: true,
          message: 'Am piese pe stoc și pot pleca imediat spre tine. Prețul include constatarea și manopera.',
          selected: getDemoAcceptedOffers().has('offer-1')
        },
        {
          id: 'offer-2',
          providerId: 'prov-2',
          providerName: 'Alexandru D.',
          providerTrustLabel: 'Telefon confirmat',
          providerRating: 48,
          providerReviewCount: 45,
          price: 200,
          etaMinutes: 45,
          priceType: 'estimate',
          visitFee: 50,
          materialsIncluded: false,
          message: 'Sunt disponibil după ora 16:00.',
          selected: getDemoAcceptedOffers().has('offer-2')
        }
      ]
    } as unknown as MyRequestDetail);
  }
  return requestJson<MyRequestDetail>(`/api/customer/requests/${encodeURIComponent(id)}`);
}

export async function cancelRequest(requestId: string) {
  try {
    return await requestJson<{ request: ServiceRequest }>(`/api/customer/requests/${encodeURIComponent(requestId)}`, { method: 'DELETE' });
  } catch (e) { if (configuredUrl) throw e;
    return { request: { id: requestId, status: 'cancelled' } as unknown as ServiceRequest };
  }
}

export async function republishRequest(requestId: string) {
  return requestJson<{ request: ServiceRequest; workOrder?: StructuredWorkOrder; dispatch: { matchedProviders: number; notificationsQueued: number } }>(`/api/customer/requests/${encodeURIComponent(requestId)}/republish`, { method: "POST" });
}

export async function updateRequestStatus(requestId: string, action: 'complete' | 'complete_cycle' | 'cancel_after_match' | 'no_show' | 'dispute', targetProviderId?: string) {
  try {
    return await requestJson<{ request: ServiceRequest }>(`/api/customer/requests/${encodeURIComponent(requestId)}`, { method: 'PATCH', body: JSON.stringify({ action, targetProviderId }) });
  } catch (e) { if (configuredUrl) throw e;
    const statusMap = { complete: 'completed', complete_cycle: 'matched', cancel_after_match: 'cancelled_after_match', no_show: 'no_show', dispute: 'disputed' };
    return { request: { id: requestId, status: statusMap[action] ?? 'completed' } as unknown as ServiceRequest };
  }
}

export type OpenRequestUpdate = {
  description: string;
  urgency: string;
  city: string;
  locationLabel: string;
  clientPrice?: number | null;
};

export async function updateOpenRequest(requestId: string, update: OpenRequestUpdate) {
  return requestJson<{ request: ServiceRequest }>(`/api/customer/requests/${encodeURIComponent(requestId)}`, {
    method: "PATCH",
    body: JSON.stringify({ action: "update_open", ...update }),
  });
}
