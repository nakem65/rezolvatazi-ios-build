import type {
  AccountProfile,
  AccountProfileMemberRole,
  EarningAlertPreferences,
  EarningProfile,
  ProviderCapabilityLevel,
  ProviderEntityType,
  ProviderEquipmentId,
  RequestProfile,
  RequestProfileType,
  ProfileInvitation,
} from "../types";
import { requestJson } from "./core";

export type RequestProfileDraft = {
  accountProfileId?: string;
  label: string;
  profileType: RequestProfileType;
  displayName: string;
  legalName?: string | null;
  taxId?: string | null;
  tradeRegistryNumber?: string | null;
  billingEmail?: string | null;
  billingPhone?: string | null;
  billingAddressLine1?: string | null;
  billingAddressLine2?: string | null;
  workAddressLine1?: string | null;
  city: string;
  county?: string | null;
  postalCode?: string | null;
  contactName?: string | null;
  contactPhone?: string | null;
  defaultInvoiceRequired: boolean;
  isDefault?: boolean;
};

export type EarningProfileDraft = {
  accountProfileId?: string;
  label: string;
  entityType: ProviderEntityType;
  publicName: string;
  legalName?: string | null;
  taxId?: string | null;
  tradeRegistryNumber?: string | null;
  canInvoice: boolean;
  city: string;
  latitude?: number | null;
  longitude?: number | null;
  radiusKm: number;
  baseHourlyRateLei: number | null;
  minimumHours: number;
  bio: string;
  isDefault?: boolean;
  isActive?: boolean;
  capabilities: Array<{
    categoryId: string;
    level: ProviderCapabilityLevel;
    hourlyRateLei: number | null;
    minimumPriceLei?: number | null;
  }>;
  equipment: ProviderEquipmentId[];
  alerts: EarningAlertPreferences;
};

export async function fetchRequestProfiles() {
  return requestJson<{ profiles: RequestProfile[] }>("/api/request-profiles");
}

export async function createRequestProfile(profile: RequestProfileDraft) {
  return requestJson<{ profile: RequestProfile }>("/api/request-profiles", {
    method: "POST",
    body: JSON.stringify(profile),
  });
}

export async function updateRequestProfile(id: string, profile: Partial<RequestProfileDraft>) {
  return requestJson<{ profile: RequestProfile }>(`/api/request-profiles/${encodeURIComponent(id)}`, {
    method: "PATCH",
    body: JSON.stringify(profile),
  });
}

export async function fetchEarningProfiles() {
  return requestJson<{ profiles: EarningProfile[] }>("/api/earning-profiles");
}

export async function createEarningProfile(profile: EarningProfileDraft) {
  return requestJson<{ profile: EarningProfile }>("/api/earning-profiles", {
    method: "POST",
    body: JSON.stringify(profile),
  });
}

export async function updateEarningProfile(id: string, profile: Partial<EarningProfileDraft>) {
  return requestJson<{ profile: EarningProfile }>(`/api/earning-profiles/${encodeURIComponent(id)}`, {
    method: "PATCH",
    body: JSON.stringify(profile),
  });
}

export async function startEarningAvailability(id: string, hours: 1 | 2 | 4 | 8) {
  return requestJson<{ availability: { id: string; startsAt: string; endsAt: string; hours: number } }>(
    `/api/earning-profiles/${encodeURIComponent(id)}/availability`,
    { method: "POST", body: JSON.stringify({ hours }) },
  );
}

export async function stopEarningAvailability(id: string) {
  return requestJson<{ ok: true }>(`/api/earning-profiles/${encodeURIComponent(id)}/availability`, {
    method: "DELETE",
  });
}

export async function saveEarningAlerts(id: string, alerts: EarningAlertPreferences) {
  return requestJson<{ alerts: EarningAlertPreferences }>(`/api/earning-profiles/${encodeURIComponent(id)}/alerts`, {
    method: "PUT",
    body: JSON.stringify(alerts),
  });
}

export async function fetchAccountProfiles() {
  return requestJson<{ profiles: AccountProfile[] }>("/api/account-profiles");
}

export async function createAccountProfile(profile: {
  label: string;
  profileType: RequestProfileType;
  displayName: string;
  legalName?: string | null;
  taxId?: string | null;
  tradeRegistryNumber?: string | null;
  avatarUrl?: string | null;
  bio?: string;
}) {
  return requestJson<{ profile: AccountProfile }>("/api/account-profiles", {
    method: "POST",
    body: JSON.stringify(profile),
  });
}

export async function updateAccountProfile(id: string, profile: Partial<{
  label: string;
  profileType: RequestProfileType;
  displayName: string;
  legalName: string | null;
  taxId: string | null;
  tradeRegistryNumber: string | null;
  bio: string;
}>) {
  return requestJson<{ profile: AccountProfile }>(`/api/account-profiles/${encodeURIComponent(id)}`, {
    method: "PATCH",
    body: JSON.stringify(profile),
  });
}

export async function addAccountProfileMedia(id: string, media: { kind: "avatar" | "logo" | "portfolio"; url: string; caption?: string }) {
  return requestJson<{ media: AccountProfile["media"][number] }>(`/api/account-profiles/${encodeURIComponent(id)}/media`, {
    method: "POST",
    body: JSON.stringify(media),
  });
}

export async function deleteAccountProfileMedia(id: string, mediaId: string) {
  return requestJson<{ ok: true }>(`/api/account-profiles/${encodeURIComponent(id)}/media?mediaId=${encodeURIComponent(mediaId)}`, {
    method: "DELETE",
  });
}

export async function fetchAccountProfileMembers(id: string) {
  return requestJson<{ members: Array<{
    id: string;
    accountId: string | null;
    name: string;
    avatarUrl: string | null;
    phone: string | null;
    role: AccountProfileMemberRole;
    status: "invited" | "active";
    createdAt: string;
    acceptedAt: string | null;
  }> }>(`/api/account-profiles/${encodeURIComponent(id)}/members`);
}

export async function inviteAccountProfileMember(id: string, phone: string, role: "admin" | "worker") {
  return requestJson<{ invitation: { id: string; status: "invited" } }>(`/api/account-profiles/${encodeURIComponent(id)}/members`, {
    method: "POST",
    body: JSON.stringify({ phone, role }),
  });
}

export async function fetchProfileInvitations() {
  return requestJson<{ invitations: ProfileInvitation[] }>("/api/profile-invitations");
}

export async function acceptProfileInvitation(id: string) {
  return requestJson<{ membership: { id: string; profileId: string; status: "active" } }>(`/api/profile-invitations/${encodeURIComponent(id)}/accept`, {
    method: "POST",
  });
}
