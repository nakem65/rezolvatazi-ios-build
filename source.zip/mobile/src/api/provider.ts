import { Provider, ProviderOnboarding, ProviderWorkProfile } from '../types';
import { demoProvider } from '../demo';
import { requestJson, configuredUrl } from './core';

export async function fetchCurrentProvider() {
  try {
    return await requestJson<{ provider: Provider }>('/api/me');
  } catch (e) { if (configuredUrl) throw e;
    return { provider: demoProvider };
  }
}

export async function saveProviderProfile(profile: ProviderOnboarding) {
  try {
    return await requestJson<{ provider: Provider }>('/api/me', { method: 'PATCH', body: JSON.stringify(profile) });
  } catch (e) { if (configuredUrl) throw e;
    return { provider: { ...demoProvider, ...profile } };
  }
}

export async function updateProviderPreferences(preferences: {
  clientName?: string;
  isAvailable?: boolean; 
  helperAvailable?: boolean; 
  professionalAvailable?: boolean; 
  availabilityMinutes?: number;
  hobbyAvailable?: boolean; 
  notificationEnabled?: boolean; 
  helperEnabled?: boolean; 
  professionalEnabled?: boolean; 
  hobbyEnabled?: boolean; 
  avatarUrl?: string | null;
  hobbyAvatarUrl?: string | null;
  neighborAvatarUrl?: string | null;
}) {
  try {
    return await requestJson<{ provider: Provider }>('/api/me', { method: 'PATCH', body: JSON.stringify(preferences) });
  } catch (e) { if (configuredUrl) throw e;
    throw new Error('Datele nu au putut fi salvate pe server. Verificați conexiunea.');
  }
}

export async function fetchProviderWorkProfile() {
  return requestJson<{ profile: ProviderWorkProfile }>('/api/provider/work-profile');
}

export async function saveProviderWorkProfile(profile: {
  entityType: ProviderWorkProfile['entityType'];
  baseHourlyRateLei: number | null;
  minimumHours: number;
  bio: string;
  capabilities: Array<{
    categoryId: string;
    level: ProviderWorkProfile['capabilities'][number]['level'];
    hourlyRateLei: number | null;
  }>;
  equipment: ProviderWorkProfile['equipment'];
}) {
  return requestJson<{ profile: ProviderWorkProfile }>('/api/provider/work-profile', {
    method: 'PUT',
    body: JSON.stringify(profile),
  });
}

export async function deleteProviderAccount() {
  try { return await requestJson<{ ok: true }>('/api/me', { method: 'DELETE' }); } catch (e) { if (configuredUrl) throw e; return { ok: true as const }; }
}

export async function submitKYC(): Promise<{ provider: Provider }> {
  try {
    return await requestJson<{ provider: Provider }>('/api/provider/kyc', {
      method: 'POST',
      body: JSON.stringify({})
    });
  } catch (e) { if (configuredUrl) throw e;
    throw new Error('Nu am putut salva datele de verificare.');
  }
}

export async function savePushToken(token: string, platform: 'android' | 'ios') {
  try { return await requestJson<{ ok: true }>('/api/push-tokens', { method: 'POST', body: JSON.stringify({ token, platform }) }); } catch (e) { if (configuredUrl) throw e; return { ok: true as const }; }
}
