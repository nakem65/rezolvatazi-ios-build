import { SentOffer, OfferDraft, OfferPricingDraft, ServiceRequest } from '../types';
import { requestJson, configuredUrl } from './core';

export async function fetchProviderOffers() {
  try {
    const payload = await requestJson<{ offers: SentOffer[] }>('/api/provider/offers');
    return payload.offers;
  } catch (e) { if (configuredUrl) throw e;
    return [];
  }
}

export async function createOffer(providerId: string, draft: OfferDraft) {
  try {
    const payload = await requestJson<{ offer: { id: string } }>('/api/offers', {
      method: 'POST',
      body: JSON.stringify({ providerId, ...draft }),
    });
    return payload.offer;
  } catch (e) { if (configuredUrl) throw e;
    return { id: `demo-offer-${Date.now()}` };
  }
}

export async function updateOffer(offerId: string, revision: number, input: {
  pricing: OfferPricingDraft;
  etaMinutes: number;
  message: string;
}) {
  return requestJson<{ offer: { id: string; revision: number } }>(`/api/offers/${offerId}`, {
    method: 'PATCH',
    body: JSON.stringify({ revision, ...input }),
  });
}

export async function withdrawOffer(offerId: string, revision: number) {
  return requestJson<{ ok: boolean; offer: { id: string; revision: number } }>(`/api/offers/${offerId}`, {
    method: 'DELETE',
    body: JSON.stringify({ revision }),
  });
}

const demoAcceptedOffers = new Set<string>();

export async function acceptOffer(requestId: string, offerId: string) {
  try {
    return await requestJson<{ request: ServiceRequest }>('/api/accept-offer', { method: 'POST', body: JSON.stringify({ requestId, offerId }) });
  } catch (e) { if (configuredUrl) throw e;
    demoAcceptedOffers.add(offerId);
    const createdAt = new Date().toISOString();
    return {
      request: {
        id: requestId,
        description: 'Cerere demonstrativă',
        category: 'general',
        urgency: 'normal',
        city: 'București',
        contactName: 'Utilizator demo',
        contactPhone: '',
        status: 'matched',
        selectedOfferId: offerId,
        requestMode: 'professional',
        isDemo: true,
        createdAt,
        expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
      },
    };
  }
}

export function getDemoAcceptedOffers() { return demoAcceptedOffers; }
