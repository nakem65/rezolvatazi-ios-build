import { ProviderBilling } from '../types';
import { requestJson, configuredUrl } from './core';

export async function fetchProviderBilling() {
  try {
    const payload = await requestJson<{ billing: ProviderBilling }>('/api/provider/billing');
    return payload.billing;
  } catch (e) { if (configuredUrl) throw e;
    return { pendingBani: 0, waivedJobs: 3, freeJobsRemaining: 3, successFeeBani: 2900, betaFree: true, charges: [] };
  }
}
