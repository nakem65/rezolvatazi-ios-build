import * as ExpoLocation from "expo-location";
import { geocodeLocationQuery, type PlaceSelection } from "./googlePlaces";

type ReversePlace = ExpoLocation.LocationGeocodedAddress;

export function resolveWithinTimeout<T>(operation: Promise<T>, timeoutMs = 6_000): Promise<T | null> {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(null), timeoutMs);
    operation.then(
      (value) => { clearTimeout(timeout); resolve(value); },
      () => { clearTimeout(timeout); resolve(null); },
    );
  });
}

function uniqueParts(parts: Array<string | null | undefined>) {
  return parts
    .map((part) => part?.trim() ?? "")
    .filter(Boolean)
    .filter((value, index, values) => values.findIndex((candidate) => candidate.toLocaleLowerCase("ro-RO") === value.toLocaleLowerCase("ro-RO")) === index);
}

export function selectionFromReverseGeocode(
  place: ReversePlace | undefined,
  coordinates: { latitude: number; longitude: number },
  fallbackLabel = "",
): PlaceSelection {
  const street = uniqueParts([place?.street, place?.streetNumber]).join(" ");
  const fullParts = uniqueParts([
    street || place?.name,
    place?.district,
    place?.city,
    place?.subregion,
    place?.region,
  ]);
  const areaParts = uniqueParts([
    place?.district,
    place?.city,
    place?.subregion,
    place?.region,
  ]);
  return {
    fullLabel: fullParts.join(", ") || fallbackLabel.trim(),
    areaLabel: areaParts.slice(0, 2).join(", ") || fallbackLabel.trim(),
    latitude: coordinates.latitude,
    longitude: coordinates.longitude,
    county: place?.region ?? place?.subregion ?? null,
    postalCode: place?.postalCode ?? null,
  };
}

export async function resolveTypedRomanianLocation(query: string): Promise<PlaceSelection | null> {
  const trimmed = query.trim();
  if (trimmed.length < 3) return null;
  const serverResult = await geocodeLocationQuery(trimmed);
  if (serverResult) return serverResult;
  try {
    const matches = await resolveWithinTimeout(ExpoLocation.geocodeAsync(`${trimmed}, România`));
    const first = matches?.[0];
    if (!first) return null;
    const coordinates = { latitude: first.latitude, longitude: first.longitude };
    const reverse = await resolveWithinTimeout(ExpoLocation.reverseGeocodeAsync(coordinates));
    const selection = selectionFromReverseGeocode(reverse?.[0], coordinates, trimmed);
    return {
      ...selection,
      // Pentru o adresă scrisă manual păstrăm formularea utilizatorului, dar
      // calculăm separat zona publică din rezultatul geocodării.
      fullLabel: trimmed,
    };
  } catch {
    return null;
  }
}
