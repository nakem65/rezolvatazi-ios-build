import { Linking } from "react-native";
import { showAppAlert } from "@/src/alerts";

export async function openExternalUrl(url: string, unavailableMessage = "Linkul nu poate fi deschis pe acest dispozitiv.") {
  try {
    if (!await Linking.canOpenURL(url)) throw new Error("UNSUPPORTED_URL");
    await Linking.openURL(url);
  } catch {
    showAppAlert("Nu am putut deschide", unavailableMessage);
  }
}
