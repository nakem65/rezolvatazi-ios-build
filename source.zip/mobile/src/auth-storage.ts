import { Platform } from "react-native";

const key = "rezolvatazi_session";
const legacyKey = "rezolvatazi_provider_session";

export async function readStoredToken() {
  if (Platform.OS === "web") return typeof localStorage === "undefined" ? null : localStorage.getItem(key) ?? localStorage.getItem(legacyKey);
  const SecureStore = await import("expo-secure-store");
  const current = await SecureStore.getItemAsync(key);
  if (current) return current;
  const legacy = await SecureStore.getItemAsync(legacyKey);
  if (legacy) await SecureStore.setItemAsync(key, legacy, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
  return legacy;
}

export async function storeToken(token: string) {
  if (Platform.OS === "web") return localStorage.setItem(key, token);
  const SecureStore = await import("expo-secure-store");
  return SecureStore.setItemAsync(key, token, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
}

export async function removeStoredToken() {
  if (Platform.OS === "web") { localStorage.removeItem(key); localStorage.removeItem(legacyKey); return; }
  const SecureStore = await import("expo-secure-store");
  await Promise.all([SecureStore.deleteItemAsync(key), SecureStore.deleteItemAsync(legacyKey)]);
}
