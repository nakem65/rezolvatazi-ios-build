import { PropsWithChildren, createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Platform } from "react-native";
import { apiMode, createOffer, fetchEarningProfiles, fetchOpenRequests, fetchProviderBilling, fetchProviderOffers, savePushToken, startEarningAvailability, stopEarningAvailability, updateProviderPreferences } from "./api";
import { demoRequests } from "./demo";
import { useAuth } from "./AuthContext";
import { registerForRequestAlerts } from "./notifications";
import { useMode } from "./ModeContext";
import { OfferDraft, ProviderBilling, SentOffer, ServiceRequest } from "./types";

const emptyBilling: ProviderBilling = { pendingBani: 0, waivedJobs: 0, freeJobsRemaining: 3, successFeeBani: 2900, betaFree: true, charges: [] };

type NotificationOperationResult = {
  enabled: boolean;
  changed: boolean;
  message: string;
};

type ProviderState = {
  available: boolean;
  notificationEnabled: boolean;
  notificationMessage: string;
  requests: ServiceRequest[];
  offers: SentOffer[];
  billing: ProviderBilling;
  loading: boolean;
  error: string;
  source: "demo" | "live";
  toggleAvailable: () => Promise<void>;
  setAvailabilityFor: (minutes: number, earningProfileId?: string) => Promise<void>;
  enableNotifications: () => Promise<NotificationOperationResult>;
  toggleNotifications: () => Promise<NotificationOperationResult>;
  refresh: () => Promise<void>;
  sendOffer: (draft: OfferDraft) => Promise<void>;
};

const ProviderContext = createContext<ProviderState | null>(null);

export function ProviderProvider({ children }: PropsWithChildren) {
  const { provider, setProvider, isDemo } = useAuth();
  const { activeMode } = useMode();
  const activeAvailability = activeMode === "neighbor" ? provider?.helperAvailable : activeMode === "hobby" ? provider?.hobbyAvailable : provider?.professionalAvailable;
  const [available, setAvailable] = useState(activeAvailability ?? true);
  const [notificationEnabled, setNotificationEnabled] = useState(provider?.notificationEnabled ?? false);
  const [notificationMessage, setNotificationMessage] = useState("");
  const [requests, setRequests] = useState<ServiceRequest[]>(apiMode === "demo" ? demoRequests : []);
  const [offers, setOffers] = useState<SentOffer[]>([]);
  const [billing, setBilling] = useState<ProviderBilling>(emptyBilling);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [source, setSource] = useState<"demo" | "live">(apiMode);

  // Keep the optimistic availability control aligned with server profile refreshes.
  useEffect(() => { if (provider) { setAvailable(activeMode === "neighbor" ? provider.helperAvailable : activeMode === "hobby" ? provider.hobbyAvailable : provider.professionalAvailable ?? false); setNotificationEnabled(provider.notificationEnabled); } }, [activeMode, provider]);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const nextRequests = activeMode === "client" ? [] : await fetchOpenRequests(activeMode);
      setRequests(nextRequests);
      setSource(apiMode);
      if (!isDemo && provider) {
        const [nextOffers, nextBilling] = await Promise.all([fetchProviderOffers(), fetchProviderBilling()]);
        setOffers(nextOffers);
        setBilling(nextBilling);
      }
    } catch {
      setRequests(apiMode === "demo" && activeMode !== "client" ? demoRequests.filter((request) => request.requestMode === activeMode) : []);
      setSource(apiMode);
      setError(apiMode === "demo" ? "" : "API-ul nu răspunde. Reîncearcă în câteva secunde.");
    } finally {
      setLoading(false);
    }
  }, [activeMode, isDemo, provider]);

  useEffect(() => {
    // Initial network refresh resolves asynchronously.
    void refresh();
  }, [refresh]);

  const enableNotifications = useCallback(async () => {
    // The bell must acknowledge the press immediately. Permission and token
    // registration can take a few seconds on iOS, so do that work after the
    // visible state changes and roll it back only if activation truly fails.
    setNotificationEnabled(true);
    setNotificationMessage("Activăm alertele pe acest telefon…");
    try {
      const result = await registerForRequestAlerts();
      if (!result.enabled) {
        const message = result.message ?? "Notificările nu au fost permise pe acest telefon.";
        setNotificationEnabled(false);
        setNotificationMessage(message);
        return { enabled: false, changed: false, message };
      }
      if (!isDemo && (Platform.OS === "android" || Platform.OS === "ios")) {
        if (!result.token) throw new Error("Telefonul nu a furnizat un token pentru notificări.");
        await savePushToken(result.token, Platform.OS);
        const updated = await updateProviderPreferences({ notificationEnabled: true });
        setProvider(updated.provider);
      }
      setNotificationEnabled(true);
      const message = result.message ?? "Alertele pentru cereri urgente sunt active.";
      setNotificationMessage(message);
      return { enabled: true, changed: true, message };
    } catch (caught) {
      const message = caught instanceof Error
        ? `Telefonul a permis notificările, dar activarea pe server a eșuat: ${caught.message}`
        : "Telefonul a permis notificările, dar activarea pe server a eșuat.";
      setNotificationEnabled(false);
      setNotificationMessage(message);
      return { enabled: false, changed: false, message };
    }
  }, [isDemo, setProvider]);

  const sendOffer = useCallback(async (draft: OfferDraft) => {
    const target = requests.find((request) => request.id === draft.requestId);
    if (!target && isDemo) throw new Error("Cererea nu mai este disponibilă.");
    if (!provider) throw new Error("Autentifică-te din nou pentru a trimite oferta.");
    let earningProfileId = draft.earningProfileId;
    if (!earningProfileId && !isDemo) {
      const { profiles } = await fetchEarningProfiles();
      const activeProfile = profiles.find((profile) => profile.isActive) ?? profiles.find((profile) => profile.isDefault);
      if (!activeProfile) throw new Error("Alege profilul cu care vrei să primești lucrarea.");
      earningProfileId = activeProfile.id;
    }
    const created = await createOffer(provider.id, { ...draft, earningProfileId });
    if (isDemo) {
      const { pricing: pricingDraft, ...legacyDraft } = draft;
      void pricingDraft;
      setOffers((current) => [
        {
          ...legacyDraft,
          id: created.id,
          request: target!,
          status: "pending",
          revision: 1,
          customerRating: null,
          createdAt: new Date().toISOString(),
        },
        ...current,
      ]);
    } else {
      setOffers(await fetchProviderOffers());
    }
  }, [isDemo, provider, requests]);

  const toggleAvailable = useCallback(async () => {
    const next = !available;
    setAvailable(next);
    if (isDemo) return;
    try {
      if (activeMode === "professional") {
        const { profiles } = await fetchEarningProfiles();
        const profile = profiles.find((item) => item.isActive)
          ?? profiles.find((item) => item.isDefault)
          ?? profiles[0];
        if (!profile) throw new Error("Configurează mai întâi profilul cu care vrei să lucrezi.");
        if (next) {
          const result = await startEarningAvailability(profile.id, 4);
          if (provider) setProvider({
            ...provider,
            professionalEnabled: true,
            professionalAvailable: true,
            professionalAvailableUntil: result.availability.endsAt,
          });
        } else {
          await stopEarningAvailability(profile.id);
          if (provider) setProvider({
            ...provider,
            professionalAvailable: false,
            professionalAvailableUntil: null,
          });
        }
        return;
      }
      const payload = activeMode === "neighbor"
        ? { helperAvailable: next }
        : activeMode === "hobby"
          ? { hobbyAvailable: next }
          : {};
      const updated = await updateProviderPreferences(payload);
      setProvider(updated.provider);
    } catch (caught) {
      setAvailable(!next);
      throw caught;
    }
  }, [activeMode, available, isDemo, provider, setProvider]);

  const setAvailabilityFor = useCallback(async (minutes: number, earningProfileId?: string) => {
    setAvailable(true);
    if (isDemo) {
      if (provider) setProvider({
        ...provider,
        professionalAvailable: true,
        professionalAvailableUntil: new Date(Date.now() + minutes * 60_000).toISOString(),
      });
      return;
    }
    try {
      const { profiles } = await fetchEarningProfiles();
      const profile = profiles.find((item) => item.id === earningProfileId)
        ?? profiles.find((item) => item.isActive)
        ?? profiles.find((item) => item.isDefault)
        ?? profiles[0];
      if (!profile) throw new Error("Configurează mai întâi profilul cu care vrei să lucrezi.");
      const hours = (minutes <= 60 ? 1 : minutes <= 120 ? 2 : minutes <= 240 ? 4 : 8) as 1 | 2 | 4 | 8;
      const result = await startEarningAvailability(profile.id, hours);
      if (provider) setProvider({
        ...provider,
        professionalEnabled: true,
        professionalAvailable: true,
        professionalAvailableUntil: result.availability.endsAt,
      });
    } catch (caught) {
      setAvailable(provider?.professionalAvailable ?? false);
      throw caught;
    }
  }, [isDemo, provider, setProvider]);

  const toggleNotifications = useCallback(async () => {
    const next = !notificationEnabled;
    if (next) {
      return enableNotifications();
    }
    setNotificationEnabled(next);
    setNotificationMessage("Alertele au fost dezactivate.");
    if (!isDemo) {
      try {
        await updateProviderPreferences({ notificationEnabled: next });
        if (provider) setProvider({ ...provider, notificationEnabled: next });
      } catch (caught) {
        setNotificationEnabled(!next);
        const errorMsg = caught instanceof Error ? caught.message : String(caught);
        const message = `Alertele au rămas active deoarece serverul nu a salvat modificarea: ${errorMsg}`;
        setNotificationMessage(message);
        return { enabled: true, changed: false, message };
      }
    }
    return { enabled: false, changed: true, message: "Alertele au fost dezactivate." };
  }, [enableNotifications, isDemo, notificationEnabled, provider, setProvider]);

  const value = useMemo(
    () => ({
      available,
      notificationEnabled,
      notificationMessage,
      requests,
      offers,
      billing,
      loading,
      error,
      source,
      toggleAvailable,
      setAvailabilityFor,
      enableNotifications,
      toggleNotifications,
      refresh,
      sendOffer,
    }),
    [available, billing, enableNotifications, error, loading, notificationEnabled, notificationMessage, offers, refresh, requests, sendOffer, setAvailabilityFor, source, toggleAvailable, toggleNotifications]
  );

  return <ProviderContext.Provider value={value}>{children}</ProviderContext.Provider>;
}

export function useProvider() {
  const context = useContext(ProviderContext);
  if (!context) throw new Error("useProvider must be used within ProviderProvider");
  return context;
}
