import { PropsWithChildren, createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useAuth } from "./AuthContext";
import { readStoredMode, storeMode } from "./mode-storage";
import { AppMode } from "./types";

type ModeState = { activeMode: AppMode; setActiveMode: (mode: AppMode) => void };
const ModeContext = createContext<ModeState | null>(null);

export function ModeProvider({ children }: PropsWithChildren) {
  const { provider } = useAuth();
  const [activeMode, setMode] = useState<AppMode>("client");
  useEffect(() => {
    let active = true;
    void readStoredMode().then((stored) => {
      if (!active) return;
      const allowed = stored === "client"
        || (stored === "professional" && provider?.professionalEnabled);
      setMode(allowed ? stored! : "client");
    });
    return () => { active = false; };
  }, [provider?.id, provider?.professionalEnabled]);
  const setActiveMode = useCallback((mode: AppMode) => { setMode(mode); void storeMode(mode); }, []);
  const value = useMemo(() => ({ activeMode, setActiveMode }), [activeMode, setActiveMode]);
  return <ModeContext.Provider value={value}>{children}</ModeContext.Provider>;
}

export function useMode() {
  const context = useContext(ModeContext);
  if (!context) throw new Error("useMode must be used inside ModeProvider");
  return context;
}
