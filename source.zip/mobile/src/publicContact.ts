/** Public brand contact details. Keep credentials and private forwarding out of source control. */
export const publicSupportWhatsAppUrl = "https://wa.me/40770118908";
