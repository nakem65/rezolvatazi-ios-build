import { createAudioPlayer } from "expo-audio";
import { Platform } from "react-native";
import { getInAppSoundsEnabled } from "@/src/device-preferences";

type UiSound = "click" | "success" | "notification" | "error" | "send";

function playNativeSound(type: UiSound) {
  // Messages get a short, local acknowledgement. We never make a sound for
  // each typed character, polling tick, or the already loaded chat history.
  const asset = type === "send"
    // Expo resolves bundled audio assets from require at build time.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    ? require("../assets/sounds/message-sent.wav")
    : type === "notification"
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      ? require("../assets/sounds/message-received.wav")
      : null;
  if (!asset) return;
  try {
    const player = createAudioPlayer(asset, { keepAudioSessionActive: false });
    player.volume = type === "send" ? 0.18 : 0.22;
    player.play();
    setTimeout(() => player.remove(), 1_500);
  } catch {
    // The device may be muted or audio unavailable. Haptic feedback and the
    // visible send state still acknowledge the action.
  }
}

function playWebSound(type: UiSound) {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const audioCtx = new AudioContextClass();
    if (audioCtx.state === "suspended") {
      void audioCtx.resume();
    }
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (type === "click" || type === "send") {
      const freq = type === "send" ? 600 : 440;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.5, audioCtx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.1);
    } else if (type === "success") {
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
      osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    } else if (type === "notification") {
      osc.frequency.setValueAtTime(659.25, audioCtx.currentTime);
      osc.frequency.setValueAtTime(987.77, audioCtx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } else if (type === "error") {
      osc.frequency.setValueAtTime(220, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.15);
    }
  } catch {
    // AudioContext muted/unsupported
  }
}

export function playUiSound(type: UiSound = "click") {
  void getInAppSoundsEnabled().then((enabled) => {
    if (!enabled) return;
    if (Platform.OS === "web") playWebSound(type);
    else playNativeSound(type);
  }).catch(() => undefined);
}
