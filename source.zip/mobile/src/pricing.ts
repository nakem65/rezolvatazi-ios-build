import type {
  OfferMaterialsMode,
  OfferPricing,
  OfferPricingDraft,
  OfferPricingUnit,
  OfferTravelMode,
  OfferVatMode,
  StructuredWorkOrder,
} from "./types";

export const pricingUnitOptions: Array<{ value: OfferPricingUnit; label: string; short: string }> = [
  { value: "job", label: "Preț total pentru lucrare", short: "lucrare" },
  { value: "hour", label: "Tarif pe oră", short: "oră" },
  { value: "person_hour", label: "Tarif pe persoană și oră", short: "persoană/oră" },
  { value: "km", label: "Tarif pe kilometru", short: "km" },
  { value: "sqm", label: "Tarif pe metru pătrat", short: "m²" },
  { value: "item", label: "Tarif pe bucată", short: "bucată" },
  { value: "visit", label: "Tarif pe vizită", short: "vizită" },
  { value: "day", label: "Tarif pe zi", short: "zi" },
  { value: "trip", label: "Tarif pe cursă", short: "cursă" },
];

export const travelModeOptions: Array<{ value: OfferTravelMode; label: string }> = [
  { value: "included", label: "Inclusă" },
  { value: "fixed", label: "Taxă fixă" },
  { value: "per_km", label: "Pe kilometru" },
];

export const materialsModeOptions: Array<{ value: OfferMaterialsMode; label: string }> = [
  { value: "included", label: "Incluse" },
  { value: "excluded", label: "Neincluse" },
  { value: "estimated", label: "Estimate separat" },
];

export const vatModeOptions: Array<{ value: OfferVatMode; label: string }> = [
  { value: "not_applicable", label: "Nu se aplică" },
  { value: "included", label: "TVA inclus" },
  { value: "excluded", label: "TVA se adaugă" },
  { value: "unspecified", label: "Neprecizat" },
];

export function defaultPricingUnit(
  workOrder: StructuredWorkOrder | null | undefined,
  category?: string,
): OfferPricingUnit {
  if (workOrder?.solutionKind === "recurring") return "visit";
  if (workOrder?.solutionKind === "team") return "person_hour";
  if (workOrder?.pricingModel === "hourly") return "hour";
  if (category === "Transport & livrări" || category === "Auto & tractări") return "km";
  return "job";
}

export function createPricingDraft(
  unit: OfferPricingUnit,
  requiredParticipants = 1,
): OfferPricingDraft {
  return {
    priceType: unit === "job" ? "fixed" : "estimate",
    unit,
    unitPriceLei: 0,
    estimatedQuantity: 1,
    minimumPriceLei: 0,
    includedParticipants: Math.min(1, requiredParticipants),
    travelMode: "included",
    travelFeeLei: 0,
    travelRateLei: 0,
    estimatedTravelKm: 0,
    materialsMode: "excluded",
    materialsCostLei: 0,
    vatMode: "unspecified",
    vatIncluded: false,
  };
}

export function pricingDraftFromOffer(pricing: OfferPricing): OfferPricingDraft {
  return {
    priceType: pricing.priceType,
    unit: pricing.unit,
    unitPriceLei: pricing.unitPriceBani / 100,
    estimatedQuantity: pricing.estimatedQuantity,
    minimumPriceLei: pricing.minimumPriceBani / 100,
    includedParticipants: pricing.includedParticipants,
    travelMode: pricing.travel.mode,
    travelFeeLei: pricing.travel.feeBani / 100,
    travelRateLei: pricing.travel.rateBani / 100,
    estimatedTravelKm: pricing.travel.estimatedKm,
    materialsMode: pricing.materials.mode,
    materialsCostLei: pricing.materials.estimatedCostBani / 100,
    vatMode: pricing.vatMode,
    vatIncluded: pricing.vatIncluded,
  };
}

export function estimatePricingDraftTotal(draft: OfferPricingDraft) {
  const unitMultiplier = draft.unit === "person_hour" ? draft.includedParticipants : 1;
  const labor = Math.max(
    draft.unitPriceLei * (draft.unit === "job" ? 1 : draft.estimatedQuantity) * unitMultiplier,
    draft.minimumPriceLei,
  );
  const travel = draft.travelMode === "fixed"
    ? draft.travelFeeLei
    : draft.travelMode === "per_km"
      ? draft.travelRateLei * draft.estimatedTravelKm
      : 0;
  const materials = draft.materialsMode === "estimated" ? draft.materialsCostLei : 0;
  return Math.round((labor + travel + materials) * 100) / 100;
}

function formatLei(bani: number) {
  return new Intl.NumberFormat("ro-RO", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(bani / 100);
}

export function pricingPresentation(pricing: OfferPricing | null | undefined) {
  if (!pricing) return null;
  if (pricing.priceType === "free") {
    return { headline: "Gratuit", formula: "Ajutor fără plată", details: [] as string[] };
  }
  const unit = pricingUnitOptions.find((item) => item.value === pricing.unit)?.short ?? pricing.unit;
  const quantity = new Intl.NumberFormat("ro-RO", { maximumFractionDigits: 2 }).format(pricing.estimatedQuantity);
  let formula = pricing.unit === "job"
    ? `${formatLei(pricing.unitPriceBani)} lei pentru lucrare`
    : `${quantity} ${unit} × ${formatLei(pricing.unitPriceBani)} lei`;
  if (pricing.unit === "person_hour") {
    formula = `${pricing.includedParticipants} ${pricing.includedParticipants === 1 ? "persoană" : "persoane"} × ${quantity} ore × ${formatLei(pricing.unitPriceBani)} lei`;
  }
  const details: string[] = [];
  if (pricing.minimumPriceBani) details.push(`Minimum ${formatLei(pricing.minimumPriceBani)} lei`);
  if (pricing.travel.mode === "included") details.push("Deplasare inclusă");
  if (pricing.travel.mode === "fixed") details.push(`Deplasare ${formatLei(pricing.travel.feeBani)} lei`);
  if (pricing.travel.mode === "per_km") details.push(`${formatLei(pricing.travel.rateBani)} lei/km pentru aproximativ ${pricing.travel.estimatedKm} km`);
  if (pricing.materials.mode === "included") details.push("Materiale incluse");
  if (pricing.materials.mode === "excluded") details.push("Materiale neincluse");
  if (pricing.materials.mode === "estimated") details.push(`Materiale estimate la ${formatLei(pricing.materials.estimatedCostBani)} lei`);
  details.push(
    pricing.vatMode === "included"
      ? "TVA inclus"
      : pricing.vatMode === "excluded"
        ? "TVA se adaugă"
        : pricing.vatMode === "not_applicable"
          ? "TVA nu se aplică"
          : "TVA neprecizat",
  );
  return {
    headline: `${pricing.priceType === "estimate" ? "Aprox. " : ""}${formatLei(pricing.estimatedTotalBani)} lei`,
    formula,
    details,
  };
}
