import * as ImageManipulator from "expo-image-manipulator";
import * as ImagePicker from "expo-image-picker";
import { Alert } from "react-native";

const maximumEncodedImageLength = 500_000;

export type PickedMediaAsset = {
  uri: string;
  name: string;
  type: string;
  mediaType: "image" | "video" | "audio";
};

async function requestLibraryPermission(message: string) {
  try {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permission.granted) return true;
  } catch {
    // The system picker can be unavailable on an emulator or a restricted device.
  }
  Alert.alert("Permisiune necesară", message);
  return false;
}

async function requestCameraPermission(message: string) {
  try {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (permission.granted) return true;
  } catch {
    // The camera can be unavailable on simulators or restricted devices.
  }
  Alert.alert("Permisiune necesară", message);
  return false;
}

async function prepareChatImage(asset: ImagePicker.ImagePickerAsset): Promise<PickedMediaAsset | null> {
  try {
    const actions = asset.width > 1_600 ? [{ resize: { width: 1_600 } }] : [];
    const prepared = await ImageManipulator.manipulateAsync(asset.uri, actions, {
      compress: 0.68,
      format: ImageManipulator.SaveFormat.JPEG,
    });
    return {
      uri: prepared.uri,
      name: `fotografie-${Date.now()}.jpg`,
      type: "image/jpeg",
      mediaType: "image",
    };
  } catch {
    Alert.alert("Imagine indisponibilă", "Fotografia nu a putut fi pregătită. Încearcă alta.");
    return null;
  }
}

async function prepareRequestImage(asset: ImagePicker.ImagePickerAsset): Promise<string | null> {
  try {
    const actions = asset.width > 1_000 ? [{ resize: { width: 1_000 } }] : [];
    const compressed = await ImageManipulator.manipulateAsync(asset.uri, actions, {
      base64: true,
      compress: 0.52,
      format: ImageManipulator.SaveFormat.JPEG,
    });
    if (!compressed.base64) throw new Error("missing_base64");
    const dataUrl = `data:image/jpeg;base64,${compressed.base64}`;
    if (dataUrl.length > maximumEncodedImageLength) {
      Alert.alert("Imagine prea mare", "Alege o fotografie mai mică. Limita protejează viteza aplicației.");
      return null;
    }
    return dataUrl;
  } catch {
    Alert.alert("Imagine indisponibilă", "Fotografia nu a putut fi pregătită. Încearcă alta.");
    return null;
  }
}

export async function pickImageFromGallery(): Promise<string | null> {
  if (!await requestLibraryPermission("Permite accesul la fotografii pentru a alege o imagine.")) return null;
  let result: ImagePicker.ImagePickerResult;
  try {
    result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsMultipleSelection: false,
      quality: 0.6,
    });
  } catch {
    Alert.alert("Galerie indisponibilă", "Fotografiile nu pot fi deschise pe acest dispozitiv. Încearcă din nou.");
    return null;
  }
  if (result.canceled || !result.assets[0]) return null;

  return prepareRequestImage(result.assets[0]);
}

/** Photograph the work now rather than forcing a person through the gallery. */
export async function takeImageWithCamera(): Promise<string | null> {
  if (!await requestCameraPermission("Permite accesul la cameră pentru a face o fotografie.")) return null;
  let result: ImagePicker.ImagePickerResult;
  try {
    result = await ImagePicker.launchCameraAsync({
      mediaTypes: ["images"],
      quality: 0.6,
    });
  } catch {
    Alert.alert("Camera indisponibilă", "Nu am putut deschide camera pe acest dispozitiv. Încearcă din nou sau alege o fotografie din galerie.");
    return null;
  }
  if (result.canceled || !result.assets[0]) return null;
  return prepareRequestImage(result.assets[0]);
}

export async function pickChatImageFromGallery(): Promise<PickedMediaAsset | null> {
  if (!await requestLibraryPermission("Permite accesul la fotografii pentru a alege o imagine.")) return null;
  let result: ImagePicker.ImagePickerResult;
  try {
    result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsMultipleSelection: false,
      quality: 0.72,
    });
  } catch {
    Alert.alert("Galerie indisponibilă", "Fotografiile nu pot fi deschise pe acest dispozitiv. Încearcă din nou.");
    return null;
  }
  if (result.canceled || !result.assets[0]) return null;
  return prepareChatImage(result.assets[0]);
}

/**
 * Select several conversation attachments in one visit to the device picker.
 *
 * Chat messages retain one attachment per message in the API, so the composer
 * sends the chosen files as consecutive messages. This lets a person select a
 * small batch at once without introducing an opaque "album" object that
 * cannot be retried independently on a weak connection.
 */
export async function pickChatMediaFromGallery(): Promise<PickedMediaAsset[]> {
  if (!await requestLibraryPermission("Permite accesul la fotografii și filmări pentru a le trimite în conversație.")) return [];
  let result: ImagePicker.ImagePickerResult;
  try {
    result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images", "videos"],
      allowsMultipleSelection: true,
      selectionLimit: 6,
      quality: 0.72,
      videoMaxDuration: 90,
    });
  } catch {
    Alert.alert("Galerie indisponibilă", "Fotografiile și filmările nu pot fi deschise pe acest dispozitiv. Încearcă din nou.");
    return [];
  }
  if (result.canceled || !result.assets.length) return [];

  const prepared = await Promise.all(result.assets.slice(0, 6).map(async (asset) => {
    if (asset.type === "video") {
      return {
        uri: asset.uri,
        name: asset.fileName || `filmare-${Date.now()}.mp4`,
        type: asset.mimeType || "video/mp4",
        mediaType: "video" as const,
      };
    }
    return prepareChatImage(asset);
  }));
  return prepared.filter((asset): asset is PickedMediaAsset => Boolean(asset));
}

export async function takeChatPhoto(): Promise<PickedMediaAsset | null> {
  if (!await requestCameraPermission("Permite accesul la cameră pentru a face o fotografie.")) return null;
  let result: ImagePicker.ImagePickerResult;
  try {
    result = await ImagePicker.launchCameraAsync({
      mediaTypes: ["images"],
      quality: 0.72,
    });
  } catch {
    Alert.alert("Camera indisponibilă", "Nu am putut deschide camera pe acest dispozitiv. Încearcă din nou sau alege o fotografie din galerie.");
    return null;
  }
  if (result.canceled || !result.assets[0]) return null;
  return prepareChatImage(result.assets[0]);
}

export async function pickChatVideoFromGallery(): Promise<PickedMediaAsset | null> {
  if (!await requestLibraryPermission("Permite accesul la fotografii și filmări.")) return null;
  let result: ImagePicker.ImagePickerResult;
  try {
    result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["videos"],
      allowsMultipleSelection: false,
      quality: 0.7,
      videoMaxDuration: 90,
    });
  } catch {
    Alert.alert("Galerie indisponibilă", "Filmările nu pot fi deschise pe acest dispozitiv. Încearcă din nou.");
    return null;
  }
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];
  return {
    uri: asset.uri,
    name: asset.fileName || `filmare-${Date.now()}.mp4`,
    type: asset.mimeType || "video/mp4",
    mediaType: "video",
  };
}

export async function recordChatVideo(): Promise<PickedMediaAsset | null> {
  if (!await requestCameraPermission("Permite accesul la cameră pentru a înregistra o filmare.")) return null;
  let result: ImagePicker.ImagePickerResult;
  try {
    result = await ImagePicker.launchCameraAsync({
      mediaTypes: ["videos"],
      quality: 0.7,
      videoMaxDuration: 90,
    });
  } catch {
    Alert.alert("Camera indisponibilă", "Nu am putut deschide camera pentru filmare. Încearcă din nou sau alege un videoclip din galerie.");
    return null;
  }
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];
  return {
    uri: asset.uri,
    name: asset.fileName || `filmare-${Date.now()}.mp4`,
    type: asset.mimeType || "video/mp4",
    mediaType: "video",
  };
}
