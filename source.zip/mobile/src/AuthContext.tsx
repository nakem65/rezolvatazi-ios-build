import { PropsWithChildren, createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Platform } from "react-native";
import { apiConfigured, deleteProviderAccount, fetchCurrentProvider, logoutProvider, passkeysSupported, registerDevicePasskey, requestLoginCode, saveProviderProfile, setSessionToken, signInWithDevicePasskey, verifyLoginCode } from "./api";
import { readStoredToken, removeStoredToken, storeToken } from "./auth-storage";
import { demoProvider } from "./demo";
import { Provider, ProviderOnboarding } from "./types";
import { clearAllRequestDrafts, clearRequestDraft } from "./requestDraft";

type AuthStatus = "loading" | "signedOut" | "needsOnboarding" | "ready";

type AuthState = {
  status: AuthStatus;
  provider: Provider | null;
  isDemo: boolean;
  sendCode: (phone: string) => Promise<{ phone: string; note?: string; retryAfterSeconds?: number }>;
  verifyCode: (phone: string, code: string) => Promise<void>;
  passkeySupported: boolean;
  addPasskey: () => Promise<void>;
  signInWithPasskey: () => Promise<void>;
  completeOnboarding: (profile: ProviderOnboarding) => Promise<void>;
  setProvider: (provider: Provider) => void;
  signOut: () => Promise<void>;
  deleteAccount: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: PropsWithChildren) {
  const [status, setStatus] = useState<AuthStatus>("loading");
  const [provider, setProvider] = useState<Provider | null>(null);

  useEffect(() => {
    let active = true;
    void (async () => {
      const token = await readStoredToken();
      if (!token) {
        if (Platform.OS === "web" && apiConfigured) {
          try {
            const result = await fetchCurrentProvider();
            if (!active) return;
            setProvider(result.provider);
            setStatus(result.provider.onboardingComplete ? "ready" : "needsOnboarding");
            return;
          } catch {
            // Nu există o sesiune web recunoscută; continuăm cu autentificarea prin SMS.
          }
        }
        if (active) {
          setProvider(null);
          setStatus("signedOut");
        }
        return;
      }
      setSessionToken(token);
      try {
        const result = await fetchCurrentProvider();
        if (!active) return;
        setProvider(result.provider);
        setStatus(result.provider.onboardingComplete ? "ready" : "needsOnboarding");
      } catch {
        if (!active) return;
        if (apiConfigured) {
          setSessionToken(null);
          await removeStoredToken();
          setProvider(null);
          setStatus("signedOut");
        } else {
          setProvider(demoProvider);
          setStatus("ready");
        }
      }
    })();
    return () => { active = false; };
  }, []);

  const sendCode = useCallback(async (phone: string) => {
    return requestLoginCode(phone);
  }, []);

  const verifyCode = useCallback(async (phone: string, code: string) => {
    const result = await verifyLoginCode(phone, code);
    setSessionToken(result.token);
    await storeToken(result.token);
    setProvider(result.provider);
    setStatus(result.provider.onboardingComplete ? "ready" : "needsOnboarding");
  }, []);

  const finishAuthentication = useCallback(async (result: { token: string; provider: Provider }) => {
    setSessionToken(result.token);
    await storeToken(result.token);
    setProvider(result.provider);
    setStatus(result.provider.onboardingComplete ? "ready" : "needsOnboarding");
  }, []);

  const addPasskey = useCallback(async () => {
    const label = Platform.OS === "ios" ? "iPhone" : Platform.OS === "android" ? "Android" : "Browser";
    await registerDevicePasskey(label);
  }, []);

  const signInWithPasskey = useCallback(async () => {
    await finishAuthentication(await signInWithDevicePasskey());
  }, [finishAuthentication]);

  const completeOnboarding = useCallback(async (profile: ProviderOnboarding) => {
    const result = await saveProviderProfile(profile);
    setProvider(result.provider);
    setStatus("ready");
  }, []);

  const signOut = useCallback(async () => {
    try {
      if (provider?.id) await clearRequestDraft(provider.id);
      await logoutProvider();
    } finally {
      setSessionToken(null);
      await removeStoredToken();
      await clearAllRequestDrafts();
      setProvider(null);
      setStatus("signedOut");
    }
  }, [provider]);

  const deleteAccount = useCallback(async () => {
    if (provider?.id) await clearRequestDraft(provider.id);
    await deleteProviderAccount();
    setSessionToken(null);
    await removeStoredToken();
    await clearAllRequestDrafts();
    setProvider(null);
    setStatus("signedOut");
  }, [provider]);

  const value = useMemo<AuthState>(() => ({ status, provider, isDemo: !apiConfigured, sendCode, verifyCode, passkeySupported: passkeysSupported(), addPasskey, signInWithPasskey, completeOnboarding, setProvider, signOut, deleteAccount }), [status, provider, sendCode, verifyCode, addPasskey, signInWithPasskey, completeOnboarding, signOut, deleteAccount]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
