import { Alert, Platform, type AlertButton as NativeAlertButton } from "react-native";

export type AlertButton = NativeAlertButton;

export function showAppAlert(title: string, message?: string, buttons?: AlertButton[]) {
  if (Platform.OS === "web" && typeof window !== "undefined") {
    if (!buttons || buttons.length === 0) {
      window.alert(message ? `${title}\n\n${message}` : title);
      return;
    }

    if (buttons.length === 1) {
      window.alert(message ? `${title}\n\n${message}` : title);
      if (buttons[0]?.onPress) buttons[0].onPress();
      return;
    }

    const primaryBtn = buttons.find((b) => b.style !== "cancel") || buttons[0];
    const cancelBtn = buttons.find((b) => b.style === "cancel");

    const result = window.confirm(`${title}\n\n${message || ""}`);
    if (result) {
      if (primaryBtn?.onPress) primaryBtn.onPress();
    } else {
      if (cancelBtn?.onPress) cancelBtn.onPress();
    }
    return;
  }

  Alert.alert(title, message, buttons);
}
