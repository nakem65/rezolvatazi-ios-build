import { ROMANIAN_CITIES } from "./cities";
import { configuredUrl } from "./api/core";

export type PlacePurpose = "area" | "address";

export type PlaceSuggestion = {
  description: string;
  placeId?: string;
  isCustom?: boolean;
  source?: "google" | "manual";
};

export type PlaceSelection = {
  fullLabel: string;
  areaLabel: string;
  latitude: number | null;
  longitude: number | null;
  placeId?: string;
  county?: string | null;
  postalCode?: string | null;
};

type AddressComponent = {
  long_name?: string;
  short_name?: string;
  types?: string[];
};

const GOOGLE_API_KEY = process.env.EXPO_PUBLIC_GOOGLE_PLACES_API_KEY?.trim();
const LOCATION_REQUEST_TIMEOUT_MS = 4_500;

async function locationApi<T>(path: string): Promise<T | null> {
  if (!configuredUrl) return null;
  const controller = new AbortController();
  let timeout: ReturnType<typeof setTimeout> | null = null;
  try {
    const request = fetch(`${configuredUrl}${path}`, { signal: controller.signal });
    const deadline = new Promise<never>((_, reject) => {
      timeout = setTimeout(() => {
        controller.abort();
        reject(new Error("LOCATION_API_TIMEOUT"));
      }, LOCATION_REQUEST_TIMEOUT_MS);
    });
    const response = await Promise.race([request, deadline]);
    if (!response.ok) return null;
    return await response.json() as T;
  } catch {
    return null;
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

function component(components: AddressComponent[], type: string) {
  return components.find((item) => item.types?.includes(type))?.long_name?.trim() ?? "";
}

function withoutCountry(label: string) {
  return label.replace(/,\s*România\s*$/i, "").trim();
}

export function publicAreaFromComponents(components: AddressComponent[], fallback: string) {
  const sector = component(components, "sublocality_level_1")
    || component(components, "sublocality")
    || component(components, "neighborhood");
  const locality = component(components, "locality")
    || component(components, "postal_town")
    || component(components, "administrative_area_level_2");
  const county = component(components, "administrative_area_level_1");
  const parts = [sector, locality, county]
    .filter(Boolean)
    .filter((value, index, values) => values.findIndex((candidate) => candidate.toLocaleLowerCase("ro-RO") === value.toLocaleLowerCase("ro-RO")) === index);
  return parts.slice(0, 2).join(", ") || withoutCountry(fallback);
}

export async function getPlaceSuggestions(query: string, purpose: PlacePurpose = "area"): Promise<PlaceSuggestion[]> {
  const trimmed = query.trim();
  if (trimmed.length < 2) return [];

  const queryNorm = trimmed.toLocaleLowerCase("ro-RO");
  const matched = ROMANIAN_CITIES
    .filter((city) => city !== "Toată țara" && city.toLocaleLowerCase("ro-RO").includes(queryNorm))
    .slice(0, 5)
    .map((city) => ({ description: `${city}, România`, source: "manual" as const }));

  // On the request composer the free, exact address is the dependable route:
  // it is geocoded on Continue. Returning it synchronously prevents an
  // unavailable autocomplete provider from delaying the only visible action.
  if (purpose === "address" && trimmed.length >= 4) {
    return [{ description: trimmed, isCustom: true, source: "manual" as const }, ...matched].slice(0, 6);
  }

  const server = await locationApi<{ suggestions?: Array<{ description?: string; placeId?: string }> }>(
    `/api/locations/autocomplete?q=${encodeURIComponent(trimmed)}&purpose=${purpose}`,
  );
  if (server?.suggestions?.length) {
    return server.suggestions.flatMap((suggestion) => suggestion.description && suggestion.placeId
      ? [{ description: suggestion.description, placeId: suggestion.placeId, source: "google" as const }]
      : []).slice(0, 6);
  }

  if (GOOGLE_API_KEY) {
    try {
      const types = purpose === "area" ? "&types=(regions)" : "&types=geocode";
      const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(trimmed)}&components=country:ro${types}&language=ro&key=${GOOGLE_API_KEY}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.status === "OK" && Array.isArray(data.predictions)) {
        return data.predictions.slice(0, 6).map((prediction: { description?: string; place_id?: string }) => ({
          description: prediction.description ?? trimmed,
          placeId: prediction.place_id,
          source: "google",
        }));
      }
    } catch {
      // Tastarea liberă rămâne disponibilă dacă serviciul extern nu răspunde.
    }
  }

  return matched;
}

export async function getPlaceDetails(placeId: string): Promise<PlaceSelection | null> {
  const server = await locationApi<{ place?: PlaceSelection | null }>(
    `/api/locations/details?placeId=${encodeURIComponent(placeId)}`,
  );
  if (server?.place) return server.place;
  if (!GOOGLE_API_KEY || !placeId) return null;
  try {
    const fields = "formatted_address,address_components,geometry";
    const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${encodeURIComponent(placeId)}&fields=${encodeURIComponent(fields)}&language=ro&key=${GOOGLE_API_KEY}`;
    const res = await fetch(url);
    const data = await res.json();
    const result = data.result;
    const location = result?.geometry?.location;
    if (data.status === "OK" && location) {
      const components = Array.isArray(result.address_components) ? result.address_components as AddressComponent[] : [];
      const fullLabel = withoutCountry(result.formatted_address ?? "");
      return {
        fullLabel,
        areaLabel: publicAreaFromComponents(components, fullLabel),
        latitude: Number(location.lat),
        longitude: Number(location.lng),
        placeId,
        county: component(components, "administrative_area_level_1") || null,
        postalCode: component(components, "postal_code") || null,
      };
    }
  } catch {
    // Aplicația va permite confirmarea manuală sau folosirea locației telefonului.
  }
  return null;
}

export async function geocodeLocationQuery(query: string): Promise<PlaceSelection | null> {
  const trimmed = query.trim();
  if (trimmed.length < 3) return null;
  const server = await locationApi<{ place?: PlaceSelection | null }>(
    `/api/locations/geocode?q=${encodeURIComponent(trimmed)}`,
  );
  return server?.place ?? null;
}

export async function reverseGeocodeLocation(coordinates: { latitude: number; longitude: number }): Promise<PlaceSelection | null> {
  const server = await locationApi<{ place?: PlaceSelection | null }>(
    `/api/locations/reverse?latitude=${encodeURIComponent(coordinates.latitude)}&longitude=${encodeURIComponent(coordinates.longitude)}`,
  );
  return server?.place ?? null;
}

export async function getPlaceCoordinates(placeId: string): Promise<{ latitude: number; longitude: number } | null> {
  const place = await getPlaceDetails(placeId);
  return place && place.latitude !== null && place.longitude !== null
    ? { latitude: place.latitude, longitude: place.longitude }
    : null;
}
