export type AppMode = "client" | "neighbor" | "professional" | "hobby";
export type RequestMode = Exclude<AppMode, "client">;
export type WorkSolutionKind = "quotes" | "hourly" | "team" | "recurring" | "assessment";
export type ProviderEntityType = "individual" | "pfa" | "company";
export type ProviderCapabilityLevel = "can_do" | "experienced" | "specialist";
export type ProviderEquipmentId = "basic_tools" | "power_tools" | "ladder" | "car" | "van" | "garden_equipment" | "cleaning_equipment" | "protective_equipment";
export type RequestProfileType = "person" | "pfa" | "company" | "organization";
export type AccountProfileMemberRole = "owner" | "admin" | "worker";

export type AccountProfileMedia = {
  id: string;
  kind: "avatar" | "logo" | "portfolio";
  url: string;
  caption: string | null;
  sortOrder: number;
};

export type AccountProfile = {
  id: string;
  label: string;
  profileType: RequestProfileType;
  displayName: string;
  legalName: string | null;
  taxId: string | null;
  tradeRegistryNumber: string | null;
  avatarUrl: string | null;
  bio: string;
  clientRating: number;
  clientReviewCount: number;
  clientCompletedJobs: number;
  providerRating: number;
  providerReviewCount: number;
  providerCompletedJobs: number;
  identityStatus: "unverified" | "pending" | "verified" | "rejected";
  businessStatus: "unverified" | "pending" | "verified" | "rejected";
  status: "active" | "archived";
  role: AccountProfileMemberRole;
  canManage: boolean;
  media: AccountProfileMedia[];
  createdAt: string;
  updatedAt: string;
};

export type ProfileInvitation = {
  id: string;
  profileId: string;
  profileName: string;
  profileType: RequestProfileType;
  avatarUrl: string | null;
  role: Exclude<AccountProfileMemberRole, "owner">;
  invitedBy: string;
  createdAt: string;
};

export type OfferAssignmentMember = {
  accountId: string;
  name: string;
  avatarUrl: string | null;
  role: AccountProfileMemberRole;
  assignment: { id: string; status: "assigned" | "accepted" | "completed" } | null;
};

export type WorkAssignment = {
  id: string;
  offerId: string;
  status: "assigned" | "accepted" | "completed";
  profileId: string;
  profileName: string;
  profileAvatarUrl: string | null;
  assignedByName: string;
  createdAt: string;
  acceptedAt: string | null;
  completedAt: string | null;
  request: {
    id: string;
    description: string;
    category: string;
    urgency: string;
    city: string;
    locationLabel: string;
    contactName: string;
    contactPhone: string;
    status: string;
  };
};

export type ProviderWorkProfile = {
  entityType: ProviderEntityType;
  baseHourlyRateLei: number | null;
  minimumHours: number;
  bio: string;
  capabilities: Array<{
    categoryId: string;
    level: ProviderCapabilityLevel;
    hourlyRateLei: number | null;
  }>;
  equipment: ProviderEquipmentId[];
};

export type RequestProfile = {
  id: string;
  accountProfileId: string | null;
  label: string;
  profileType: RequestProfileType;
  displayName: string;
  legalName: string | null;
  taxId: string | null;
  tradeRegistryNumber: string | null;
  billingEmail: string | null;
  billingPhone: string | null;
  billingAddressLine1: string | null;
  billingAddressLine2: string | null;
  workAddressLine1: string | null;
  city: string;
  county: string | null;
  postalCode: string | null;
  countryCode: "RO";
  contactName: string | null;
  contactPhone: string | null;
  defaultInvoiceRequired: boolean;
  rating: number;
  reviewCount: number;
  completedJobs: number;
  avatarUrl: string | null;
  providerRating: number;
  providerReviewCount: number;
  providerCompletedJobs: number;
  isDefault: boolean;
  status: "active" | "archived";
  createdAt: string;
  updatedAt: string;
};

export type EarningAlertPreferences = {
  alwaysReceiveMatches: boolean;
  quietHoursStart: string | null;
  quietHoursEnd: string | null;
  days: number[];
  urgentEnabled: boolean;
  dailyLimit: number | null;
};

export type EarningProfile = {
  id: string;
  canManage: boolean;
  accountProfileId: string | null;
  label: string;
  entityType: ProviderEntityType;
  publicName: string;
  legalName: string | null;
  taxId: string | null;
  tradeRegistryNumber: string | null;
  canInvoice: boolean;
  identityStatus: "unverified" | "pending" | "verified" | "rejected";
  businessStatus: "unverified" | "pending" | "verified" | "rejected";
  city: string;
  latitude?: number | null;
  longitude?: number | null;
  radiusKm: number;
  baseHourlyRateLei: number | null;
  minimumHours: number;
  bio: string;
  rating: number;
  reviewCount: number;
  completedJobs: number;
  avatarUrl: string | null;
  clientRating: number;
  clientReviewCount: number;
  clientCompletedJobs: number;
  isDefault: boolean;
  isActive: boolean;
  status: "active" | "archived";
  capabilities: Array<{
    categoryId: string;
    level: ProviderCapabilityLevel;
    hourlyRateLei: number | null;
    minimumPriceLei: number | null;
  }>;
  equipment: ProviderEquipmentId[];
  alerts: EarningAlertPreferences;
  availability: { startsAt: string; endsAt: string } | null;
  createdAt: string;
  updatedAt: string;
};

export type StructuredWorkOrder = {
  id: string;
  legacyRequestId: string;
  requesterId?: string | null;
  solutionKind: WorkSolutionKind;
  pricingModel: "quote" | "hourly" | "estimate";
  riskClass: "low" | "standard" | "regulated";
  recurrenceLabel?: string | null;
  requiredParticipants: number;
  budgetBani?: number | null;
  intentSummary: string;
  intentConfidence: "scăzută" | "medie" | "ridicată";
  intentVersion: string;
  templateId: string;
  structuredDetailsJson: string;
  createdAt: string;
  updatedAt: string;
};

export type RecurringAgreement = {
  id: string;
  requestId: string;
  workOrderId: string;
  providerId: string;
  cadenceLabel: string;
  status: "active" | "completed" | "cancelled";
  completedCycles: number;
  lastCompletedAt?: string | null;
  nextDueAt?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type Review = {
  id: string;
  requestId: string;
  reviewerId: string;
  reviewerName: string;
  targetId: string;
  targetName: string;
  category?: string | null;
  score: number;
  comment: string;
  mediaUrls?: string[];
  replyText?: string;
  replyPhotoUrl?: string;
  replyVideoUrl?: string;
  createdAt: string;
  repliedAt?: string;
};

export type ServiceRequest = {
  id: string;
  description: string;
  category: string;
  urgency: string;
  city: string;
  locationLabel?: string | null;
  contactName: string;
  contactPhone: string;
  status: string;
  selectedOfferId: string | null;
  requestMode: RequestMode;
  isDemo: boolean;
  photos?: string[];
  clientPrice?: number;
  latitude?: number | null;
  longitude?: number | null;
  distanceKm?: number;
  clientRating?: number;
  clientReviewCount?: number;
  clientCompletedJobs?: number;
  requiredParticipants?: number;
  acceptedParticipantIds?: string[];
  acceptedParticipantCount?: number;
  shareActive?: boolean;
  genderRestriction?: "M" | "F" | "Other" | "Oricare";
  minAge?: number;
  workOrder?: StructuredWorkOrder | null;
  matchedEarningProfileId?: string;
  recurringAgreement?: RecurringAgreement | null;
  match?: {
    score: number;
    reasons: string[];
    cautions: string[];
    publicHourlyRateLei: number | null;
    availabilityUntil: string | null;
  } | null;
  createdAt: string;
  expiresAt: string;
};

export type ChatMessage = {
  id: string;
  requestId: string;
  offerId?: string | null;
  senderName: string;
  senderRole: "client" | "neighbor" | "professional" | "hobby";
  senderId?: string | null;
  messageType?: "text" | "image" | "video" | "audio" | "price_proposal" | "deleted";
  content: string;
  photoUrl?: string;
  videoUrl?: string;
  audioUrl?: string;
  attachmentId?: string | null;
  replyToMessageId?: string | null;
  replyToSenderName?: string;
  replyToContent?: string;
  isPriceProposal?: boolean;
  proposedPrice?: number;
  proposalStatus?: "pending" | "accepted" | "declined";
  isDeleted?: boolean;
  readByCount?: number;
  clientNonce?: string | null;
  editedAt?: string | null;
  deletedAt?: string | null;
  createdAt: string;
};

export type ChatInboxConversation = {
  requestId: string;
  offerId?: string | null;
  conversationKey: string;
  title: string;
  requestDescription: string;
  category: string;
  city: string;
  requestStatus: string;
  requestMode: string;
  userRole: "client" | "neighbor" | "professional" | "hobby";
  preAcceptance: boolean;
  latestMessage: {
    id: string;
    senderId?: string | null;
    senderName: string;
    messageType: string;
    preview: string;
    createdAt: string;
    isMine: boolean;
  };
  unreadCount: number;
};

export type Provider = {
  id: string;
  phone: string | null;
  name: string;
  clientName?: string;
  categories: string[];
  city: string;
  avatarUrl?: string | null;
  hobbyAvatarUrl?: string | null;
  neighborAvatarUrl?: string | null;
  radiusKm: number;
  age?: number;
  gender?: "M" | "F" | "Other";
  clientRating: number;
  clientReviewCount: number;
  clientCompletedJobs: number;
  rating: number;
  reviewCount: number;
  completedJobs: number;
  professionalRating: number;
  professionalReviewCount: number;
  professionalCompletedJobs: number;
  neighborRating: number;
  neighborReviewCount: number;
  neighborCompletedJobs: number;
  hobbyRating: number;
  hobbyReviewCount: number;
  hobbyCompletedJobs: number;
  hobbyPenaltyScore: number;
  isVerified: boolean;
  kycStatus: "unverified" | "pending" | "approved" | "rejected";
  idPhotoUrl?: string | null;
  selfieUrl?: string | null;
  isAvailable: boolean;
  helperAvailable: boolean;
  professionalAvailable: boolean;
  professionalAvailableUntil?: string | null;
  hobbyAvailable: boolean;
  onboardingComplete: boolean;
  helperEnabled: boolean;
  professionalEnabled: boolean;
  hobbyEnabled: boolean;
  notificationEnabled: boolean;
  latitude?: number | null;
  longitude?: number | null;
};

export type ProviderOnboarding = {
  name: string;
  clientName?: string;
  categories: string[];
  city: string;
  radiusKm: number;
  latitude?: number;
  longitude?: number;
  age?: number;
  gender?: "M" | "F" | "Other";
  helperEnabled: boolean;
  professionalEnabled: boolean;
  hobbyEnabled: boolean;
};

export type OfferPricingUnit = "job" | "hour" | "person_hour" | "km" | "sqm" | "item" | "visit" | "day" | "trip";
export type OfferTravelMode = "included" | "fixed" | "per_km";
export type OfferMaterialsMode = "included" | "excluded" | "estimated";
export type OfferVatMode = "included" | "excluded" | "not_applicable" | "unspecified";

export type OfferPricingDraft = {
  priceType: "estimate" | "fixed" | "free";
  unit: OfferPricingUnit;
  unitPriceLei: number;
  estimatedQuantity: number;
  minimumPriceLei: number;
  includedParticipants: number;
  travelMode: OfferTravelMode;
  travelFeeLei: number;
  travelRateLei: number;
  estimatedTravelKm: number;
  materialsMode: OfferMaterialsMode;
  materialsCostLei: number;
  vatMode: OfferVatMode;
  vatIncluded: boolean;
};

export type OfferPricing = {
  version: "offer-pricing-v1";
  currency: "RON";
  priceType: "estimate" | "fixed" | "free";
  unit: OfferPricingUnit;
  unitPriceBani: number;
  estimatedQuantity: number;
  minimumPriceBani: number;
  includedParticipants: number;
  travel: {
    mode: OfferTravelMode;
    feeBani: number;
    rateBani: number;
    estimatedKm: number;
  };
  materials: {
    mode: OfferMaterialsMode;
    estimatedCostBani: number;
  };
  vatMode: OfferVatMode;
  vatIncluded: boolean;
  estimatedTotalBani: number;
};

export type OfferDraft = {
  requestId: string;
  earningProfileId?: string;
  price: number;
  priceType: "estimate" | "fixed" | "free";
  visitFee: number;
  materialsIncluded: boolean;
  pricing?: OfferPricingDraft;
  etaMinutes: number;
  message: string;
};

export type SentOffer = Omit<OfferDraft, "pricing"> & {
  id: string;
  pricing?: OfferPricing | null;
  estimatedTotalBani?: number | null;
  includedParticipants?: number;
  lifecycleState?: "active" | "withdrawn";
  revision: number;
  updatedAt?: string | null;
  withdrawnAt?: string | null;
  canManageTeam?: boolean;
  request: ServiceRequest;
  status: "pending" | "accepted" | "declined" | "withdrawn";
  customerRating: Review | null;
  createdAt: string;
};

export type ProviderBilling = {
  pendingBani: number;
  waivedJobs: number;
  freeJobsRemaining: number;
  successFeeBani: number;
  betaFree: boolean;
  charges: Array<{ id: string; requestId: string; amountBani: number; status: "waived" | "pending" | "paid"; createdAt: string; paidAt: string | null }>;
};

export type MyRequest = ServiceRequest & { offerCount: number };

export type CustomerOffer = {
  id: string;
  requestId: string;
  providerId: string;
  earningProfileId?: string | null;
  providerName: string;
  providerPhone: string | null;
  providerRating: number;
  providerReviewCount: number;
  providerCompletedJobs?: number;
  providerVerified: boolean;
  providerTrustLabel: string;
  price: number;
  priceType: "estimate" | "fixed" | "free";
  visitFee: number;
  materialsIncluded: boolean;
  pricing?: OfferPricing | null;
  estimatedTotalBani?: number | null;
  includedParticipants?: number;
  etaMinutes: number;
  message: string;
  revision: number;
  updatedAt?: string | null;
  selected: boolean;
  createdAt: string;
};

export type MyRequestDetail = {
  request: ServiceRequest;
  workOrder?: StructuredWorkOrder | null;
  recurringAgreement?: RecurringAgreement | null;
  offers: CustomerOffer[];
  rating: { id: string; providerId: string; score: number; comment: string } | null;
  ratings?: Array<{ id: string; providerId: string; score: number; comment: string }>;
};

export type RequestDraft = {
  description: string;
  category: string;
  urgency: string;
  city: string;
  locationLabel?: string;
  requestMode: RequestMode;
  requestProfileId?: string;
  clientPrice?: number;
  latitude?: number;
  longitude?: number;
  photos?: string[];
  requiredParticipants?: number;
  genderRestriction?: "M" | "F" | "Other" | "Oricare";
  minAge?: number;
  solutionKind?: WorkSolutionKind;
  recurrenceLabel?: string;
  intentSummary?: string;
  intentConfidence?: "scăzută" | "medie" | "ridicată";
  intentVersion?: string;
  intentAnswers?: Record<string, string | number | boolean>;
};
