import { useEffect, useRef, useState } from "react";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useLocalSearchParams } from "expo-router";
import { Keyboard, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View, Image } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "@/src/AuthContext";
import { colors, shadow } from "@/src/theme";
import appIcon from "../assets/icon.png";

import { ScrollView } from "react-native";

export default function SignInScreen() {
  const params = useLocalSearchParams<{ returnTo?: string }>();
  const { sendCode, verifyCode, passkeySupported, signInWithPasskey } = useAuth();
  const [step, setStep] = useState<"phone" | "code">("phone");
  const [phone, setPhone] = useState("");
  const [normalizedPhone, setNormalizedPhone] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [resendSeconds, setResendSeconds] = useState(0);
  const [deliveryState, setDeliveryState] = useState<"idle" | "sending" | "sent" | "unconfirmed" | "failed">("idle");
  const [deliveryNote, setDeliveryNote] = useState("");
  const sendAttempt = useRef(0);
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    if (step !== "code" || (deliveryState !== "sent" && deliveryState !== "unconfirmed") || resendSeconds <= 0) return;
    const timer = setInterval(() => {
      setResendSeconds((current) => Math.max(0, current - 1));
    }, 1_000);
    return () => clearInterval(timer);
  }, [deliveryState, resendSeconds, step]);

  function handlePhoneChange(val: string) {
    let digits = val.replace(/\D/g, "");
    if (digits.startsWith("0040")) digits = digits.slice(4);
    else if (digits.startsWith("40")) digits = digits.slice(2);
    if (digits.startsWith("0")) digits = digits.slice(1);
    setPhone(digits.slice(0, 9));
    if (error) setError("");
  }

  function deliveryError(caught: unknown) {
    const message = caught instanceof Error ? caught.message : "";
    if (/conexiunea|contacta serviciul|durat prea mult|timeout|fetch failed/i.test(message)) {
      return "Nu am putut confirma trimiterea SMS-ului acum. Numărul rămâne aici; încearcă din nou peste câteva secunde.";
    }
    return message || "Codul nu a putut fi trimis. Încearcă din nou.";
  }

  function deliveryMayStillArrive(caught: unknown) {
    const message = caught instanceof Error ? caught.message : "";
    // The request response can be lost after the Worker has handed the SMS to
    // the gateway. Do not make a code unusable merely because the phone did
    // not receive that confirmation response.
    return /conexiunea|contacta serviciul|durat prea mult|timeout|fetch failed|network request failed|network error/i.test(message);
  }

  function requestCode(preserveTypedCode = step === "code") {
    const digits = phone.replace(/\D/g, "");
    const phoneForApi = /^7\d{8}$/.test(digits) ? `+40${digits}` : "";
    if (!phoneForApi) {
      setError("Te rugăm să introduci un număr mobil din România valid (ex: 0722123456).");
      return;
    }
    const attempt = ++sendAttempt.current;
    setBusy(false);
    setError("");
    // A resend always keeps the same valid server challenge. Do not erase a
    // code the person may have already pasted while waiting for delivery.
    if (!preserveTypedCode) setCode("");
    setNormalizedPhone(phoneForApi);
    setResendSeconds(0);
    setDeliveryNote("");
    setDeliveryState("sending");
    // Enter the code screen immediately. Carrier delivery is asynchronous and
    // must never leave someone staring at a blocked form for 15–20 seconds.
    setStep("code");
    requestAnimationFrame(() => Keyboard.dismiss());
    void sendCode(phoneForApi).then((result) => {
      if (sendAttempt.current !== attempt) return;
      setNormalizedPhone(result.phone);
      setDeliveryNote(result.note ?? "");
      setDeliveryState("sent");
      setResendSeconds(Math.max(0, Math.min(30, Math.ceil(result.retryAfterSeconds ?? 30))));
    }).catch((caught) => {
      if (sendAttempt.current !== attempt) return;
      if (deliveryMayStillArrive(caught)) {
        setDeliveryState("unconfirmed");
        setDeliveryNote("Nu am putut confirma cererea de SMS. Dacă primești codul, îl poți introduce; dacă nu, retrimite codul.");
        // Retrying is safe: the server reuses the first valid code during its
        // cooldown, so a lost client response cannot create two active codes.
        setResendSeconds(0);
      } else {
        setDeliveryState("failed");
        setError(deliveryError(caught));
      }
    });
  }

  // On iPad the software keyboard can cover the lower half of an iPhone-sized
  // compatibility layout. Keep the primary action reachable instead of relying
  // on a particular device's keyboard inset behavior.
  function revealPrimaryAction() {
    requestAnimationFrame(() => scrollRef.current?.scrollToEnd({ animated: true }));
  }

  async function confirmCode() {
    if (deliveryState === "sending") {
      setError("Trimitem codul. Așteaptă confirmarea înainte să îl introduci.");
      return;
    }
    if (deliveryState !== "sent" && deliveryState !== "unconfirmed") {
      setError("Codul nu a fost trimis. Apasă „Retrimite codul” ca să încerci din nou.");
      return;
    }
    if (!/^\d{6}$/.test(code)) {
      setError("Introdu toate cele 6 cifre din SMS.");
      return;
    }
    setBusy(true); setError("");
    try {
      await verifyCode(normalizedPhone, code);
      if (params.returnTo === "/new-request" && router.canGoBack()) router.back();
      else if (params.returnTo === "/work-profile") router.replace("/work-profile");
      else if (params.returnTo === "/profiles") router.replace("/profiles");
      else router.replace("/");
    }
    catch (caught) { setError(caught instanceof Error ? caught.message : "Nu am putut verifica acest cod. Te rugăm să încerci din nou."); }
    finally { setBusy(false); }
  }

  async function continueWithPasskey() {
    setBusy(true); setError("");
    try {
      await signInWithPasskey();
      if (params.returnTo === "/new-request" && router.canGoBack()) router.back();
      else if (params.returnTo === "/work-profile") router.replace("/work-profile");
      else if (params.returnTo === "/profiles") router.replace("/profiles");
      else router.replace("/");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Passkey-ul nu a putut fi folosit. Conectează-te prin SMS.");
    } finally { setBusy(false); }
  }

  return (
    <SafeAreaView style={styles.safe} edges={["top", "bottom"]}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={Platform.OS === "ios" ? 8 : 0}>
        <ScrollView
          ref={scrollRef}
          style={styles.flex}
          contentContainerStyle={styles.scrollContent}
          contentInsetAdjustmentBehavior="automatic"
          keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.shell}>
            <View style={styles.hero}>
              <View style={styles.brand}>
                <Image source={appIcon} style={styles.logo} />
                <Text style={styles.brandText}>Rezolvat<Text style={styles.brandAccent}>Azi</Text></Text>
              </View>
              <Text style={styles.heroTitle}>Spune ce ai nevoie.</Text>
              <Text style={styles.heroCopy}>Găsește oameni potriviți din apropiere.</Text>
            </View>

            <View style={styles.formSheet}>
              <Text style={styles.title}>{step === "phone" ? "Intră în cont" : "Introdu codul primit"}</Text>
              <Text style={styles.subtitle}>
                {step === "phone"
                  ? "Îți trimitem un cod prin SMS."
                  : deliveryState === "sending"
                    ? `Trimitem codul la ${normalizedPhone}. Poți rămâne pe acest ecran.`
                    : deliveryState === "unconfirmed"
                      ? "Nu am putut confirma trimiterea. Dacă primești codul, îl poți introduce mai jos."
                    : deliveryState === "failed"
                      ? "Codul nu a plecat. Încearcă din nou fără să reintroduci numărul."
                    : `Am trimis un cod prin SMS la ${normalizedPhone}. Același cod rămâne valabil 10 minute, inclusiv dacă îl retrimiți.`}
              </Text>
              {step === "phone" ? (
                <>
                  <Text style={styles.label}>Număr de telefon</Text>
                  <View style={styles.inputShell}>
                    <View style={styles.country}><Text style={styles.flag}>🇷🇴</Text><Text style={styles.countryCode}>+40</Text></View>
                    <TextInput accessibilityLabel="Număr de telefon" value={phone} onChangeText={handlePhoneChange} onFocus={revealPrimaryAction} keyboardType="phone-pad" autoComplete="tel" placeholder="7xx xxx xxx" placeholderTextColor="#99A19A" style={styles.input} />
                  </View>
                </>
              ) : (
                <>
                  <Text style={styles.label}>Cod SMS</Text>
                  <TextInput
                    accessibilityLabel="Cod primit prin SMS"
                    value={code}
                    onChangeText={(value) => { setCode(value.replace(/\D/g, "").slice(0, 6)); if (error) setError(""); }}
                    onFocus={revealPrimaryAction}
                    onSubmitEditing={() => void confirmCode()}
                    keyboardType="number-pad"
                    inputMode="numeric"
                    autoComplete={Platform.OS === "android" ? "sms-otp" : "one-time-code"}
                    textContentType="oneTimeCode"
                    importantForAutofill="yes"
                    placeholder="••••••"
                    placeholderTextColor="#99A19A"
                    style={[styles.input, styles.codeInput]}
                  />
                </>
              )}
              {error ? <Text accessibilityLiveRegion="assertive" style={styles.error}>{error}</Text> : null}
              {deliveryNote ? <Text accessibilityLiveRegion="polite" style={styles.deliveryNote}>{deliveryNote}</Text> : null}
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={step === "phone" ? "Continuă cu SMS" : "Verifică și continuă"}
                disabled={busy || (step === "code" && deliveryState === "sending")}
                onPress={() => void (step === "phone" ? requestCode() : confirmCode())}
                style={({ pressed }) => [styles.primary, (pressed || busy || (step === "code" && deliveryState === "sending")) && styles.pressed]}
              >
                <Text style={styles.primaryText}>{busy ? "Te rugăm așteaptă..." : step === "phone" ? "Continuă cu SMS" : deliveryState === "sending" ? "Trimitem codul..." : "Verifică și continuă"}</Text>
                <View style={styles.primaryArrow}><MaterialCommunityIcons name="arrow-right" size={20} color={colors.ink} /></View>
              </Pressable>
              {step === "phone" && passkeySupported ? (
                <>
                  <View style={styles.dividerRow}><View style={styles.divider} /><Text style={styles.dividerText}>sau</Text><View style={styles.divider} /></View>
                  <Pressable accessibilityRole="button" disabled={busy} onPress={() => void continueWithPasskey()} style={({ pressed }) => [styles.passkey, (pressed || busy) && styles.pressed]}>
                    <MaterialCommunityIcons name="key-variant" size={19} color={colors.ink} />
                    <Text style={styles.passkeyText}>Intră cu passkey</Text>
                  </Pressable>
                  <Text style={styles.passkeyHint}>Folosește codul telefonului, Face ID, Touch ID sau amprenta, dacă ai adăugat anterior o passkey.</Text>
                </>
              ) : null}
              {step === "code" ? (
                <View style={styles.codeActions}>
                  <Pressable
                    accessibilityRole="button"
                    disabled={busy || deliveryState === "sending" || resendSeconds > 0}
                    onPress={() => void requestCode(true)}
                  >
                    <Text style={[styles.change, resendSeconds > 0 && styles.changeDisabled]}>
                      {deliveryState === "sending" ? "Trimitem codul…" : resendSeconds > 0 ? `Retrimite codul în ${resendSeconds}s` : "Retrimite codul"}
                    </Text>
                  </Pressable>
                  <Pressable accessibilityRole="button" onPress={() => { sendAttempt.current += 1; setStep("phone"); setCode(""); setError(""); setResendSeconds(0); setDeliveryState("idle"); }}>
                    <Text style={styles.change}>Schimbă numărul</Text>
                  </Pressable>
                </View>
              ) : null}

              <View style={styles.trustRow}>
                <MaterialCommunityIcons name="shield-check-outline" size={16} color={colors.mintDark} />
                <Text style={styles.trustText}>Numărul tău nu este afișat public.</Text>
              </View>
            </View>

            <View style={styles.legal}><Text style={styles.legalCopy}>Continuând, accepți </Text><Pressable onPress={() => router.push({ pathname: "/legal/[document]", params: { document: "terms" } })}><Text style={styles.legalLink}>termenii</Text></Pressable><Text style={styles.legalCopy}> și </Text><Pressable onPress={() => router.push({ pathname: "/legal/[document]", params: { document: "privacy" } })}><Text style={styles.legalLink}>confidențialitatea</Text></Pressable><Text style={styles.legalCopy}>.</Text></View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream }, flex: { flex: 1 },
  scrollContent: { flexGrow: 1, backgroundColor: colors.cream, paddingBottom: 28 },
  shell: { width: "100%", maxWidth: 540, alignSelf: "center", flexGrow: 1, paddingBottom: 22 },
  hero: { backgroundColor: colors.cream, paddingHorizontal: 24, paddingTop: 28, paddingBottom: 26 },
  brand: { flexDirection: "row", alignItems: "center", gap: 9, zIndex: 2 },
  logo: { width: 42, height: 42, borderRadius: 13 },
  brandText: { color: colors.ink, fontSize: 18, fontWeight: "900" },
  brandAccent: { color: colors.accent },
  heroTitle: { color: colors.ink, fontSize: 29, lineHeight: 35, fontWeight: "900", letterSpacing: -0.9, marginTop: 36, maxWidth: 390 },
  heroCopy: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 5, maxWidth: 390 },
  formSheet: { marginHorizontal: 20, backgroundColor: colors.paper, borderRadius: 22, borderWidth: 1, borderColor: colors.line, padding: 22, ...shadow },
  stepRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  stepBadge: { width: 36, height: 36, borderRadius: 12, backgroundColor: colors.dangerSoft, alignItems: "center", justifyContent: "center" },
  stepLabel: { color: colors.accentDark, fontSize: 11, fontWeight: "900", letterSpacing: 0.8 },
  title: { color: colors.ink, fontSize: 23, lineHeight: 29, fontWeight: "900", letterSpacing: -0.6 },
  subtitle: { color: colors.muted, fontSize: 14, lineHeight: 20, marginTop: 5, marginBottom: 24 },
  label: { color: colors.ink, fontSize: 13, fontWeight: "800", marginBottom: 8 },
  inputShell: { height: 57, borderWidth: 1, borderColor: colors.line, borderRadius: 15, flexDirection: "row", alignItems: "center", backgroundColor: "#FAFAF7", overflow: "hidden" },
  country: { height: "100%", flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, borderRightWidth: 1, borderRightColor: colors.line },
  flag: { fontSize: 17 },
  countryCode: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  input: { flex: 1, height: 55, paddingHorizontal: 13, color: colors.ink, fontSize: 17, backgroundColor: "#FAFAF7" },
  codeInput: { flex: 0, width: "100%", borderWidth: 1, borderColor: colors.line, borderRadius: 15, fontSize: 24, letterSpacing: 7, textAlign: "center" },
  error: { color: colors.accentDark, backgroundColor: colors.dangerSoft, borderRadius: 10, padding: 11, fontSize: 12, lineHeight: 17, fontWeight: "700", marginTop: 10 },
  deliveryNote: { color: colors.mintDark, backgroundColor: "#EDF8F1", borderRadius: 10, padding: 11, fontSize: 12, lineHeight: 17, fontWeight: "700", marginTop: 10 },
  primary: { minHeight: 56, backgroundColor: colors.accent, borderRadius: 16, marginTop: 14, paddingLeft: 17, paddingRight: 7, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  primaryArrow: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.lime, alignItems: "center", justifyContent: "center" },
  pressed: { opacity: 0.75 },
  primaryText: { color: colors.paper, fontSize: 15, fontWeight: "900" },
  change: { color: colors.accent, textAlign: "center", fontSize: 12, lineHeight: 18, fontWeight: "800", marginTop: 15 },
  changeDisabled: { color: colors.muted },
  codeActions: { flexDirection: "row", justifyContent: "center", gap: 20, flexWrap: "wrap" },
  altAuth: { marginTop: 18 },
  dividerRow: { flexDirection: "row", alignItems: "center", marginBottom: 13 },
  divider: { flex: 1, height: 1, backgroundColor: colors.line },
  dividerText: { marginHorizontal: 10, color: colors.muted, fontSize: 11, fontWeight: "800" },
  google: { height: 50, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10 },
  googleText: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  passkey: { minHeight: 50, borderWidth: 1, borderColor: colors.line, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, backgroundColor: colors.paper },
  passkeyText: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  passkeyHint: { color: colors.muted, fontSize: 11, lineHeight: 15, textAlign: "center", marginTop: 8 },
  trustRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, marginTop: 16 },
  trustText: { color: colors.muted, fontSize: 12, fontWeight: "600" },
  legal: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", paddingHorizontal: 20, marginTop: 20 },
  legalCopy: { color: colors.muted, fontSize: 12, lineHeight: 17 },
  legalLink: { color: colors.accent, fontSize: 12, lineHeight: 17, fontWeight: "800", textDecorationLine: "underline" },
});
