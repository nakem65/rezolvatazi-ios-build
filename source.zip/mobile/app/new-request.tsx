import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Alert, BackHandler, Image, Keyboard, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View, ActivityIndicator } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import * as Location from "expo-location";
import { analyzeWorkIntentRemote, createRequest, createRequestProfile, fetchRequestProfiles } from "@/src/api";
import type { RemoteIntentAnalysis, RemoteIntentAnswer } from "@/src/api";
import { categories, hasEmergencyRisk } from "@/src/classify";
import { useAuth } from "@/src/AuthContext";
import { colors } from "@/src/theme";
import { RequestMode, RequestProfile, RequestProfileType } from "@/src/types";
import { CityAutocompleteInput } from "@/components/CityAutocompleteInput";
import { pickImageFromGallery, takeImageWithCamera } from "@/src/mediaPicker";
import { analyzeWorkIntent, type WorkIntent, WorkSolutionKind } from "@/src/workIntent";
import { reverseGeocodeLocation, type PlaceSelection } from "@/src/googlePlaces";
import { resolveWithinTimeout, resolveTypedRomanianLocation, selectionFromReverseGeocode } from "@/src/location";
import { clearRequestDraft, loadRequestDraft, saveRequestDraft } from "@/src/requestDraft";
import { isValidRomanianTaxId, normalizeRomanianTaxId } from "@/src/romanianTaxId";
import { triggerFeedback } from "@/src/feedback";

const urgencyOptions = ["Acum", "Astăzi", "În 24 de ore"];
const recurrenceOptions = ["Zilnic", "De două ori pe săptămână", "Săptămânal", "La 2 săptămâni", "Lunar", "Alt interval"];
const solutionLabels: Record<WorkSolutionKind, string> = {
  quotes: "Compar oferte",
  hourly: "Plată la oră",
  team: "Echipă",
  recurring: "Lucrare recurentă",
  assessment: "Constatare",
};
const quickPrompts = [
  { label: "Mut ceva", text: "Am nevoie de ajutor la o mutare și de persoane pentru cărat" },
  { label: "Curte", text: "Am nevoie de cineva să tundă iarba din curte" },
  { label: "Curățenie", text: "Caut curățenie pentru apartament o dată pe săptămână" },
  { label: "Montaj", text: "Am nevoie de montaj pentru un dulap" },
] as const;

function inferRecurrenceLabel(value: string) {
  const normalized = value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("ro-RO");
  if (
    /(?:de doua ori|2 ori|doua vizite).{0,24}(?:pe |in )?saptaman/u.test(normalized)
    || /(?:pe |in )?saptaman.{0,24}(?:de doua ori|2 ori|doua vizite)/u.test(normalized)
  ) return "De două ori pe săptămână";
  if (normalized.includes("la 2 sapt")) return "La 2 săptămâni";
  if (normalized.includes("lunar") || normalized.includes("in fiecare luna")) return "Lunar";
  if (normalized.includes("zilnic") || normalized.includes("in fiecare zi")) return "Zilnic";
  if (normalized.includes("saptaman")) return "Săptămânal";
  return null;
}

function isPlaceholderProfileName(value: string | null | undefined) {
  const normalized = (value ?? "").trim().toLocaleLowerCase("ro-RO");
  return normalized === "utilizator nou" || normalized === "prestator nou";
}

type NewRequestDraft = {
  step: number;
  description: string;
  category: string;
  urgency: string;
  city: string;
  locationLabel: string;
  clientPrice: string;
  location: { latitude: number; longitude: number } | null;
  requiredParticipants: string;
  participantsTouched: boolean;
  solutionKind: WorkSolutionKind;
  solutionTouched: boolean;
  categoryTouched: boolean;
  intentSummaryDraft: string;
  summaryTouched: boolean;
  recurrence: string;
  customRecurrence: string;
  clarificationAnswers: Record<string, RemoteIntentAnswer>;
  photos: string[];
  selectedRequestProfileId: string;
};

export default function NewRequestScreen() {
  const { provider, setProvider, status } = useAuth();
  const providerId = provider?.id;
  const providerName = provider?.name;
  const [step, setStep] = useState(0);
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Altele");
  const [urgency, setUrgency] = useState("Astăzi");
  const [city, setCity] = useState(provider?.city ?? "București");
  const [locationLabel, setLocationLabel] = useState(provider?.city ?? "");
  const [clientPrice, setClientPrice] = useState("");
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const requestMode: RequestMode = "professional";
  const [requiredParticipants, setRequiredParticipants] = useState("1");
  const [participantsTouched, setParticipantsTouched] = useState(false);
  const [solutionKind, setSolutionKind] = useState<WorkSolutionKind>("quotes");
  const [solutionTouched, setSolutionTouched] = useState(false);
  const [categoryTouched, setCategoryTouched] = useState(false);
  const [intentSummaryDraft, setIntentSummaryDraft] = useState("");
  const [summaryTouched, setSummaryTouched] = useState(false);
  const [recurrence, setRecurrence] = useState("Săptămânal");
  const [customRecurrence, setCustomRecurrence] = useState("");
  const [remoteAnalysis, setRemoteAnalysis] = useState<RemoteIntentAnalysis | null>(null);
  // Once the person continues, keep the controls on the next page stable.
  // A slow AI result remains useful for publishing, but cannot move controls
  // underneath someone or make the flow appear frozen.
  const [analysisForFlow, setAnalysisForFlow] = useState<RemoteIntentAnalysis | null>(null);
  const [intentForFlow, setIntentForFlow] = useState<WorkIntent | null>(null);
  const [clarificationAnswers, setClarificationAnswers] = useState<Record<string, RemoteIntentAnswer>>({});
  const [flowBusy, setFlowBusy] = useState(false);
  const analysisSequence = useRef(0);
  const analysisAbortController = useRef<AbortController | null>(null);
  const stepRef = useRef(step);
  const [photos, setPhotos] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [requestProfiles, setRequestProfiles] = useState<RequestProfile[]>([]);
  const [selectedRequestProfileId, setSelectedRequestProfileId] = useState("");
  const [profilesLoading, setProfilesLoading] = useState(Boolean(provider));
  const [requestProfilesLoaded, setRequestProfilesLoaded] = useState(!provider);
  const [addingProfile, setAddingProfile] = useState(false);
  const [profileType, setProfileType] = useState<RequestProfileType>("person");
  const [profileLabel, setProfileLabel] = useState("Eu");
  const [profileName, setProfileName] = useState(isPlaceholderProfileName(provider?.name) ? "" : provider?.name ?? "");
  const [profileLegalName, setProfileLegalName] = useState("");
  const [profileTaxId, setProfileTaxId] = useState("");
  const [profileBillingEmail, setProfileBillingEmail] = useState("");
  const [profileBillingAddress, setProfileBillingAddress] = useState("");
  const profileModeTouched = useRef(false);
  const profileModeOwner = useRef<string | null>(null);
  const [editingFromSummary, setEditingFromSummary] = useState(false);
  const [draftReady, setDraftReady] = useState(false);
  const [draftLoadReliable, setDraftLoadReliable] = useState(false);
  const loadedDraftOwner = useRef<string | null | undefined>(undefined);
  const draftWriteGeneration = useRef(0);
  const intent = useMemo(() => analyzeWorkIntent(description), [description]);
  const stableIntent = step > 0 ? intentForFlow ?? intent : intent;
  const effectiveSolutions = analysisForFlow?.ready && analysisForFlow.eligibleSolutions.length
    ? analysisForFlow.eligibleSolutions
    : stableIntent.solutions;
  const effectiveRecommended = analysisForFlow?.ready && analysisForFlow.recommendedSolution
    ? analysisForFlow.recommendedSolution
    : stableIntent.recommended;
  const selectedSolution = effectiveSolutions.some((solution) => solution.kind === solutionKind)
    ? solutionKind
    : effectiveRecommended;
  const effectiveEmergency = hasEmergencyRisk(description) || Boolean(remoteAnalysis?.emergency);
  const visibleStep = step;
  const totalSteps = 6;

  useEffect(() => {
    stepRef.current = step;
  }, [step]);

  function draftSnapshot(): NewRequestDraft {
    return {
      step: editingFromSummary ? 5 : step,
      description,
      category,
      urgency,
      city,
      locationLabel,
      clientPrice,
      location,
      requiredParticipants,
      participantsTouched,
      solutionKind,
      solutionTouched,
      categoryTouched,
      intentSummaryDraft,
      summaryTouched,
      recurrence,
      customRecurrence,
      clarificationAnswers,
      photos,
      selectedRequestProfileId,
    };
  }

  useEffect(() => {
    const ownerId = provider?.id ?? null;
    const previousOwner = loadedDraftOwner.current;
    const hasCurrentDraft = Boolean(description.trim() || photos.length);
    if (previousOwner === null && ownerId && hasCurrentDraft) {
      loadedDraftOwner.current = ownerId;
      setDraftLoadReliable(true);
      void saveRequestDraft(draftSnapshot(), ownerId).then((saved) => {
        if (saved) setDraftLoadReliable(true);
        return clearRequestDraft(null);
      });
      return;
    }
    let active = true;
    setDraftReady(false);
    setDraftLoadReliable(false);
    void loadRequestDraft<NewRequestDraft>(ownerId).then((result) => {
      if (!active) return;
      setDraftLoadReliable(result.status === "loaded");
      const draft = result.draft;
      if (!draft) return;
      setStep(Math.max(0, Math.min(5, draft.step ?? 0)));
      setDescription(draft.description ?? "");
      setCategory(draft.category ?? "Altele");
      setUrgency(draft.urgency ?? "Astăzi");
      setCity(draft.city ?? "");
      setLocationLabel(draft.locationLabel ?? "");
      setClientPrice(draft.clientPrice ?? "");
      setLocation(draft.location ?? null);
      setRequiredParticipants(draft.requiredParticipants ?? "1");
      setParticipantsTouched(Boolean(draft.participantsTouched));
      setSolutionKind(draft.solutionKind ?? "quotes");
      setSolutionTouched(Boolean(draft.solutionTouched));
      setCategoryTouched(Boolean(draft.categoryTouched));
      setIntentSummaryDraft(draft.intentSummaryDraft ?? "");
      setSummaryTouched(Boolean(draft.summaryTouched));
      setRecurrence(draft.recurrence ?? "Săptămânal");
      setCustomRecurrence(draft.customRecurrence ?? "");
      setClarificationAnswers(draft.clarificationAnswers ?? {});
      setPhotos((draft.photos ?? []).slice(0, 2));
      setSelectedRequestProfileId(draft.selectedRequestProfileId ?? "");
    }).finally(() => {
      if (active) {
        loadedDraftOwner.current = ownerId;
        setDraftReady(true);
      }
    });
    return () => {
      active = false;
    };
    // Only an ownership change should reload and replace the entire draft.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [provider?.id]);

  useEffect(() => {
    if (!draftReady) return;
    const generation = draftWriteGeneration.current;
    const timer = setTimeout(() => {
      if (draftWriteGeneration.current !== generation) return;
      if (!description.trim() && photos.length === 0) {
        if (draftLoadReliable) void clearRequestDraft(provider?.id);
      } else {
        void saveRequestDraft(draftSnapshot(), provider?.id).then((saved) => {
          if (saved && draftWriteGeneration.current === generation) setDraftLoadReliable(true);
        });
      }
    }, 350);
    return () => clearTimeout(timer);
    // All serialized draft fields are listed explicitly below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    category,
    categoryTouched,
    city,
    clarificationAnswers,
    clientPrice,
    customRecurrence,
    description,
    draftLoadReliable,
    draftReady,
    editingFromSummary,
    intentSummaryDraft,
    location,
    locationLabel,
    participantsTouched,
    photos,
    recurrence,
    requiredParticipants,
    selectedRequestProfileId,
    solutionKind,
    solutionTouched,
    step,
    summaryTouched,
    urgency,
    provider?.id,
  ]);

  useFocusEffect(useCallback(() => {
    if (Platform.OS === "web") return undefined;
    const subscription = BackHandler.addEventListener("hardwareBackPress", () => {
      goBack();
      return true;
    });
    return () => subscription.remove();
    // Re-subscribe only when the values used by goBack change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [description, editingFromSummary, photos.length, step]));

  useEffect(() => () => analysisAbortController.current?.abort(), []);

  useEffect(() => {
    if (profileModeOwner.current !== (providerId ?? null)) {
      profileModeOwner.current = providerId ?? null;
      profileModeTouched.current = false;
    }
    if (!providerId || status === "signedOut") {
      setRequestProfilesLoaded(true);
      setProfilesLoading(false);
      return;
    }
    let active = true;
    setRequestProfilesLoaded(false);
    setProfilesLoading(true);
    void fetchRequestProfiles().then(({ profiles }) => {
      if (!active) return;
      const usableProfiles = profiles.filter((profile) => !isPlaceholderProfileName(profile.displayName));
      setRequestProfiles(usableProfiles);
      setSelectedRequestProfileId((current) => usableProfiles.some((profile) => profile.id === current)
        ? current
        : usableProfiles.find((profile) => profile.isDefault)?.id || usableProfiles[0]?.id || "");
      // A refresh of AuthContext used to reset this to false just after the
      // user pressed “Adaugă alt profil”. Keep the explicitly chosen mode.
      if (!profileModeTouched.current) setAddingProfile(usableProfiles.length === 0);
      setProfileName((current) => current || (isPlaceholderProfileName(providerName ?? "") ? "" : providerName ?? ""));
    }).catch((caught) => {
      if (active) setError(caught instanceof Error ? caught.message : "Profilurile nu au putut fi încărcate.");
    }).finally(() => {
      if (active) {
        setProfilesLoading(false);
        setRequestProfilesLoaded(true);
      }
    });
    return () => { active = false; };
  }, [providerId, providerName, status]);

  useEffect(() => {
    if (!providerId || !draftReady || !requestProfilesLoaded) return;
    setSelectedRequestProfileId((current) => requestProfiles.some((profile) => profile.id === current)
      ? current
      : requestProfiles.find((profile) => profile.isDefault)?.id || requestProfiles[0]?.id || "");
  }, [draftReady, providerId, requestProfiles, requestProfilesLoaded]);

  function updateDescription(value: string) {
    analysisSequence.current += 1;
    analysisAbortController.current?.abort();
    analysisAbortController.current = null;
    setDescription(value);
    setSummaryTouched(false);
    // Keep the actual request visible all the way to publication. Suggestions
    // may improve category and price options later, but never replace this.
    setIntentSummaryDraft(value);
    const inferred = analyzeWorkIntent(value);
    if (!categoryTouched) setCategory(inferred.category);
    if (!solutionTouched) setSolutionKind(inferred.recommended);
    const inferredRecurrence = inferRecurrenceLabel(value);
    if (inferredRecurrence) setRecurrence(inferredRecurrence);
    setClarificationAnswers({});
    setRemoteAnalysis(null);
    setAnalysisForFlow(null);
    setIntentForFlow(null);
    setError("");
  }

  function analyzeAfterLeavingEditor() {
    const trimmed = description.trim();
    if (trimmed.length < 8) return;

    // Typing must always stay local and instantaneous. The optional remote
    // classifier starts only after the person presses Continue, and its result
    // is retained as metadata instead of redrawing the form under their hands.
    const sequence = ++analysisSequence.current;
    analysisAbortController.current?.abort();
    const controller = new AbortController();
    analysisAbortController.current = controller;
    const timeout = setTimeout(() => controller.abort(), 5_000);

    void analyzeWorkIntentRemote({
      description: trimmed,
      selectedCategory: categoryTouched ? category : undefined,
      selectedSolution: solutionTouched ? solutionKind : undefined,
      answers: clarificationAnswers,
    }, controller.signal).then((analysis) => {
      if (analysisSequence.current !== sequence) return;
      setRemoteAnalysis(analysis);
    }).catch(() => {
      // The local categoriser keeps every part of the request flow usable
      // offline or when the optional analysis service is slow.
    }).finally(() => clearTimeout(timeout));
  }

  function answerClarification(id: string, value: string) {
    setClarificationAnswers((current) => ({ ...current, [id]: value }));
    if (id === "work_mode" && ["quotes", "hourly", "team", "recurring", "assessment"].includes(value)) {
      setSolutionKind(value as WorkSolutionKind);
      setSolutionTouched(true);
    }
    if (id === "people_count") {
      const count = Math.max(1, Math.min(20, Number(value) || 1));
      setRequiredParticipants(String(count));
      setParticipantsTouched(true);
      if (solutionKind !== "recurring") setSolutionKind(count >= 2 ? "team" : "hourly");
      setSolutionTouched(true);
    }
    if (id === "frequency") {
      if (value === "weekly") setRecurrence("Săptămânal");
      if (value === "biweekly") setRecurrence("La 2 săptămâni");
      if (value === "monthly") setRecurrence("Lunar");
      if (value !== "once") {
        setSolutionKind("recurring");
        setSolutionTouched(true);
      }
    }
    if (id === "duration") {
      setSolutionKind("hourly");
      setSolutionTouched(true);
    }
  }

  function addRequestPhoto(uri: string | null) {
    if (uri) setPhotos((prev) => [...prev, uri]);
  }

  async function pickRequestPhoto() {
    if (photos.length >= 2) {
      Alert.alert("Limită fotografii", "Poți adăuga maximum 2 fotografii per cerere.");
      return;
    }
    const uri = await pickImageFromGallery();
    addRequestPhoto(uri);
  }

  async function takeRequestPhoto() {
    if (photos.length >= 2) {
      Alert.alert("Limită fotografii", "Poți adăuga maximum 2 fotografii per cerere.");
      return;
    }
    addRequestPhoto(await takeImageWithCamera());
  }

  function chooseRequestPhoto() {
    if (photos.length >= 2) {
      Alert.alert("Limită fotografii", "Poți adăuga maximum 2 fotografii per cerere.");
      return;
    }
    Alert.alert("Adaugă o fotografie", "Poți face una acum sau poți alege o fotografie existentă.", [
      { text: "Renunță", style: "cancel" },
      { text: "Fă o poză", onPress: () => void takeRequestPhoto() },
      { text: "Alege din galerie", onPress: () => void pickRequestPhoto() },
    ]);
  }

  function removePhoto(index: number) {
    setPhotos(photos.filter((_, i) => i !== index));
  }

  function changeParticipantCount(delta: number) {
    const current = Number.parseInt(requiredParticipants, 10) || 1;
    const next = Math.max(1, Math.min(20, current + delta));
    setRequiredParticipants(String(next));
    setParticipantsTouched(true);
    if (solutionKind !== "recurring") {
      setSolutionKind(next > 1 ? "team" : "quotes");
      setSolutionTouched(true);
    }
  }

  async function fetchLocation() {
    setLocating(true);
    try {
      // On un telefon unde utilizatorul a acordat deja accesul, un al doilea
      // prompt poate părea că butonul nu face nimic. Verificăm mai întâi starea
      // existentă și cerem permisiunea numai când este necesar.
      const existingPermission = await resolveWithinTimeout(Location.getForegroundPermissionsAsync(), 4_000);
      const permission = existingPermission?.status === "granted"
        ? existingPermission
        : await resolveWithinTimeout(Location.requestForegroundPermissionsAsync(), 8_000);
      if (!permission || permission.status !== "granted") {
        Alert.alert("Locația nu a fost preluată", "Poți scrie adresa, cartierul, localitatea sau un reper și continui fără să acorzi acces la poziția telefonului.");
        return;
      }
      const loc = await resolveWithinTimeout(Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }), 10_000);
      if (!loc) {
        Alert.alert("Locația nu a fost preluată", "Poți scrie adresa, cartierul, localitatea sau un reper și continuăm cu locația introdusă de tine.");
        return;
      }
      const coordinates = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
      const serverPlace = await reverseGeocodeLocation(coordinates);
      if (serverPlace) {
        applyLocationSelection(serverPlace);
      } else {
        // GPS has already given us valid coordinates. Confirm them immediately
        // instead of making the user wait for a reverse-geocoding provider.
        applyLocationSelection(selectionFromReverseGeocode(undefined, coordinates, provider?.city ?? "Locația curentă"));
        void resolveWithinTimeout(Location.reverseGeocodeAsync(coordinates)).then((geocode) => {
          if (geocode?.[0]) applyLocationSelection(selectionFromReverseGeocode(geocode[0], coordinates, provider?.city ?? "Locația curentă"));
        });
      }
    } catch {
      Alert.alert("Locația nu a fost preluată", "Poți scrie adresa, cartierul, localitatea sau un reper și continuăm cu locația introdusă de tine.");
    } finally {
      setLocating(false);
    }
  }

  function applyLocationSelection(place: PlaceSelection) {
    setLocationLabel(place.fullLabel);
    setCity(place.areaLabel);
    if (place.latitude !== null && place.longitude !== null) {
      setLocation({ latitude: place.latitude, longitude: place.longitude });
    } else {
      setLocation(null);
    }
    setError("");
  }

  async function resolveLocationBeforeContinue() {
    if (location && city.trim().length >= 2 && locationLabel.trim().length >= 3) return true;
    if (locationLabel.trim().length < 3) {
      setError("Scrie adresa, cartierul, localitatea sau un reper apropiat.");
      return false;
    }
    setFlowBusy(true);
    try {
      const resolved = await resolveTypedRomanianLocation(locationLabel);
      if (!resolved) {
        setError("Nu am putut identifica locația. Alege o sugestie sau folosește butonul de localizare.");
        return false;
      }
      applyLocationSelection(resolved);
      return true;
    } finally {
      setFlowBusy(false);
    }
  }

  async function submit() {
    if (description.trim().length < 15 || city.trim().length < 2 || locationLabel.trim().length < 3 || !location) {
      return setError("Descrie problema și confirmă locul lucrării din sugestii sau cu butonul de localizare.");
    }
    if (effectiveEmergency) return setError("Poate fi o urgență reală. Sună la 112 și părăsește zona dacă este necesar.");
    if (!provider || !requestProfiles.some((profile) => profile.id === selectedRequestProfileId)) {
      setStep(4);
      return setError("Alege un profil valabil înainte să publici cererea.");
    }
    const parsedParticipants = parseInt(requiredParticipants, 10);
    if (isNaN(parsedParticipants) || parsedParticipants < 1 || parsedParticipants > 20) {
      return setError("Alege între 1 și 20 de persoane.");
    }
    if (selectedSolution === "recurring" && recurrence === "Alt interval" && customRecurrence.trim().length < 3) {
      return setError("Descrie intervalul dorit, de exemplu „în fiecare luni” sau „la 3 săptămâni”.");
    }
    if (status === "signedOut" || !provider) {
      router.push({ pathname: "/sign-in", params: { returnTo: "/new-request" } });
      return;
    }
    setBusy(true); setError("");
    try {
      const parsedPrice = parseInt(clientPrice, 10);
      const priceVal = !isNaN(parsedPrice) && parsedPrice > 0 ? parsedPrice : undefined;
      const recurrenceLabel = recurrence === "Alt interval" ? customRecurrence.trim() : recurrence;
      const result = await createRequest({ 
        description: description.trim(),
        category, 
        urgency, 
        city: city.trim(), 
        locationLabel: locationLabel.trim(),
        requestMode, 
        photos, 
        clientPrice: priceVal,
        requiredParticipants: parsedParticipants,
        solutionKind: selectedSolution,
        recurrenceLabel: selectedSolution === "recurring" ? recurrenceLabel : undefined,
        intentSummary: intentSummaryDraft.trim() || description.trim(),
        intentConfidence: remoteAnalysis?.confidence ?? intent.confidence,
        intentVersion: remoteAnalysis?.analysisVersion ?? "local-rules-v1",
        intentAnswers: clarificationAnswers,
        requestProfileId: selectedRequestProfileId,
        latitude: location?.latitude,
        longitude: location?.longitude
      });
      draftWriteGeneration.current += 1;
      setDraftReady(false);
      await Promise.all([clearRequestDraft(provider.id), clearRequestDraft(null)]);
      // Confirmarea nativă arăta ca o fereastră gri peste aplicație și cerea
      // încă un tap ca utilizatorul să poată vedea lucrarea. Intrăm direct în
      // cererea publicată, unde bannerul verde explică pe scurt ce urmează.
      router.replace({ pathname: "/my-request/[id]", params: { id: result.request.id, published: "1" } } as never);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Cererea nu a putut fi publicată.");
    } finally { setBusy(false); }
  }

  async function continueFlow() {
    setError("");
    if (step === 0) {
      if (description.trim().length < 15) {
        setError("Spune-ne în câteva cuvinte ce ai nevoie să fie făcut.");
        return;
      }
      if (effectiveEmergency) {
        setError("Poate fi o urgență reală. Sună la 112 și părăsește zona dacă este necesar.");
        return;
      }
      if (remoteAnalysis?.emergency) {
        setError("Poate fi o urgență reală. Sună la 112 și părăsește zona dacă este necesar.");
        return;
      }
      setIntentForFlow(intent);
      // A late remote result must not add or move fields after the person has
      // left the editor. The local rules already give a clear first pass and
      // the remote result is saved as non-blocking metadata.
      setAnalysisForFlow(null);
      if (editingFromSummary) {
        setEditingFromSummary(false);
        setStep(5);
      } else {
        setStep(1);
      }
      requestAnimationFrame(() => Keyboard.dismiss());
      analyzeAfterLeavingEditor();
      return;
    }
    Keyboard.dismiss();
    if (step === 1) {
      const clarification = analysisForFlow?.clarification;
      if (!clarification) {
        if (editingFromSummary) {
          setEditingFromSummary(false);
          setStep(5);
        } else {
          setStep(2);
        }
        return;
      }
      const answer = clarificationAnswers[clarification.id];
      if (answer === undefined || String(answer).trim().length === 0) {
        setError("Alege un răspuns pentru a continua.");
        return;
      }
      if (remoteAnalysis?.emergency) {
        setError("Poate fi o urgență reală. Sună la 112 și părăsește zona dacă este necesar.");
        return;
      }
      if (editingFromSummary) {
        setEditingFromSummary(false);
        setStep(5);
      } else {
        setStep(2);
      }
      return;
    }
    if (step === 3) {
      if (!await resolveLocationBeforeContinue()) return;
    }
    if (step === 4) {
      if (status === "signedOut" || !provider) {
        router.push({ pathname: "/sign-in", params: { returnTo: "/new-request" } });
        return;
      }
      if (!requestProfiles.some((profile) => profile.id === selectedRequestProfileId)) {
        setError("Alege un profil valabil pentru care publici lucrarea.");
        return;
      }
    }
    if (editingFromSummary) {
      setEditingFromSummary(false);
      setStep(5);
    } else {
      setStep((current) => Math.min(5, current + 1));
    }
  }

  async function addRequestProfile() {
    if (!provider) {
      router.push({ pathname: "/sign-in", params: { returnTo: "/new-request" } });
      return;
    }
    setError("");
    const legal = profileType !== "person";
    if (profileLabel.trim().length < 2) {
      setError("Scrie o etichetă pentru profil, de exemplu „Eu”, „Mama” sau „Sediu”.");
      return;
    }
    if (profileName.trim().length < 2) {
      setError("Scrie numele persoanei sau numele afișat pentru acest profil.");
      return;
    }
    if (legal && profileLegalName.trim().length < 2) {
      setError("Scrie denumirea legală a firmei sau a PFA-ului.");
      return;
    }
    if (legal && !isValidRomanianTaxId(profileTaxId)) {
      setError("CUI/CIF nu este valid. Verifică cifrele introduse.");
      return;
    }
    if (legal && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(profileBillingEmail.trim())) {
      setError("Scrie o adresă de e-mail de facturare validă.");
      return;
    }
    if (legal && profileBillingAddress.trim().length < 5) {
      setError("Scrie adresa de facturare.");
      return;
    }
    setProfilesLoading(true);
    try {
      const { profile } = await createRequestProfile({
        label: profileLabel.trim(),
        profileType,
        displayName: profileName.trim(),
        legalName: legal ? profileLegalName.trim() : null,
        taxId: legal ? normalizeRomanianTaxId(profileTaxId) : null,
        billingEmail: legal ? profileBillingEmail.trim() : null,
        billingAddressLine1: legal ? profileBillingAddress.trim() : null,
        city: city.trim(),
        contactName: profileName.trim(),
        contactPhone: provider.phone,
        defaultInvoiceRequired: legal,
      });
      setRequestProfiles((current) => [...current, profile]);
      setSelectedRequestProfileId(profile.id);
      profileModeTouched.current = false;
      setAddingProfile(false);
      triggerFeedback("success");
      if (isPlaceholderProfileName(provider.name)) {
        setProvider({ ...provider, name: profile.displayName, city: profile.city });
      }
    } catch (caught) {
      triggerFeedback("error");
      setError(caught instanceof Error ? caught.message : "Profilul nu a putut fi salvat.");
    } finally {
      setProfilesLoading(false);
    }
  }

  function startAddingRequestProfile() {
    profileModeTouched.current = true;
    setError("");
    setProfileType("person");
    setProfileLabel("Eu");
    setProfileName(isPlaceholderProfileName(provider?.name) ? "" : provider?.name ?? "");
    setProfileLegalName("");
    setProfileTaxId("");
    setProfileBillingEmail("");
    setProfileBillingAddress("");
    setAddingProfile(true);
    triggerFeedback("selection");
  }

  function cancelAddingRequestProfile() {
    profileModeTouched.current = false;
    setAddingProfile(false);
  }

  function leaveFlow() {
    if (router.canGoBack()) router.back();
    else router.replace("/");
  }

  function exitFlow() {
    if (!description.trim() && photos.length === 0) {
      leaveFlow();
      return;
    }
    Alert.alert(
      "Păstrezi cererea începută?",
      "O putem salva pe acest telefon ca să continui mai târziu.",
      [
        { text: "Continuă editarea", style: "cancel" },
        {
          text: "Păstrează și ieși",
          onPress: () => {
            void saveRequestDraft(draftSnapshot(), provider?.id).finally(leaveFlow);
          },
        },
        {
          text: "Renunță la cerere",
          style: "destructive",
          onPress: () => {
            draftWriteGeneration.current += 1;
            setDraftReady(false);
            void clearRequestDraft(provider?.id).finally(leaveFlow);
          },
        },
      ],
    );
  }

  function goBack() {
    Keyboard.dismiss();
    setError("");
    if (editingFromSummary) {
      setEditingFromSummary(false);
      setStep(5);
      return;
    }
    if (step > 0) {
      setStep((current) => Math.max(0, current - 1));
      return;
    }
    exitFlow();
  }

  function editFromSummary(targetStep: number) {
    setEditingFromSummary(true);
    setStep(targetStep);
    setError("");
  }

  if (!draftReady) {
    return (
      <SafeAreaView style={styles.draftLoading}>
        <ActivityIndicator size="large" color={colors.accent} />
        <Text style={styles.draftLoadingText}>Recuperăm cererea începută...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={["top", "bottom"]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={0}
      >
        <ScrollView
          contentContainerStyle={styles.flowContent}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.progressHeader}>
            <Pressable accessibilityLabel={step === 0 ? "Închide cererea" : "Înapoi"} accessibilityRole="button" onPress={goBack} style={styles.backButton}>
                <MaterialCommunityIcons name="arrow-left" size={20} color={colors.ink} />
            </Pressable>
            <Text style={styles.progressText}>PASUL {visibleStep + 1} DIN {totalSteps}</Text>
            <View style={styles.backPlaceholder} />
          </View>
          <View style={styles.progressTrack}>
            {Array.from({ length: totalSteps }, (_, item) => <View key={item} style={[styles.progressSegment, item <= visibleStep && styles.progressSegmentActive]} />)}
          </View>

          {step === 0 ? (
            <>
              <Text style={styles.flowTitle}>Ce ai nevoie să fie făcut?</Text>
              <Text style={styles.flowSubtitle}>Scrie natural, ca și cum ai explica unui om.</Text>
              <TextInput
                value={description}
                onChangeText={updateDescription}
                accessibilityLabel="Descrie lucrarea de care ai nevoie"
                accessibilityHint="Scrie ce trebuie făcut, când ai nevoie și orice detaliu important"
                placeholder="Ex: Am nevoie de două persoane care să mă ajute la mutare mâine..."
                placeholderTextColor="#98A19B"
                style={styles.flowDescription}
                multiline
                numberOfLines={5}
                maxLength={850}
                textAlignVertical="top"
              />
              {effectiveEmergency ? <View style={styles.emergency}><MaterialCommunityIcons name="alert-octagon-outline" size={20} color={colors.accentDark} /><Text style={styles.emergencyText}>Nu publica aici o urgență periculoasă. Sună la 112.</Text></View> : null}
              {Platform.OS === "android" ? (
                <>
                  {error ? <Text accessibilityLiveRegion="assertive" style={[styles.flowError, styles.flowInlineError]}>{error}</Text> : null}
                  <Pressable
                    disabled={busy || flowBusy}
                    onPress={() => void continueFlow()}
                    style={({ pressed }) => [styles.flowInlineButton, (pressed || busy || flowBusy) && styles.pressed]}
                  >
                    <Text style={styles.flowButtonText}>{flowBusy ? "Pregătim..." : editingFromSummary ? "Salvează modificarea" : "Continuă"}</Text>
                    <MaterialCommunityIcons name="arrow-right" size={21} color={colors.paper} />
                  </Pressable>
                </>
              ) : null}

              <Text style={styles.exampleLabel}>EXEMPLE</Text>
              <View style={styles.exampleList}>
                {quickPrompts.slice(0, 3).map((prompt) => (
                  <Pressable key={prompt.label} accessibilityRole="button" accessibilityLabel={`Folosește exemplul: ${prompt.text}`} onPress={() => updateDescription(prompt.text)} style={styles.exampleButton}>
                    <Text style={styles.exampleText}>{prompt.text}</Text>
                    <MaterialCommunityIcons name="arrow-top-right" size={17} color={colors.muted} />
                  </Pressable>
                ))}
              </View>

              <Pressable accessibilityLabel="Adaugă o fotografie cererii" accessibilityHint="Opțional, poți face o fotografie acum sau poți alege una din galerie" accessibilityRole="button" onPress={chooseRequestPhoto} style={styles.photoAction}>
                <MaterialCommunityIcons name="camera-plus-outline" size={21} color={colors.ink} />
                <View style={styles.photoActionCopy}>
                  <Text style={styles.photoActionTitle}>Adaugă o fotografie</Text>
                  <Text style={styles.photoActionText}>Opțional · ajută la oferte mai exacte</Text>
                </View>
                <Text style={styles.photoCount}>{photos.length ? `${photos.length}/2` : ""}</Text>
              </Pressable>
              {photos.length > 0 ? (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.photoRow}>
                  {photos.map((url, idx) => (
                    <View key={`${url}-${idx}`} style={styles.photoThumbWrap}>
                      <Image source={{ uri: url }} style={styles.photoThumb} />
                      <Pressable accessibilityLabel={`Șterge fotografia ${idx + 1}`} accessibilityRole="button" style={styles.photoRemove} hitSlop={12} onPress={() => removePhoto(idx)}>
                        <MaterialCommunityIcons name="close-circle" size={25} color={colors.accentDark} />
                      </Pressable>
                    </View>
                  ))}
                </ScrollView>
              ) : null}
            </>
          ) : null}

          {step === 1 ? (
            <>
              <Text style={styles.flowTitle}>{analysisForFlow?.clarification?.prompt ?? "Verifică ce am înțeles"}</Text>
              <Text style={styles.flowSubtitle}>{analysisForFlow?.clarification?.helpText ?? "Aplicația propune aceste detalii. Tu ai ultimul cuvânt și le poți schimba."}</Text>
              {analysisForFlow?.clarification?.type === "single_choice" ? (
                <View style={styles.choiceList}>
                  {(analysisForFlow.clarification.options ?? []).map((option) => {
                    const active = clarificationAnswers[analysisForFlow.clarification!.id] === option.value;
                    return (
                      <Pressable
                        key={option.value}
                        accessibilityRole="radio"
                        accessibilityState={{ checked: active }}
                        onPress={() => answerClarification(analysisForFlow.clarification!.id, option.value)}
                        style={[styles.choice, active && styles.choiceActive]}
                      >
                        <View style={[styles.choiceRadio, active && styles.choiceRadioActive]}>{active ? <View style={styles.choiceRadioDot} /> : null}</View>
                        <Text style={[styles.choiceText, active && styles.choiceTextActive]}>{option.label}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              ) : analysisForFlow?.clarification ? (
                <TextInput
                  value={String(clarificationAnswers[analysisForFlow.clarification.id] ?? "")}
                  onChangeText={(value) => answerClarification(analysisForFlow.clarification!.id, value)}
                  placeholder={analysisForFlow.clarification.type === "number" ? "Introdu un număr" : "Scrie răspunsul"}
                  placeholderTextColor="#98A19B"
                  keyboardType={analysisForFlow.clarification.type === "number" ? "number-pad" : "default"}
                  style={styles.clarificationField}
                />
              ) : null}
              <View style={styles.aiEditor}>
                <Text style={styles.aiEditorLabel}>REZUMAT</Text>
                <TextInput
                  value={intentSummaryDraft}
                  onChangeText={(value) => {
                    setIntentSummaryDraft(value);
                    setSummaryTouched(true);
                  }}
                  placeholder="Scrie pe scurt ce trebuie rezolvat"
                  placeholderTextColor="#98A19B"
                  style={styles.aiSummaryInput}
                  multiline
                  maxLength={240}
                />

                <Text style={styles.aiEditorLabel}>CATEGORIE</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.aiChipRow}>
                  {categories.map((item) => (
                    <Pressable
                      key={item}
                      accessibilityRole="button"
                      accessibilityState={{ selected: category === item }}
                      onPress={() => {
                        setCategory(item);
                        setCategoryTouched(true);
                      }}
                      style={[styles.aiChip, category === item && styles.aiChipActive]}
                    >
                      <Text style={[styles.aiChipText, category === item && styles.aiChipTextActive]}>{item}</Text>
                    </Pressable>
                  ))}
                </ScrollView>

                <Text style={styles.aiEditorLabel}>CUM VREI SĂ PRIMEȘTI OFERTE</Text>
                <View style={styles.solutionGrid}>
                  {effectiveSolutions.map((solution) => {
                    const active = selectedSolution === solution.kind;
                    return (
                    <Pressable
                      key={solution.kind}
                      accessibilityRole="radio"
                      accessibilityState={{ checked: active }}
                      onPress={() => {
                          setSolutionKind(solution.kind);
                          setSolutionTouched(true);
                        }}
                        style={[styles.solutionCard, active && styles.solutionCardActive]}
                      >
                        <Text style={[styles.solutionTitle, active && styles.solutionTextActive]}>{solution.title}</Text>
                        <Text style={[styles.solutionDescription, active && styles.solutionDescriptionActive]}>{solution.description}</Text>
                      </Pressable>
                    );
                  })}
                </View>

                <View style={styles.aiCounterRow}>
                  <View>
                    <Text style={styles.aiCounterTitle}>De câte persoane ai nevoie?</Text>
                    <Text style={styles.aiCounterHint}>Poate fi schimbat și în rezumat.</Text>
                  </View>
                  <View style={styles.participantEditor}>
                    <Pressable
                      accessibilityLabel="Scade numărul de persoane"
                      accessibilityRole="button"
                      disabled={Number(requiredParticipants) <= 1}
                      onPress={() => changeParticipantCount(-1)}
                      style={[styles.participantButton, Number(requiredParticipants) <= 1 && styles.participantButtonDisabled]}
                    >
                      <MaterialCommunityIcons name="minus" size={18} color={colors.ink} />
                    </Pressable>
                    <Text style={styles.participantCount}>{requiredParticipants}</Text>
                    <Pressable
                      accessibilityLabel="Crește numărul de persoane"
                      accessibilityRole="button"
                      disabled={Number(requiredParticipants) >= 20}
                      onPress={() => changeParticipantCount(1)}
                      style={[styles.participantButton, Number(requiredParticipants) >= 20 && styles.participantButtonDisabled]}
                    >
                      <MaterialCommunityIcons name="plus" size={18} color={colors.ink} />
                    </Pressable>
                  </View>
                </View>

                {selectedSolution === "recurring" ? (
                  <>
                    <Text style={styles.aiEditorLabel}>FRECVENȚĂ</Text>
                    <View style={styles.aiWrapRow}>
                      {recurrenceOptions.map((item) => (
                        <Pressable key={item} accessibilityRole="radio" accessibilityState={{ checked: recurrence === item }} onPress={() => setRecurrence(item)} style={[styles.aiChip, recurrence === item && styles.aiChipActive]}>
                          <Text style={[styles.aiChipText, recurrence === item && styles.aiChipTextActive]}>{item}</Text>
                        </Pressable>
                      ))}
                    </View>
                    {recurrence === "Alt interval" ? (
                      <TextInput value={customRecurrence} onChangeText={setCustomRecurrence} placeholder="Ex: în fiecare luni, la două săptămâni" placeholderTextColor="#98A19B" style={styles.aiSmallInput} maxLength={80} />
                    ) : null}
                  </>
                ) : null}

                <Text style={styles.aiEditorLabel}>BUGET ORIENTATIV · OPȚIONAL</Text>
                <View style={styles.aiMoneyInput}>
                  <TextInput value={clientPrice} onChangeText={(value) => setClientPrice(value.replace(/\D/g, "").slice(0, 6))} placeholder="Ex: 300" placeholderTextColor="#98A19B" keyboardType="number-pad" style={styles.aiMoneyField} />
                  <Text style={styles.aiMoneyCurrency}>LEI</Text>
                </View>
                <Pressable
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: clarificationAnswers.price_negotiable === "yes" }}
                  accessibilityLabel="Buget negociabil"
                  onPress={() => answerClarification("price_negotiable", clarificationAnswers.price_negotiable === "yes" ? "no" : "yes")}
                  style={[styles.aiNegotiable, clarificationAnswers.price_negotiable === "yes" && styles.aiNegotiableActive]}
                >
                  <MaterialCommunityIcons name={clarificationAnswers.price_negotiable === "yes" ? "check-circle" : "circle-outline"} size={18} color={clarificationAnswers.price_negotiable === "yes" ? colors.mintDark : colors.muted} />
                  <Text style={[styles.aiNegotiableText, clarificationAnswers.price_negotiable === "yes" && styles.aiNegotiableTextActive]}>Buget negociabil</Text>
                </Pressable>

                <Text style={styles.aiEditorLabel}>FACTURĂ</Text>
                <View style={styles.aiWrapRow}>
                  {([
                    ["no", "Nu este necesară"],
                    ["yes", "Da, am nevoie"],
                  ] as const).map(([value, label]) => (
                    <Pressable key={value} accessibilityRole="radio" accessibilityState={{ checked: clarificationAnswers.invoice_required === value }} onPress={() => answerClarification("invoice_required", value)} style={[styles.aiChip, clarificationAnswers.invoice_required === value && styles.aiChipActive]}>
                      <Text style={[styles.aiChipText, clarificationAnswers.invoice_required === value && styles.aiChipTextActive]}>{label}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
              <View style={styles.safetyLock}><MaterialCommunityIcons name="shield-alert-outline" size={18} color={colors.mintDark} /><Text style={styles.safetyLockText}>Poți corecta toate sugestiile. Detectarea unui pericol imediat rămâne activă pentru siguranță.</Text></View>
            </>
          ) : null}

          {step === 2 ? (
            <>
              <Text style={styles.flowTitle}>Când ai nevoie?</Text>
              <Text style={styles.flowSubtitle}>Alege varianta cea mai apropiată. Poți discuta ora exactă după ce primești oferte.</Text>
              <View style={styles.choiceList}>
                {urgencyOptions.map((item) => {
                  const active = urgency === item;
                  return (
                  <Pressable key={item} accessibilityRole="radio" accessibilityState={{ checked: active }} onPress={() => setUrgency(item)} style={[styles.choice, active && styles.choiceActive]}>
                      <View style={[styles.choiceRadio, active && styles.choiceRadioActive]}>{active ? <View style={styles.choiceRadioDot} /> : null}</View>
                      <Text style={[styles.choiceText, active && styles.choiceTextActive]}>{item}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </>
          ) : null}

          {step === 3 ? (
            <>
              <Text style={styles.flowTitle}>Unde este lucrarea?</Text>
              <Text style={styles.flowSubtitle}>Cei care trimit oferte văd doar zona aproximativă.</Text>
              <View style={styles.locationRow}>
                <View style={styles.locationInput}>
                  <CityAutocompleteInput
                    value={locationLabel}
                    onChangeText={(value) => {
                      setLocationLabel(value);
                      setCity("");
                      setLocation(null);
                    }}
                    onSelectPlace={applyLocationSelection}
                    purpose="address"
                    placeholder="Adresă, cartier, sat sau reper"
                  />
                </View>
                <Pressable accessibilityRole="button" accessibilityLabel="Folosește locația mea curentă" disabled={locating} onPress={() => void fetchLocation()} style={[styles.gpsBtn, location && styles.gpsBtnActive]}>
                  {locating ? <ActivityIndicator size="small" color={colors.mintDark} /> : <><MaterialCommunityIcons name="crosshairs-gps" size={18} color={location ? colors.mintDark : colors.ink} /><Text style={[styles.gpsBtnText, location && styles.gpsBtnTextActive]}>Locația mea</Text></>}
                </Pressable>
              </View>
              {location ? <View style={styles.locationConfirmed}><MaterialCommunityIcons name="check-circle" size={18} color={colors.mintDark} /><Text style={styles.locationConfirmedText}>Zona afișată: {city || "zona aleasă"}.</Text></View> : null}
              <View style={styles.privacy}><MaterialCommunityIcons name="shield-lock-outline" size={19} color={colors.mintDark} /><Text style={styles.privacyText}>Adresa exactă o primește doar persoana pe care o alegi.</Text></View>
            </>
          ) : null}

          {step === 4 ? (
            <>
              <Text style={styles.flowTitle}>Pentru cine este lucrarea?</Text>
              <Text style={styles.flowSubtitle}>Alege persoana, locuința sau firma. Profilul nu îți schimbă tipul contului.</Text>
              {!provider ? (
                <View style={styles.signInProfileCard}>
                  <MaterialCommunityIcons name="account-lock-outline" size={24} color={colors.mintDark} />
                  <Text style={styles.signInProfileTitle}>Salvează cererea înainte de publicare</Text>
                  <Text style={styles.signInProfileText}>Verificăm numărul prin SMS, apoi revii exact aici ca să alegi profilul.</Text>
                </View>
              ) : profilesLoading && !requestProfiles.length ? (
                <View style={styles.inlineStatus}><ActivityIndicator size="small" color={colors.mintDark} /><Text style={styles.inlineStatusText}>Încărcăm profilurile...</Text></View>
              ) : !addingProfile ? (
                <>
                  <View style={styles.profileChoices}>
                    {requestProfiles.map((profile) => {
                      const active = selectedRequestProfileId === profile.id;
                      return (
                      <Pressable key={profile.id} accessibilityRole="radio" accessibilityState={{ checked: active }} onPress={() => setSelectedRequestProfileId(profile.id)} style={[styles.profileChoice, active && styles.profileChoiceActive]}>
                          <View style={[styles.profileChoiceIcon, active && styles.profileChoiceIconActive]}>
                            <MaterialCommunityIcons name={profile.profileType === "person" ? "account-outline" : "office-building-outline"} size={21} color={active ? colors.paper : colors.ink} />
                          </View>
                          <View style={styles.profileChoiceCopy}>
                            <Text style={styles.profileChoiceTitle}>{profile.label}</Text>
                            <Text style={styles.profileChoiceText}>{profile.displayName} · {profile.city}{profile.defaultInvoiceRequired ? " · cu factură" : ""}</Text>
                            <Text style={styles.profileChoiceText}>{profile.reviewCount ? `★ ${(profile.rating / 10).toFixed(1).replace(".", ",")} · ${profile.reviewCount} evaluări ca solicitant` : "Profil nou, fără evaluări"} · {profile.completedJobs} lucrări finalizate</Text>
                          </View>
                          <MaterialCommunityIcons name={active ? "check-circle" : "circle-outline"} size={22} color={active ? colors.mintDark : colors.muted} />
                        </Pressable>
                      );
                    })}
                  </View>
                  <Pressable accessibilityRole="button" accessibilityLabel="Adaugă alt profil" onPress={startAddingRequestProfile} style={styles.addProfileButton}>
                    <MaterialCommunityIcons name="plus" size={19} color={colors.ink} />
                    <Text style={styles.addProfileText}>Adaugă alt profil</Text>
                  </Pressable>
                </>
              ) : (
                <View style={styles.profileForm}>
                  <Text style={styles.profileFormTitle}>Profil nou</Text>
                  <View style={styles.profileTypeRow}>
                    {([
                      ["person", "Personal"],
                      ["pfa", "PFA"],
                      ["company", "Firmă"],
                    ] as const).map(([value, label]) => (
                      <Pressable key={value} accessibilityRole="radio" accessibilityState={{ checked: profileType === value }} onPress={() => setProfileType(value)} style={[styles.profileTypeButton, profileType === value && styles.profileTypeButtonActive]}>
                        <Text style={[styles.profileTypeText, profileType === value && styles.profileTypeTextActive]}>{label}</Text>
                      </Pressable>
                    ))}
                  </View>
                  <Text style={styles.profileFieldLabel}>Eticheta profilului</Text>
                  <TextInput value={profileLabel} onChangeText={setProfileLabel} placeholder="Eu, Mama, Sediu..." placeholderTextColor="#78817B" style={styles.profileInput} />
                  <Text style={styles.profileFieldLabel}>Numele afișat</Text>
                  <TextInput value={profileName} onChangeText={setProfileName} placeholder="Nume persoană sau firmă" placeholderTextColor="#78817B" style={styles.profileInput} />
                  {profileType !== "person" ? (
                    <>
                      <Text style={styles.profileFieldLabel}>Denumirea legală</Text>
                      <TextInput value={profileLegalName} onChangeText={setProfileLegalName} placeholder="Denumirea din documente" placeholderTextColor="#78817B" style={styles.profileInput} />
                      <Text style={styles.profileFieldLabel}>CUI / CIF</Text>
                      <TextInput value={profileTaxId} onChangeText={setProfileTaxId} placeholder="Ex: RO12345678" autoCapitalize="characters" placeholderTextColor="#78817B" style={styles.profileInput} />
                      <Text style={styles.profileFieldLabel}>E-mail de facturare</Text>
                      <TextInput value={profileBillingEmail} onChangeText={setProfileBillingEmail} placeholder="facturi@firma.ro" keyboardType="email-address" autoCapitalize="none" placeholderTextColor="#78817B" style={styles.profileInput} />
                      <Text style={styles.profileFieldLabel}>Adresa de facturare</Text>
                      <TextInput value={profileBillingAddress} onChangeText={setProfileBillingAddress} placeholder="Stradă, număr, localitate" placeholderTextColor="#78817B" style={styles.profileInput} />
                    </>
                  ) : null}
                  <View style={styles.profileFormActions}>
                    <Pressable accessibilityRole="button" onPress={cancelAddingRequestProfile} style={styles.profileCancel}><Text style={styles.profileCancelText}>Renunță</Text></Pressable>
                    <Pressable accessibilityRole="button" disabled={profilesLoading} onPress={() => void addRequestProfile()} style={styles.profileSave}><Text style={styles.profileSaveText}>{profilesLoading ? "Se salvează..." : "Salvează profilul"}</Text></Pressable>
                  </View>
                </View>
              )}
            </>
          ) : null}

          {step === 5 ? (
            <>
              <Text style={styles.flowTitle}>Verifică cererea</Text>
              <Text style={styles.flowSubtitle}>Verifică ce vor vedea prestatorii înainte să publici.</Text>
              <View style={styles.summaryCard}>
                <View style={styles.summaryIcon}><MaterialCommunityIcons name="check-decagram-outline" size={22} color={colors.mintDark} /></View>
                <Text style={styles.summaryTitle}>{intentSummaryDraft.trim() || description.trim()}</Text>
                <View style={styles.summaryDivider} />
                <Pressable accessibilityRole="button" accessibilityLabel="Schimbă detaliile cererii" onPress={() => editFromSummary(0)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Detalii</Text><Text numberOfLines={2} style={styles.summaryValue}>{description.trim()}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable>
                <Pressable accessibilityRole="button" accessibilityLabel="Schimbă categoria" onPress={() => editFromSummary(1)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Categorie</Text><Text style={styles.summaryValue}>{category}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable>
                <Pressable accessibilityRole="button" accessibilityLabel="Schimbă modul de primire a ofertelor" onPress={() => editFromSummary(1)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Oferte</Text><Text style={styles.summaryValue}>{solutionLabels[selectedSolution]}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable>
                {selectedSolution === "recurring" ? <Pressable accessibilityRole="button" accessibilityLabel="Schimbă frecvența" onPress={() => editFromSummary(1)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Frecvență</Text><Text style={styles.summaryValue}>{recurrence === "Alt interval" ? customRecurrence : recurrence}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable> : null}
                {clientPrice ? <Pressable accessibilityRole="button" accessibilityLabel="Schimbă bugetul" onPress={() => editFromSummary(1)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Buget</Text><Text style={styles.summaryValue}>{clientPrice} lei{clarificationAnswers.price_negotiable === "yes" ? " · negociabil" : ""}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable> : null}
                {clarificationAnswers.invoice_required ? <Pressable accessibilityRole="button" accessibilityLabel="Schimbă opțiunea pentru factură" onPress={() => editFromSummary(1)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Factură</Text><Text style={styles.summaryValue}>{clarificationAnswers.invoice_required === "yes" ? "Necesară" : "Nu este necesară"}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable> : null}
                <Pressable accessibilityRole="button" accessibilityLabel="Schimbă momentul lucrării" onPress={() => editFromSummary(2)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Când</Text><Text style={styles.summaryValue}>{urgency}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable>
                <Pressable accessibilityRole="button" accessibilityLabel="Schimbă locația lucrării" onPress={() => editFromSummary(3)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Unde</Text><Text style={styles.summaryValue}>{locationLabel}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Persoane</Text>
                  <View style={styles.participantEditor}>
                    <Pressable
                      accessibilityLabel="Scade numărul de persoane"
                      accessibilityRole="button"
                      disabled={Number(requiredParticipants) <= 1}
                      onPress={() => changeParticipantCount(-1)}
                      style={[styles.participantButton, Number(requiredParticipants) <= 1 && styles.participantButtonDisabled]}
                    >
                      <MaterialCommunityIcons name="minus" size={18} color={colors.ink} />
                    </Pressable>
                    <Text style={styles.participantCount}>{requiredParticipants}</Text>
                    <Pressable
                      accessibilityLabel="Crește numărul de persoane"
                      accessibilityRole="button"
                      disabled={Number(requiredParticipants) >= 20}
                      onPress={() => changeParticipantCount(1)}
                      style={[styles.participantButton, Number(requiredParticipants) >= 20 && styles.participantButtonDisabled]}
                    >
                      <MaterialCommunityIcons name="plus" size={18} color={colors.ink} />
                    </Pressable>
                  </View>
                  <Text style={styles.summaryEdit}>Confirmat</Text>
                </View>
                <Pressable accessibilityRole="button" accessibilityLabel="Schimbă profilul pentru cerere" onPress={() => editFromSummary(4)} style={styles.summaryRow}><Text style={styles.summaryLabel}>Profil</Text><Text style={styles.summaryValue}>{requestProfiles.find((profile) => profile.id === selectedRequestProfileId)?.label ?? "Profil personal"}</Text><Text style={styles.summaryEdit}>Schimbă</Text></Pressable>
                {photos.length > 0 ? <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Fotografii</Text><Text style={styles.summaryValue}>{photos.length}</Text></View> : null}
              </View>
              <View style={styles.privacy}><MaterialCommunityIcons name="shield-check-outline" size={19} color={colors.mintDark} /><Text style={styles.privacyText}>Publicarea nu te obligă să alegi o ofertă. Compari prețul și condițiile înainte să decizi.</Text></View>
            </>
          ) : null}
        </ScrollView>

        {step > 0 || Platform.OS !== "android" ? <View style={styles.flowFooter}>
          {error ? <Text accessibilityLiveRegion="assertive" style={styles.flowError}>{error}</Text> : null}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={step === 5 ? "Publică cererea" : editingFromSummary ? "Salvează modificarea" : step === 4 && !provider ? "Continuă cu SMS" : "Continuă"}
            disabled={busy || flowBusy}
            onPress={() => void (step === 5 ? submit() : continueFlow())}
            style={({ pressed }) => [styles.flowButton, (pressed || busy || flowBusy) && styles.pressed]}
          >
            <Text style={styles.flowButtonText}>{flowBusy ? "Pregătim..." : busy ? "Se publică..." : step === 5 ? "Publică cererea" : editingFromSummary ? "Salvează modificarea" : step === 4 && !provider ? "Continuă cu SMS" : "Continuă"}</Text>
            <MaterialCommunityIcons name={step === 5 ? "check" : "arrow-right"} size={21} color={colors.paper} />
          </Pressable>
        </View> : null}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  draftLoading: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.cream, padding: 24 },
  draftLoadingText: { color: colors.muted, fontSize: 14, marginTop: 12 },
  // The form shares one readable column on iPhone, iPad and Android tablets.
  // It deliberately leaves only a small gap before the fixed CTA; KeyboardAvoidingView
  // owns keyboard spacing so ScrollView never applies it a second time.
  flowContent: { width: "100%", maxWidth: 600, alignSelf: "center", paddingHorizontal: 22, paddingTop: 14, paddingBottom: 18, flexGrow: 1 },
  progressHeader: { minHeight: 38, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  progressText: { color: colors.muted, fontSize: 12, fontWeight: "800", letterSpacing: 0.7 },
  backButton: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line },
  backPlaceholder: { width: 44, height: 44 },
  progressTrack: { flexDirection: "row", gap: 6, marginTop: 8, marginBottom: 38 },
  progressSegment: { flex: 1, height: 4, borderRadius: 2, backgroundColor: colors.line },
  progressSegmentActive: { backgroundColor: colors.inkSoft },
  flowTitle: { color: colors.ink, fontSize: 30, lineHeight: 37, fontWeight: "900", letterSpacing: -1 },
  flowSubtitle: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 8, marginBottom: 26 },
  flowDescription: { minHeight: 156, paddingVertical: 17, paddingHorizontal: 16, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 18, color: colors.text, fontSize: 16, lineHeight: 23 },
  flowInlineButton: { minHeight: 56, marginTop: 14, backgroundColor: colors.accent, borderRadius: 16, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  flowInlineError: { marginTop: 12, marginBottom: 0 },
  inlineStatus: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 12 },
  inlineStatusText: { color: colors.muted, fontSize: 13 },
  exampleLabel: { color: colors.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.6, marginTop: 30, marginBottom: 10 },
  exampleList: { gap: 8 },
  exampleButton: { minHeight: 54, backgroundColor: colors.paper, borderRadius: 14, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 14, paddingVertical: 11, flexDirection: "row", alignItems: "center", gap: 10 },
  exampleText: { flex: 1, color: colors.ink, fontSize: 13, lineHeight: 18 },
  photoAction: { minHeight: 66, borderTopWidth: 1, borderTopColor: colors.line, borderBottomWidth: 1, borderBottomColor: colors.line, marginTop: 28, paddingVertical: 13, flexDirection: "row", alignItems: "center", gap: 12 },
  photoActionCopy: { flex: 1 },
  photoActionTitle: { color: colors.ink, fontSize: 14, fontWeight: "800" },
  photoActionText: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  photoCount: { color: colors.muted, fontSize: 12, fontWeight: "700" },
  photoRow: { gap: 12, paddingTop: 16, paddingRight: 8 },
  choiceList: { gap: 12 },
  choice: { minHeight: 68, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 16, paddingHorizontal: 17, flexDirection: "row", alignItems: "center", gap: 13 },
  choiceActive: { borderColor: colors.inkSoft, backgroundColor: colors.mint },
  choiceRadio: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: "#AAB2AD", alignItems: "center", justifyContent: "center" },
  choiceRadioActive: { borderColor: colors.inkSoft },
  choiceRadioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.inkSoft },
  choiceText: { color: colors.ink, fontSize: 16, fontWeight: "700" },
  choiceTextActive: { fontWeight: "900" },
  clarificationField: { minHeight: 58, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 16, paddingHorizontal: 17, color: colors.ink, fontSize: 16 },
  aiEditor: { marginTop: 22, paddingTop: 20, borderTopWidth: 1, borderTopColor: colors.line },
  aiEditorLabel: { color: colors.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.5, marginTop: 18, marginBottom: 9 },
  aiSummaryInput: { minHeight: 78, paddingHorizontal: 14, paddingVertical: 12, borderWidth: 1, borderColor: colors.line, borderRadius: 14, backgroundColor: colors.paper, color: colors.ink, fontSize: 14, lineHeight: 20, textAlignVertical: "top" },
  aiChipRow: { gap: 8, paddingRight: 16 },
  aiWrapRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  aiChip: { minHeight: 40, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.line, borderRadius: 99, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center" },
  aiChipActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  aiChipText: { color: colors.muted, fontSize: 12, fontWeight: "800" },
  aiChipTextActive: { color: colors.paper },
  aiCounterRow: { minHeight: 72, marginTop: 18, paddingVertical: 12, borderTopWidth: 1, borderTopColor: colors.line, borderBottomWidth: 1, borderBottomColor: colors.line, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  aiCounterTitle: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  aiCounterHint: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  aiSmallInput: { minHeight: 50, marginTop: 10, paddingHorizontal: 13, borderWidth: 1, borderColor: colors.line, borderRadius: 12, backgroundColor: colors.paper, color: colors.ink, fontSize: 13 },
  aiMoneyInput: { minHeight: 54, borderWidth: 1, borderColor: colors.line, borderRadius: 13, backgroundColor: colors.paper, paddingHorizontal: 14, flexDirection: "row", alignItems: "center" },
  aiMoneyField: { flex: 1, color: colors.ink, fontSize: 17, fontWeight: "800" },
  aiMoneyCurrency: { color: colors.muted, fontSize: 12, fontWeight: "900" },
  aiNegotiable: { minHeight: 42, marginTop: 8, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderColor: colors.line, borderRadius: 12, backgroundColor: colors.paper },
  aiNegotiableActive: { borderColor: "#9CC8AA", backgroundColor: colors.mint },
  aiNegotiableText: { color: colors.muted, fontSize: 13, fontWeight: "800" },
  aiNegotiableTextActive: { color: colors.mintDark },
  safetyLock: { flexDirection: "row", gap: 9, marginTop: 18, padding: 13, borderRadius: 13, backgroundColor: colors.mint },
  safetyLockText: { flex: 1, color: colors.mintDark, fontSize: 12, lineHeight: 18, fontWeight: "700" },
  locationInput: { flex: 1, zIndex: 100 },
  locationConfirmed: { flexDirection: "row", alignItems: "center", gap: 7, marginTop: 12 },
  locationConfirmedText: { color: colors.mintDark, fontSize: 12, fontWeight: "700" },
  summaryCard: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 20, padding: 18 },
  summaryIcon: { width: 43, height: 43, borderRadius: 13, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  summaryTitle: { color: colors.ink, fontSize: 18, lineHeight: 25, fontWeight: "900", marginTop: 15 },
  summaryDivider: { height: 1, backgroundColor: colors.line, marginVertical: 17 },
  summaryRow: { minHeight: 52, flexDirection: "row", alignItems: "center", gap: 10, borderBottomWidth: 1, borderBottomColor: colors.line },
  summaryLabel: { width: 62, color: colors.muted, fontSize: 12, fontWeight: "700" },
  summaryValue: { flex: 1, color: colors.ink, fontSize: 13, lineHeight: 18 },
  summaryEdit: { color: colors.accent, fontSize: 12, fontWeight: "800" },
  participantEditor: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 10 },
  participantButton: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line },
  participantButtonDisabled: { opacity: 0.35 },
  participantCount: { minWidth: 22, textAlign: "center", color: colors.ink, fontSize: 16, fontWeight: "900" },
  signInProfileCard: { backgroundColor: colors.mint, borderWidth: 1, borderColor: "#C7E0CF", borderRadius: 18, padding: 18, alignItems: "flex-start" },
  signInProfileTitle: { color: colors.ink, fontSize: 15, fontWeight: "900", marginTop: 12 },
  signInProfileText: { color: colors.mintDark, fontSize: 12, lineHeight: 18, marginTop: 5 },
  profileChoices: { gap: 10 },
  profileChoice: { minHeight: 76, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 16, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", gap: 11 },
  profileChoiceActive: { borderColor: colors.mintDark, backgroundColor: "#F1FAF3" },
  profileChoiceIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center" },
  profileChoiceIconActive: { backgroundColor: colors.mintDark },
  profileChoiceCopy: { flex: 1 },
  profileChoiceTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" },
  profileChoiceText: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  addProfileButton: { minHeight: 52, marginTop: 13, borderWidth: 1, borderColor: colors.line, borderStyle: "dashed", borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  addProfileText: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  profileForm: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 15 },
  profileFormTitle: { color: colors.ink, fontSize: 16, fontWeight: "900", marginBottom: 12 },
  profileTypeRow: { flexDirection: "row", gap: 7, marginBottom: 10 },
  profileTypeButton: { flex: 1, minHeight: 40, borderRadius: 10, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  profileTypeButtonActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  profileTypeText: { color: colors.muted, fontSize: 12, fontWeight: "800" },
  profileTypeTextActive: { color: colors.paper },
  profileInput: { minHeight: 50, marginTop: 8, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.line, borderRadius: 12, backgroundColor: colors.cream, color: colors.ink, fontSize: 13 },
  profileFieldLabel: { color: colors.ink, fontSize: 13, fontWeight: "800", marginTop: 8, marginBottom: -5 },
  profileFormActions: { flexDirection: "row", gap: 8, marginTop: 13 },
  profileCancel: { flex: 1, minHeight: 46, borderRadius: 12, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  profileCancelText: { color: colors.muted, fontSize: 12, fontWeight: "800" },
  profileSave: { flex: 1.5, minHeight: 46, borderRadius: 12, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center" },
  profileSaveText: { color: colors.paper, fontSize: 12, fontWeight: "900" },
  flowFooter: { width: "100%", maxWidth: 600, alignSelf: "center", backgroundColor: colors.cream, paddingHorizontal: 22, paddingTop: 8, paddingBottom: 10, borderTopWidth: 1, borderTopColor: colors.line },
  flowError: { color: colors.accentDark, backgroundColor: colors.dangerSoft, borderRadius: 12, padding: 12, fontSize: 13, lineHeight: 19, fontWeight: "700", marginBottom: 8 },
  flowButton: { minHeight: 58, backgroundColor: colors.accent, borderRadius: 16, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  flowButtonText: { color: colors.paper, fontSize: 16, fontWeight: "900" },
  safe: { flex: 1, backgroundColor: colors.cream }, flex: { flex: 1 }, content: { padding: 18, paddingBottom: 35 }, title: { color: colors.ink, fontSize: 27, fontWeight: "900", letterSpacing: -0.7 }, subtitle: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 6, marginBottom: 17 }, label: { color: colors.ink, fontSize: 12, fontWeight: "900", marginTop: 15, marginBottom: 8 }, sectionTitle: { color: colors.ink, fontSize: 13, fontWeight: "800", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 12 },
  quickPrompts: { gap: 8, paddingRight: 10, marginBottom: 3 },
  quickPrompt: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 99, paddingHorizontal: 13, paddingVertical: 10 },
  quickPromptText: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12, flexWrap: "wrap" },
  description: { minHeight: 115, paddingVertical: 14, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 14, paddingHorizontal: 13, color: colors.text, fontSize: 14, lineHeight: 20 }, emergency: { backgroundColor: colors.dangerSoft, borderRadius: 12, padding: 11, flexDirection: "row", gap: 8, marginTop: 9 }, emergencyText: { color: colors.accentDark, fontSize: 12, lineHeight: 17, flex: 1, fontWeight: "700" },
  intentPanel: { backgroundColor: colors.paper, borderWidth: 1, borderColor: "#B9DDC6", borderRadius: 18, padding: 14, marginTop: 12 },
  intentHeader: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  intentIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  intentCopy: { flex: 1 },
  intentEyebrow: { color: colors.mintDark, fontSize: 11, fontWeight: "900", letterSpacing: 0.6 },
  intentTitle: { color: colors.ink, fontSize: 14, lineHeight: 20, fontWeight: "900", marginTop: 3 },
  intentMeta: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  analysisStatus: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 7 },
  analysisStatusText: { color: colors.mintDark, fontSize: 11, fontWeight: "700" },
  analysisFallback: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 7 },
  clarification: { backgroundColor: "#F2F8F3", borderWidth: 1, borderColor: "#CBE2D1", borderRadius: 14, padding: 12, marginTop: 13 },
  clarificationLabel: { color: colors.mintDark, fontSize: 11, fontWeight: "900", letterSpacing: 0.5 },
  clarificationPrompt: { color: colors.ink, fontSize: 13, lineHeight: 18, fontWeight: "900", marginTop: 5 },
  clarificationHelp: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 3 },
  clarificationOptions: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 10 },
  clarificationOption: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 99, paddingHorizontal: 10, paddingVertical: 8 },
  clarificationOptionActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  clarificationOptionText: { color: colors.ink, fontSize: 11, fontWeight: "800" },
  clarificationOptionTextActive: { color: colors.paper },
  clarificationInput: { marginTop: 10, marginBottom: 0 },
  solutionQuestion: { color: colors.ink, fontSize: 12, fontWeight: "900", marginTop: 15, marginBottom: 9 },
  solutionGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  solutionCard: { flexGrow: 1, flexBasis: "46%", minHeight: 108, borderWidth: 1, borderColor: colors.line, borderRadius: 14, padding: 14, backgroundColor: colors.cream },
  solutionCardActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  solutionTop: { minHeight: 23, flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 5 },
  recommended: { color: colors.mintDark, backgroundColor: colors.mint, borderRadius: 99, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 5, fontSize: 11, fontWeight: "900", letterSpacing: 0.3 },
  recommendedActive: { color: colors.ink, backgroundColor: colors.yellow },
  solutionTitle: { color: colors.ink, fontSize: 14, lineHeight: 18, fontWeight: "900", marginTop: 8 },
  solutionTextActive: { color: colors.paper },
  solutionDescription: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 5 },
  solutionDescriptionActive: { color: "#D7E0D9" },
  dynamicField: { marginTop: 13, borderTopWidth: 1, borderTopColor: colors.line, paddingTop: 12 },
  dynamicLabel: { color: colors.ink, fontSize: 12, fontWeight: "900", marginBottom: 8 },
  suggestion: { backgroundColor: colors.mint, borderRadius: 14, padding: 13, flexDirection: "row", alignItems: "center", gap: 10, marginTop: 12 }, suggestionCopy: { flex: 1 }, suggestionLabel: { color: colors.mintDark, fontSize: 11, fontWeight: "900", letterSpacing: 0.5 }, suggestionValue: { color: colors.mintDark, fontSize: 13, fontWeight: "900", marginTop: 3 }, chips: { gap: 7, paddingRight: 10 }, chip: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 99, paddingHorizontal: 11, paddingVertical: 9 }, chipActive: { backgroundColor: colors.ink, borderColor: colors.ink }, chipText: { color: colors.muted, fontSize: 11, fontWeight: "800" }, chipTextActive: { color: colors.paper },
  urgencies: { flexDirection: "row", gap: 7, flexWrap: "wrap" }, urgency: { flex: 1, alignItems: "center", backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 11, paddingVertical: 11, minWidth: 90 }, urgencyActive: { backgroundColor: colors.ink, borderColor: colors.ink }, urgencyText: { color: colors.muted, fontSize: 11, fontWeight: "800", textAlign: "center" }, urgencyTextActive: { color: colors.paper }, input: { minHeight: 52, paddingVertical: 14, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 13, paddingHorizontal: 13, color: colors.text, marginBottom: 10 }, privacy: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.mint, borderRadius: 14, padding: 14, marginTop: 24, zIndex: 1 }, privacyText: { color: colors.mintDark, fontSize: 12, lineHeight: 18, flex: 1 }, error: { color: colors.accentDark, fontSize: 12, lineHeight: 17, fontWeight: "700", marginTop: 11 }, submit: { minHeight: 53, paddingVertical: 14, backgroundColor: colors.accent, borderRadius: 14, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 17 }, submitText: { color: colors.paper, fontSize: 13, fontWeight: "900" }, pressed: { opacity: 0.8 },
  priceHint: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 2, marginBottom: 10 },
  locationRow: { flexDirection: "row", gap: 8, zIndex: 100 }, gpsBtn: { minWidth: 88, height: 52, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 13, alignItems: "center", justifyContent: "center", gap: 1, paddingHorizontal: 8 }, gpsBtnActive: { backgroundColor: colors.mint, borderColor: "#B8DEC5" }, gpsBtnText: { color: colors.ink, fontSize: 11, fontWeight: "800" }, gpsBtnTextActive: { color: colors.mintDark }, gpsSuccess: { color: colors.mintDark, fontSize: 11, fontWeight: "800", marginTop: 4 },
  photoContainer: { marginVertical: 6, paddingTop: 8, paddingRight: 8 },
  photoThumbWrap: { position: "relative", width: 74, height: 74, borderRadius: 12, overflow: "visible" },
  photoThumb: { width: 74, height: 74, borderRadius: 12, backgroundColor: colors.paper },
  photoRemove: { position: "absolute", top: 2, right: 2, backgroundColor: colors.paper, borderRadius: 14, padding: 4 },
  addPhotoBtn: { width: 90, height: 74, borderRadius: 12, borderWidth: 1, borderColor: colors.line, borderStyle: "dashed", backgroundColor: colors.paper, alignItems: "center", justifyContent: "center", gap: 3 },
  addPhotoText: { color: colors.muted, fontSize: 11, fontWeight: "800" },
});
