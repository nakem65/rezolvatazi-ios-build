import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import * as ImagePicker from "expo-image-picker";
import { router } from "expo-router";
import { useState } from "react";
import { Linking, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { AppHeader } from "@/components/AppHeader";
import { Screen } from "@/components/Screen";
import { createSupportTicket, type SupportAttachment, uploadSupportAttachment } from "@/src/api";
import { showAppAlert } from "@/src/alerts";
import { publicSupportWhatsAppUrl } from "@/src/publicContact";
import { colors } from "@/src/theme";

const quickAnswers = [
  {
    title: "Publicarea unei cereri",
    text: "Descrii lucrarea, verifici detaliile, alegi profilul și confirmi numărul. Publicarea cererii este gratuită.",
  },
  {
    title: "Trimiterea unei oferte",
    text: "În modul Prestator deschizi o cerere potrivită, introduci prețul, disponibilitatea și mesajul pentru client.",
  },
  {
    title: "Chatul unei lucrări",
    text: "Chatul se deschide după alegerea ofertei. Acolo puteți clarifica detaliile și trimite fotografii.",
  },
  {
    title: "Siguranță",
    text: "Pentru pericol imediat sună la 112. Pentru o problemă cu un utilizator, alege categoria Siguranță și scrie-ne.",
  },
];

const categories = [
  ["cont", "Cont și autentificare"],
  ["cerere", "Cerere publicată"],
  ["oferta", "Ofertă sau prestator"],
  ["plata", "Preț, ofertă sau costuri"],
  ["siguranta", "Siguranță"],
  ["eroare", "Problemă tehnică"],
  ["alta", "Altceva"],
] as const;

export default function SupportScreen() {
  const [selectedAnswer, setSelectedAnswer] = useState(0);
  const [category, setCategory] = useState("eroare");
  const [message, setMessage] = useState("");
  const [attachments, setAttachments] = useState<SupportAttachment[]>([]);
  const [sending, setSending] = useState(false);
  const [ticketCode, setTicketCode] = useState("");

  async function pickAttachment() {
    if (attachments.length >= 2) {
      showAppAlert("Limită atinsă", "Poți adăuga maximum două fișiere la o solicitare.");
      return;
    }
    let result: ImagePicker.ImagePickerResult;
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        showAppAlert("Permisiune necesară", "Permite accesul la fotografii pentru a adăuga un atașament.");
        return;
      }
      result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images", "videos"],
        allowsMultipleSelection: false,
        videoMaxDuration: 30,
        quality: 0.75,
      });
    } catch {
      showAppAlert("Galerie indisponibilă", "Fișierele nu pot fi deschise pe acest dispozitiv. Încearcă din nou.");
      return;
    }
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    const isVideo = asset.type === "video";
    const maximumBytes = isVideo ? 25 * 1024 * 1024 : 5 * 1024 * 1024;
    if (asset.fileSize && asset.fileSize > maximumBytes) {
      showAppAlert("Fișier prea mare", isVideo ? "Filmarea poate avea maximum 25 MB." : "Fotografia poate avea maximum 5 MB.");
      return;
    }
    const extension = isVideo ? "mp4" : "jpg";
    setAttachments((current) => [...current, {
      uri: asset.uri,
      name: asset.fileName || `atasament-${Date.now()}.${extension}`,
      mimeType: asset.mimeType || (isVideo ? "video/mp4" : "image/jpeg"),
    }]);
  }

  async function submit() {
    if (message.trim().length < 10) {
      showAppAlert("Mai avem nevoie de un detaliu", "Descrie problema în cel puțin 10 caractere.");
      return;
    }
    setSending(true);
    try {
      const attachmentKeys: string[] = [];
      for (const attachment of attachments) {
        const uploaded = await uploadSupportAttachment(attachment);
        attachmentKeys.push(uploaded.key);
      }
      const result = await createSupportTicket({ category, message: message.trim(), attachmentKeys });
      setTicketCode(result.ticket.code);
      setMessage("");
      setAttachments([]);
    } catch (caught) {
      showAppAlert("Nu am putut trimite solicitarea", caught instanceof Error ? caught.message : "Verifică internetul și încearcă din nou.");
    } finally {
      setSending(false);
    }
  }

  async function openWhatsAppSupport() {
    try {
      const supported = await Linking.canOpenURL(publicSupportWhatsAppUrl);
      if (!supported) throw new Error("WhatsApp nu este disponibil pe acest dispozitiv.");
      await Linking.openURL(publicSupportWhatsAppUrl);
    } catch (caught) {
      showAppAlert("Nu am putut deschide WhatsApp", caught instanceof Error ? caught.message : "Încearcă din nou mai târziu.");
    }
  }

  return (
    <Screen>
      <View style={styles.topRow}>
        <Pressable accessibilityLabel="Înapoi" onPress={() => router.back()} style={styles.back}>
          <MaterialCommunityIcons name="arrow-left" size={22} color={colors.ink} />
        </Pressable>
        <View style={styles.headerWrap}><AppHeader title="Ajutor și suport" hideSupport /></View>
      </View>

      <View style={styles.intro}>
        <View style={styles.introIcon}><MaterialCommunityIcons name="chat-processing-outline" size={25} color={colors.mintDark} /></View>
        <View style={styles.introCopy}>
          <Text style={styles.introTitle}>Cu ce te putem ajuta?</Text>
          <Text style={styles.introText}>Găsește un răspuns rapid sau trimite echipei o solicitare cu fotografii ori filmări.</Text>
        </View>
      </View>

      <Text style={styles.sectionLabel}>RĂSPUNSURI RAPIDE</Text>
      <View style={styles.quickList}>
        {quickAnswers.map((item, index) => (
          <Pressable key={item.title} onPress={() => setSelectedAnswer(index)} style={[styles.quickButton, selectedAnswer === index && styles.quickButtonActive]}>
            <Text style={[styles.quickTitle, selectedAnswer === index && styles.quickTitleActive]}>{item.title}</Text>
            <MaterialCommunityIcons name={selectedAnswer === index ? "chevron-up" : "chevron-down"} size={20} color={selectedAnswer === index ? colors.mintDark : colors.muted} />
            {selectedAnswer === index ? <Text style={styles.quickText}>{item.text}</Text> : null}
          </Pressable>
        ))}
      </View>

      <Text style={styles.sectionLabel}>SCRIE ECHIPEI REZOLVATAZI</Text>
      <View style={styles.formCard}>
        <Text style={styles.label}>Categoria</Text>
        <View style={styles.categoryList}>
          {categories.map(([value, label]) => (
            <Pressable key={value} onPress={() => setCategory(value)} style={[styles.category, category === value && styles.categoryActive]}>
              <Text style={[styles.categoryText, category === value && styles.categoryTextActive]}>{label}</Text>
            </Pressable>
          ))}
        </View>

        <Text style={styles.label}>Descrie problema</Text>
        <TextInput
          value={message}
          onChangeText={setMessage}
          multiline
          maxLength={2_000}
          placeholder="Spune-ne ce ai încercat și ce s-a întâmplat…"
          placeholderTextColor="#929B95"
          style={styles.messageInput}
          textAlignVertical="top"
        />

        <Pressable onPress={() => void pickAttachment()} style={styles.attachmentButton}>
          <MaterialCommunityIcons name="paperclip" size={21} color={colors.ink} />
          <View style={styles.attachmentCopy}>
            <Text style={styles.attachmentTitle}>Adaugă fotografie sau filmare</Text>
            <Text style={styles.attachmentHint}>Maximum 2 fișiere · filmare de cel mult 30 secunde</Text>
          </View>
          <MaterialCommunityIcons name="plus" size={20} color={colors.muted} />
        </Pressable>
        {attachments.map((attachment, index) => (
          <View key={`${attachment.uri}-${index}`} style={styles.fileRow}>
            <MaterialCommunityIcons name={attachment.mimeType.startsWith("video/") ? "video-outline" : "image-outline"} size={20} color={colors.mintDark} />
            <Text style={styles.fileName} numberOfLines={1}>{attachment.name}</Text>
            <Pressable onPress={() => setAttachments((current) => current.filter((_, itemIndex) => itemIndex !== index))}>
              <MaterialCommunityIcons name="close-circle" size={20} color={colors.accentDark} />
            </Pressable>
          </View>
        ))}

        {ticketCode ? (
          <View style={styles.success}>
            <MaterialCommunityIcons name="check-circle" size={22} color={colors.mintDark} />
            <View><Text style={styles.successTitle}>Solicitarea a fost trimisă</Text><Text style={styles.successText}>Cod suport: {ticketCode}</Text></View>
          </View>
        ) : null}

        <Pressable disabled={sending} onPress={() => void submit()} style={({ pressed }) => [styles.submit, (pressed || sending) && { opacity: 0.58 }]}>
          <Text style={styles.submitText}>{sending ? "Se trimite…" : "Trimite solicitarea"}</Text>
          <MaterialCommunityIcons name="arrow-right" size={20} color={colors.paper} />
        </Pressable>
        <Pressable accessibilityLabel="Scrie echipei de suport pe WhatsApp" onPress={() => void openWhatsAppSupport()} style={({ pressed }) => [styles.whatsapp, pressed && { opacity: 0.65 }]}>
          <MaterialCommunityIcons name="whatsapp" size={20} color={colors.mintDark} />
          <View style={styles.whatsappCopy}><Text style={styles.whatsappTitle}>Scrie pe WhatsApp</Text><Text style={styles.whatsappHint}>Suport RezolvatAzi, separat de chatul lucrării</Text></View>
          <MaterialCommunityIcons name="open-in-new" size={18} color={colors.mintDark} />
        </Pressable>
        <Text style={styles.whatsappNote}>Nu trimite coduri SMS, date de card, CNP sau adresa exactă în acest chat.</Text>
      </View>
      <Text style={styles.safetyNote}>Pentru incendiu, gaze, electrocutare, persoane rănite sau alt pericol imediat, sună la 112.</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  topRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  back: { width: 42, height: 42, borderRadius: 13, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center", marginBottom: 10 },
  headerWrap: { flex: 1 },
  intro: { flexDirection: "row", alignItems: "center", gap: 12, padding: 16, borderWidth: 1, borderColor: "#C4DDCC", borderRadius: 18, backgroundColor: colors.mint, marginBottom: 24 },
  introIcon: { width: 48, height: 48, borderRadius: 15, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center" },
  introCopy: { flex: 1 },
  introTitle: { color: colors.ink, fontSize: 16, fontWeight: "900" },
  introText: { color: colors.mintDark, fontSize: 12, lineHeight: 18, marginTop: 4 },
  sectionLabel: { color: colors.muted, fontSize: 11, fontWeight: "900", letterSpacing: 0.8, marginLeft: 4, marginBottom: 8 },
  quickList: { gap: 7, marginBottom: 25 },
  quickButton: { minHeight: 49, display: "flex", flexDirection: "row", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", padding: 13, borderWidth: 1, borderColor: colors.line, borderRadius: 13, backgroundColor: colors.paper },
  quickButtonActive: { borderColor: "#AACDB5", backgroundColor: "#F0F8F3" },
  quickTitle: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  quickTitleActive: { color: colors.mintDark },
  quickText: { width: "100%", color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 9 },
  formCard: { padding: 15, borderWidth: 1, borderColor: colors.line, borderRadius: 18, backgroundColor: colors.paper },
  label: { color: colors.ink, fontSize: 12, fontWeight: "800", marginBottom: 7, marginTop: 5 },
  categoryList: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 13 },
  category: { paddingHorizontal: 10, paddingVertical: 8, borderWidth: 1, borderColor: colors.line, borderRadius: 99, backgroundColor: colors.cream },
  categoryActive: { borderColor: colors.mintDark, backgroundColor: colors.mint },
  categoryText: { color: colors.muted, fontSize: 11, fontWeight: "700" },
  categoryTextActive: { color: colors.mintDark, fontWeight: "900" },
  messageInput: { minHeight: 115, padding: 12, borderWidth: 1, borderColor: colors.line, borderRadius: 12, color: colors.ink, backgroundColor: colors.cream, fontSize: 13, lineHeight: 18 },
  attachmentButton: { minHeight: 58, flexDirection: "row", alignItems: "center", gap: 10, padding: 11, borderWidth: 1, borderStyle: "dashed", borderColor: "#B5C2B9", borderRadius: 12, backgroundColor: "#F8F9F7", marginTop: 12 },
  attachmentCopy: { flex: 1 },
  attachmentTitle: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  attachmentHint: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 3 },
  fileRow: { minHeight: 42, flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 10, borderRadius: 10, backgroundColor: colors.mint, marginTop: 7 },
  fileName: { flex: 1, color: colors.ink, fontSize: 12, fontWeight: "600" },
  success: { flexDirection: "row", alignItems: "center", gap: 9, padding: 11, borderWidth: 1, borderColor: "#AED1B8", borderRadius: 11, backgroundColor: colors.mint, marginTop: 12 },
  successTitle: { color: colors.mintDark, fontSize: 12, fontWeight: "900" },
  successText: { color: colors.mintDark, fontSize: 11, lineHeight: 16, marginTop: 2 },
  submit: { minHeight: 49, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 14, borderRadius: 12, backgroundColor: colors.accent, marginTop: 13 },
  submitText: { color: colors.paper, fontSize: 12, fontWeight: "900" },
  whatsapp: { minHeight: 58, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12, borderWidth: 1, borderColor: "#A9CFB4", borderRadius: 12, backgroundColor: "#F1F8F3", marginTop: 10 },
  whatsappCopy: { flex: 1 },
  whatsappTitle: { color: colors.mintDark, fontSize: 12, fontWeight: "900" },
  whatsappHint: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 3 },
  whatsappNote: { color: colors.muted, fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: 7, paddingHorizontal: 6 },
  safetyNote: { color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 13, paddingHorizontal: 15 },
});
