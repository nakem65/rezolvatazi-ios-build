import { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { AppHeader } from "@/components/AppHeader";
import { Screen } from "@/components/Screen";
import { submitKYC } from "@/src/api";
import { useAuth } from "@/src/AuthContext";
import { colors, shadow } from "@/src/theme";
import { showAppAlert } from "@/src/alerts";

export default function KYCScreen() {
  const { provider, setProvider } = useAuth();
  const [submitting, setSubmitting] = useState(false);

  if (!provider) return null;

  async function requestVerification() {
    setSubmitting(true);
    try {
      const result = await submitKYC();
      setProvider(result.provider);
      showAppAlert(
        "Cerere înregistrată",
        "Cererea ta este în curs de verificare. Îți spunem dacă avem nevoie de informații suplimentare.",
      );
      router.back();
    } catch {
      showAppAlert("Eroare", "Cererea de verificare nu a putut fi trimisă. Încearcă din nou.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Screen>
      <AppHeader eyebrow="Încredere" title="Verificare prestator" hideRoleSwitcher />
      <View style={styles.card}>
        <View style={styles.icon}>
          <MaterialCommunityIcons name="shield-account-outline" size={32} color={colors.mintDark} />
        </View>
        <Text style={styles.title}>Solicită verificarea profilului</Text>
        <Text style={styles.text}>
          Trimite cererea, iar noi îți spunem dacă avem nevoie de informații suplimentare pentru forma în care lucrezi.
        </Text>
        <Pressable
          disabled={submitting || provider.kycStatus === "pending"}
          onPress={() => void requestVerification()}
          style={({ pressed }) => [styles.button, (pressed || submitting || provider.kycStatus === "pending") && styles.disabled]}
        >
          <Text style={styles.buttonText}>
            {provider.kycStatus === "pending" ? "Verificare în așteptare" : submitting ? "Se trimite..." : "Solicită verificarea"}
          </Text>
          <MaterialCommunityIcons name="arrow-right" size={20} color={colors.paper} />
        </Pressable>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: colors.paper, borderRadius: 20, padding: 20, marginTop: 12, borderWidth: 1, borderColor: colors.line, ...shadow },
  icon: { width: 58, height: 58, borderRadius: 18, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  title: { color: colors.ink, fontSize: 21, lineHeight: 27, fontWeight: "900", marginTop: 18 },
  text: { color: colors.muted, fontSize: 13, lineHeight: 20, marginTop: 8 },
  notice: { flexDirection: "row", gap: 9, backgroundColor: "#FFF2CE", borderRadius: 13, padding: 12, marginTop: 18 },
  noticeText: { color: "#725814", fontSize: 10, lineHeight: 16, flex: 1 },
  button: { minHeight: 53, backgroundColor: colors.mintDark, borderRadius: 13, paddingHorizontal: 15, marginTop: 19, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  buttonText: { color: colors.paper, fontSize: 12, fontWeight: "900" },
  disabled: { opacity: 0.55 },
});
