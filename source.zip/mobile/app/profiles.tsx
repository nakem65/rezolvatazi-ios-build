import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  acceptProfileInvitation,
  addAccountProfileMedia,
  createAccountProfile,
  fetchAccountProfileMembers,
  fetchAccountProfiles,
  fetchProfileInvitations,
  inviteAccountProfileMember,
} from "@/src/api";
import { useAuth } from "@/src/AuthContext";
import { pickImageFromGallery } from "@/src/mediaPicker";
import { isValidRomanianTaxId, normalizeRomanianTaxId } from "@/src/romanianTaxId";
import { colors, shadow } from "@/src/theme";
import type { AccountProfile, ProfileInvitation, RequestProfileType } from "@/src/types";

type Member = Awaited<ReturnType<typeof fetchAccountProfileMembers>>["members"][number];

const profileTypeLabel: Record<RequestProfileType, string> = {
  person: "Persoană",
  pfa: "PFA",
  company: "Firmă",
  organization: "Organizație",
};

function RatingLine({ label, rating, count, completed }: { label: string; rating: number; count: number; completed: number }) {
  return (
    <View style={styles.ratingLine}>
      <Text style={styles.ratingLabel}>{label}</Text>
      <Text style={styles.ratingValue}>{count ? `★ ${(rating / 10).toFixed(1).replace(".", ",")} · ${count} recenzii` : "Fără recenzii"}</Text>
      <Text style={styles.completed}>{completed} finalizate</Text>
    </View>
  );
}

export default function ProfilesScreen() {
  const { provider, status } = useAuth();
  const [profiles, setProfiles] = useState<AccountProfile[]>([]);
  const [invitations, setInvitations] = useState<ProfileInvitation[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [profileType, setProfileType] = useState<Exclude<RequestProfileType, "person">>("company");
  const [label, setLabel] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [legalName, setLegalName] = useState("");
  const [taxId, setTaxId] = useState("");
  const [photo, setPhoto] = useState<string | null>(null);
  const [invitePhone, setInvitePhone] = useState("");
  const [inviteRole, setInviteRole] = useState<"admin" | "worker">("worker");
  const scrollRef = useRef<ScrollView>(null);
  const selected = profiles.find((profile) => profile.id === selectedId) ?? null;

  function revealCreateActions() {
    requestAnimationFrame(() => scrollRef.current?.scrollToEnd({ animated: true }));
  }

  function showFormError(message: string) {
    setError(message);
    revealCreateActions();
  }

  const load = useCallback(async () => {
    setError("");
    try {
      const [profileResult, invitationResult] = await Promise.all([
        fetchAccountProfiles(),
        fetchProfileInvitations(),
      ]);
      setProfiles(profileResult.profiles);
      setInvitations(invitationResult.invitations);
      setSelectedId((current) => current || profileResult.profiles[0]?.id || "");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Profilurile nu au putut fi încărcate.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (status === "loading") return;
    if (!provider || status === "signedOut") {
      router.replace({ pathname: "/sign-in", params: { returnTo: "/profiles" } } as never);
      return;
    }
    void load();
  }, [load, provider, status]);

  useEffect(() => {
    if (!selected?.canManage || selected.profileType === "person") {
      setMembers([]);
      return;
    }
    void fetchAccountProfileMembers(selected.id)
      .then((result) => setMembers(result.members))
      .catch(() => setMembers([]));
  }, [selected?.id, selected?.canManage, selected?.profileType]);

  async function choosePrimaryPhoto(profile: AccountProfile) {
    const uri = await pickImageFromGallery();
    if (!uri) return;
    setBusy(true);
    setError("");
    try {
      await addAccountProfileMedia(profile.id, { kind: profile.profileType === "person" ? "avatar" : "logo", url: uri });
      await load();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Imaginea nu a putut fi salvată.");
    } finally {
      setBusy(false);
    }
  }

  async function addPortfolioPhoto(profile: AccountProfile) {
    const uri = await pickImageFromGallery();
    if (!uri) return;
    setBusy(true);
    setError("");
    try {
      await addAccountProfileMedia(profile.id, { kind: "portfolio", url: uri });
      await load();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Fotografia nu a putut fi adăugată.");
    } finally {
      setBusy(false);
    }
  }

  async function saveProfile() {
    if (!label.trim() || displayName.trim().length < 2 || legalName.trim().length < 2 || taxId.trim().length < 2) {
      showFormError("Completează eticheta, numele public, denumirea legală și CUI/CIF.");
      return;
    }
    if (!isValidRomanianTaxId(taxId)) {
      showFormError("CUI/CIF nu este valid. Verifică cifrele introduse.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const { profile } = await createAccountProfile({
        label: label.trim(),
        profileType,
        displayName: displayName.trim(),
        legalName: legalName.trim(),
        taxId: normalizeRomanianTaxId(taxId),
        avatarUrl: photo,
      });
      setShowCreate(false);
      setLabel("");
      setDisplayName("");
      setLegalName("");
      setTaxId("");
      setPhoto(null);
      await load();
      if (profile?.id) setSelectedId(profile.id);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Profilul nu a putut fi creat.");
    } finally {
      setBusy(false);
    }
  }

  async function sendInvite() {
    if (!selected || invitePhone.trim().length < 10) {
      setError("Introdu numărul persoanei pe care vrei să o inviți.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await inviteAccountProfileMember(selected.id, invitePhone, inviteRole);
      setInvitePhone("");
      const result = await fetchAccountProfileMembers(selected.id);
      setMembers(result.members);
      Alert.alert("Invitație creată", "Persoana va vedea invitația după ce intră în aplicație cu acel număr.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Invitația nu a putut fi trimisă.");
    } finally {
      setBusy(false);
    }
  }

  async function acceptInvite(invitation: ProfileInvitation) {
    setBusy(true);
    setError("");
    try {
      await acceptProfileInvitation(invitation.id);
      await load();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Invitația nu a putut fi acceptată.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color={colors.accent} /><Text style={styles.muted}>Încărcăm profilurile...</Text></SafeAreaView>;
  }

  return (
    <SafeAreaView style={styles.safe} edges={["top", "bottom"]}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={0}>
      <ScrollView
        ref={scrollRef}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.back}><MaterialCommunityIcons name="arrow-left" size={22} color={colors.ink} /></Pressable>
          <View style={styles.headerCopy}><Text style={styles.title}>Profiluri și echipe</Text><Text style={styles.subtitle}>Același cont, identități și reputații separate.</Text></View>
        </View>

        {invitations.length ? (
          <View style={styles.invitationBox}>
            <Text style={styles.sectionTitle}>Invitații primite</Text>
            {invitations.map((invitation) => (
              <View key={invitation.id} style={styles.invitationRow}>
                <View style={styles.flex}>
                  <Text style={styles.cardTitle}>{invitation.profileName}</Text>
                  <Text style={styles.muted}>Invitat de {invitation.invitedBy} · {invitation.role === "admin" ? "administrator" : "membru"}</Text>
                </View>
                <Pressable disabled={busy} onPress={() => void acceptInvite(invitation)} style={styles.smallPrimary}><Text style={styles.smallPrimaryText}>Acceptă</Text></Pressable>
              </View>
            ))}
          </View>
        ) : null}

        <View style={styles.sectionHeader}>
          <View><Text style={styles.sectionTitle}>Profilurile tale</Text><Text style={styles.muted}>Fiecare păstrează propriile poze și recenzii.</Text></View>
          <Pressable accessibilityRole="button" accessibilityLabel="Adaugă un profil juridic" onPress={() => { setError(""); setShowCreate((current) => !current); requestAnimationFrame(() => scrollRef.current?.scrollToEnd({ animated: true })); }} style={styles.addButton}><MaterialCommunityIcons name="plus" size={18} color={colors.paper} /><Text style={styles.addButtonText}>Adaugă</Text></Pressable>
        </View>

        {showCreate ? (
          <View style={styles.formCard}>
            <Text style={styles.formTitle}>Profil juridic nou</Text>
            <View style={styles.typeRow}>
              {(["pfa", "company", "organization"] as const).map((type) => (
                <Pressable key={type} accessibilityRole="radio" accessibilityState={{ checked: profileType === type }} onPress={() => setProfileType(type)} style={[styles.typeChip, profileType === type && styles.typeChipActive]}>
                  <Text style={[styles.typeText, profileType === type && styles.typeTextActive]}>{profileTypeLabel[type]}</Text>
                </Pressable>
              ))}
            </View>
            <TextInput accessibilityLabel="Eticheta profilului" value={label} onChangeText={setLabel} onFocus={revealCreateActions} placeholder="Etichetă: Instal 24, eMAG..." placeholderTextColor="#909991" style={styles.input} />
            <TextInput accessibilityLabel="Numele afișat public" value={displayName} onChangeText={setDisplayName} onFocus={revealCreateActions} placeholder="Numele afișat public" placeholderTextColor="#909991" style={styles.input} />
            <TextInput accessibilityLabel="Denumirea legală" value={legalName} onChangeText={setLegalName} onFocus={revealCreateActions} placeholder="Denumirea legală" placeholderTextColor="#909991" style={styles.input} />
            <TextInput accessibilityLabel="CUI sau CIF" value={taxId} onChangeText={setTaxId} onFocus={revealCreateActions} placeholder="CUI / CIF" autoCapitalize="characters" placeholderTextColor="#909991" style={styles.input} />
            <Pressable accessibilityRole="button" accessibilityLabel={photo ? "Schimbă logo-ul profilului" : "Adaugă logo-ul profilului"} onPress={async () => setPhoto(await pickImageFromGallery())} style={styles.photoPicker}>
              {photo ? <Image source={{ uri: photo }} style={styles.photoPreview} /> : <MaterialCommunityIcons name="image-plus" size={22} color={colors.ink} />}
              <Text style={styles.photoPickerText}>{photo ? "Schimbă logo-ul" : "Adaugă logo"}</Text>
            </Pressable>
            <Pressable accessibilityRole="button" disabled={busy} onPress={() => void saveProfile()} style={styles.primary}><Text style={styles.primaryText}>{busy ? "Se salvează..." : "Creează profilul"}</Text></Pressable>
          </View>
        ) : null}

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.profileTabs}>
          {profiles.map((profile) => (
            <Pressable key={profile.id} onPress={() => setSelectedId(profile.id)} style={[styles.profileTab, selectedId === profile.id && styles.profileTabActive]}>
              {profile.avatarUrl ? <Image source={{ uri: profile.avatarUrl }} style={styles.tabAvatar} /> : <View style={styles.tabAvatarFallback}><Text style={styles.tabInitial}>{profile.displayName.charAt(0).toUpperCase()}</Text></View>}
              <Text numberOfLines={1} style={[styles.profileTabText, selectedId === profile.id && styles.profileTabTextActive]}>{profile.label}</Text>
            </Pressable>
          ))}
        </ScrollView>

        {selected ? (
          <>
            <View style={styles.profileCard}>
              <Pressable disabled={!selected.canManage || busy} onPress={() => void choosePrimaryPhoto(selected)} style={styles.avatarWrap}>
                {selected.avatarUrl ? <Image source={{ uri: selected.avatarUrl }} style={styles.avatar} /> : <View style={styles.avatarFallback}><Text style={styles.avatarInitial}>{selected.displayName.charAt(0).toUpperCase()}</Text></View>}
                {selected.canManage ? <View style={styles.camera}><MaterialCommunityIcons name="camera" size={12} color={colors.paper} /></View> : null}
              </Pressable>
              <View style={styles.flex}>
                <Text style={styles.cardTitle}>{selected.displayName}</Text>
                <Text style={styles.profileMeta}>{profileTypeLabel[selected.profileType]} · {selected.role === "owner" ? "proprietar" : selected.role === "admin" ? "administrator" : "membru"}</Text>
              </View>
            </View>
            <View style={styles.reputationCard}>
              <Text style={styles.formTitle}>Reputație pe roluri</Text>
              <Pressable onPress={() => router.push({ pathname: "/reviews", params: { accountProfileId: selected.id, role: "client" } })}>
                <RatingLine label="Când solicită lucrări" rating={selected.clientRating} count={selected.clientReviewCount} completed={selected.clientCompletedJobs} />
              </Pressable>
              <Pressable onPress={() => router.push({ pathname: "/reviews", params: { accountProfileId: selected.id, role: "provider" } })}>
                <RatingLine label="Când prestează" rating={selected.providerRating} count={selected.providerReviewCount} completed={selected.providerCompletedJobs} />
              </Pressable>
            </View>
            <View style={styles.formCard}>
              <View style={styles.sectionHeader}>
                <View><Text style={styles.formTitle}>Portofoliu</Text><Text style={styles.muted}>Fotografii ale lucrărilor acestui profil.</Text></View>
                {selected.canManage ? <Pressable disabled={busy} onPress={() => void addPortfolioPhoto(selected)} style={styles.iconButton}><MaterialCommunityIcons name="image-plus" size={21} color={colors.ink} /></Pressable> : null}
              </View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.portfolio}>
                {selected.media.filter((item) => item.kind === "portfolio").map((item) => <Image key={item.id} source={{ uri: item.url }} style={styles.portfolioImage} />)}
                {!selected.media.some((item) => item.kind === "portfolio") ? <Text style={styles.muted}>Nu există încă fotografii.</Text> : null}
              </ScrollView>
            </View>
            {selected.canManage && selected.profileType !== "person" ? (
              <View style={styles.formCard}>
                <Text style={styles.formTitle}>Echipă</Text>
                <Text style={styles.muted}>Fiecare membru intră cu propriul număr și acceptă invitația.</Text>
                {members.map((member) => (
                  <View key={member.id} style={styles.memberRow}>
                    <MaterialCommunityIcons name={member.status === "active" ? "account-check-outline" : "clock-outline"} size={21} color={member.status === "active" ? colors.mintDark : colors.muted} />
                    <View style={styles.flex}><Text style={styles.memberName}>{member.name}</Text><Text style={styles.muted}>{member.role === "admin" ? "Administrator" : member.role === "owner" ? "Proprietar" : "Membru"} · {member.status === "active" ? "activ" : member.phone}</Text></View>
                  </View>
                ))}
                <TextInput value={invitePhone} onChangeText={setInvitePhone} placeholder="07xx xxx xxx" keyboardType="phone-pad" placeholderTextColor="#909991" style={styles.input} />
                <View style={styles.inviteActions}>
                  <Pressable onPress={() => setInviteRole("worker")} style={[styles.typeChip, inviteRole === "worker" && styles.typeChipActive]}><Text style={[styles.typeText, inviteRole === "worker" && styles.typeTextActive]}>Membru</Text></Pressable>
                  <Pressable onPress={() => setInviteRole("admin")} style={[styles.typeChip, inviteRole === "admin" && styles.typeChipActive]}><Text style={[styles.typeText, inviteRole === "admin" && styles.typeTextActive]}>Administrator</Text></Pressable>
                  <Pressable disabled={busy} onPress={() => void sendInvite()} style={styles.smallPrimary}><Text style={styles.smallPrimaryText}>Invită</Text></Pressable>
                </View>
              </View>
            ) : null}
          </>
        ) : null}
        {error ? <Text style={styles.error}>{error}</Text> : null}
      </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream },
  flex: { flex: 1 },
  center: { flex: 1, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center", gap: 12 },
  content: { width: "100%", maxWidth: 620, alignSelf: "center", paddingHorizontal: 20, paddingVertical: 18, paddingBottom: 50 },
  header: { flexDirection: "row", alignItems: "center", gap: 13, marginBottom: 24 },
  headerCopy: { flex: 1 },
  back: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.line },
  title: { color: colors.ink, fontSize: 28, fontWeight: "900", letterSpacing: -0.8 },
  subtitle: { color: colors.muted, fontSize: 13, marginTop: 3 },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  sectionTitle: { color: colors.ink, fontSize: 18, fontWeight: "900" },
  muted: { color: colors.muted, fontSize: 12, lineHeight: 17 },
  addButton: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: colors.ink, borderRadius: 12, paddingHorizontal: 13, height: 40 },
  addButtonText: { color: colors.paper, fontSize: 12, fontWeight: "900" },
  invitationBox: { backgroundColor: colors.mint, borderRadius: 18, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: "#C7E0CF" },
  invitationRow: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 12 },
  formCard: { backgroundColor: colors.paper, borderRadius: 20, padding: 17, marginTop: 16, borderWidth: 1, borderColor: colors.line, ...shadow },
  formTitle: { color: colors.ink, fontSize: 15, fontWeight: "900", marginBottom: 10 },
  typeRow: { flexDirection: "row", gap: 7, marginBottom: 10 },
  typeChip: { minHeight: 38, paddingHorizontal: 12, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line },
  typeChipActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  typeText: { color: colors.muted, fontSize: 11, fontWeight: "800" },
  typeTextActive: { color: colors.paper },
  input: { minHeight: 48, borderRadius: 13, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 14, color: colors.ink, fontSize: 14, marginTop: 9 },
  photoPicker: { minHeight: 52, marginTop: 10, borderRadius: 13, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line },
  photoPreview: { width: 38, height: 38, borderRadius: 10 },
  photoPickerText: { color: colors.ink, fontSize: 13, fontWeight: "800" },
  primary: { height: 48, borderRadius: 14, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center", marginTop: 13 },
  primaryText: { color: colors.paper, fontSize: 14, fontWeight: "900" },
  smallPrimary: { minHeight: 38, borderRadius: 11, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center", paddingHorizontal: 13 },
  smallPrimaryText: { color: colors.paper, fontSize: 11, fontWeight: "900" },
  profileTabs: { gap: 9, paddingVertical: 17 },
  profileTab: { width: 104, minHeight: 82, borderRadius: 16, padding: 10, alignItems: "center", backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line },
  profileTabActive: { borderColor: colors.ink, backgroundColor: colors.ink },
  profileTabText: { color: colors.ink, fontSize: 11, fontWeight: "800", marginTop: 6, maxWidth: 84 },
  profileTabTextActive: { color: colors.paper },
  tabAvatar: { width: 38, height: 38, borderRadius: 12 },
  tabAvatarFallback: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  tabInitial: { color: colors.mintDark, fontSize: 16, fontWeight: "900" },
  profileCard: { backgroundColor: colors.paper, borderRadius: 20, padding: 18, flexDirection: "row", alignItems: "center", gap: 14, borderWidth: 1, borderColor: colors.line, ...shadow },
  avatarWrap: { width: 68, height: 68 },
  avatar: { width: 68, height: 68, borderRadius: 20 },
  avatarFallback: { width: 68, height: 68, borderRadius: 20, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  avatarInitial: { color: colors.mintDark, fontSize: 27, fontWeight: "900" },
  camera: { position: "absolute", right: -4, bottom: -4, width: 24, height: 24, borderRadius: 12, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: colors.paper },
  cardTitle: { color: colors.ink, fontSize: 15, fontWeight: "900" },
  profileMeta: { color: colors.muted, fontSize: 12, marginTop: 5 },
  reputationCard: { backgroundColor: colors.paper, borderRadius: 20, padding: 17, marginTop: 14, borderWidth: 1, borderColor: colors.line },
  ratingLine: { minHeight: 44, flexDirection: "row", alignItems: "center", gap: 8, borderTopWidth: 1, borderTopColor: colors.line },
  ratingLabel: { width: 118, color: colors.muted, fontSize: 11, fontWeight: "700" },
  ratingValue: { flex: 1, color: colors.ink, fontSize: 12, fontWeight: "800" },
  completed: { color: colors.muted, fontSize: 10 },
  iconButton: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  portfolio: { minHeight: 82, alignItems: "center", gap: 9, paddingTop: 5 },
  portfolioImage: { width: 92, height: 76, borderRadius: 13, backgroundColor: colors.cream },
  memberRow: { flexDirection: "row", alignItems: "center", gap: 10, minHeight: 48, borderTopWidth: 1, borderTopColor: colors.line },
  memberName: { color: colors.ink, fontSize: 13, fontWeight: "800" },
  inviteActions: { flexDirection: "row", alignItems: "center", gap: 7, marginTop: 9 },
  error: { color: colors.accentDark, fontSize: 12, fontWeight: "800", textAlign: "center", marginTop: 16, lineHeight: 18 },
});
