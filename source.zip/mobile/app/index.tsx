import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { ActivityIndicator, Image, Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "@/src/AuthContext";
import { useMode } from "@/src/ModeContext";
import { colors } from "@/src/theme";
import appIcon from "../assets/icon.png";

export default function IntentEntryScreen() {
  const { status, provider } = useAuth();
  const { setActiveMode } = useMode();
  if (status === "loading") {
    return <View style={styles.loading}><ActivityIndicator color={colors.accent} size="large" /></View>;
  }

  function solveSomething() {
    setActiveMode("client");
    router.push("/new-request");
  }

  function earnMoney() {
    setActiveMode("professional");
    if (status === "signedOut") {
      router.push({ pathname: "/sign-in", params: { returnTo: "/work-profile" } });
      return;
    }
    router.push(provider?.professionalEnabled ? "/(tabs)/requests" : "/work-profile");
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.shell}>
        <View style={styles.brandRow}>
          <Image source={appIcon} style={styles.logo} />
          <Text style={styles.brand}>Rezolvat<Text style={styles.brandAccent}>Azi</Text></Text>
        </View>

        <View style={styles.intro}>
          <Text style={styles.eyebrow}>{provider ? `Bun venit, ${provider.name}` : "O SINGURĂ APLICAȚIE"}</Text>
          <Text style={styles.title}>Ce vrei să faci acum?</Text>
          <Text style={styles.subtitle}>Nu trebuie să alegi un rol. Poți folosi oricând ambele variante.</Text>
        </View>

        <View style={styles.actions}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Vreau să rezolv o problemă"
            onPress={solveSomething}
            style={({ pressed }) => [styles.intentCard, styles.solveCard, pressed && styles.pressed]}
          >
            <View style={styles.iconShell}><MaterialCommunityIcons name="lightning-bolt-outline" size={29} color="#8E2E24" /></View>
            <View style={styles.intentCopy}>
              <Text style={styles.intentKicker}>AM NEVOIE DE AJUTOR</Text>
              <Text style={styles.intentTitle}>Vreau să rezolv ceva</Text>
              <Text style={styles.intentText}>Descriu problema, iar aplicația mă conduce către soluția potrivită.</Text>
            </View>
            <MaterialCommunityIcons name="arrow-right" size={24} color="#8E2E24" />
          </Pressable>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Vreau să câștig bani"
            onPress={earnMoney}
            style={({ pressed }) => [styles.intentCard, styles.earnCard, pressed && styles.pressed]}
          >
            <View style={[styles.iconShell, styles.earnIcon]}><MaterialCommunityIcons name="briefcase-outline" size={28} color="#174E7A" /></View>
            <View style={styles.intentCopy}>
              <Text style={[styles.intentKicker, styles.earnKicker]}>POT FACE LUCRĂRI</Text>
              <Text style={[styles.intentTitle, styles.earnTitle]}>Vreau să câștig bani</Text>
              <Text style={[styles.intentText, styles.earnText]}>Aleg ce știu să fac, timpul disponibil și profilul cu care lucrez.</Text>
            </View>
            <MaterialCommunityIcons name="arrow-right" size={24} color="#174E7A" />
          </Pressable>
        </View>

        <View style={styles.promise}>
          <MaterialCommunityIcons name="account-switch-outline" size={20} color={colors.mintDark} />
          <Text style={styles.promiseText}>Astăzi poți cere ajutor. Peste o oră poți câștiga bani. Contul rămâne același.</Text>
        </View>

        {status === "signedOut" ? (
          <Pressable onPress={() => router.push("/sign-in")} style={styles.secondaryAction}>
            <Text style={styles.secondaryText}>Ai deja activitate? Intră în cont</Text>
          </Pressable>
        ) : (
          <Pressable onPress={() => router.push("/(tabs)/activity")} style={styles.secondaryAction}>
            <Text style={styles.secondaryText}>Vezi activitatea mea</Text>
            <MaterialCommunityIcons name="chevron-right" size={19} color={colors.ink} />
          </Pressable>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.cream },
  shell: { flex: 1, width: "100%", maxWidth: 560, alignSelf: "center", paddingHorizontal: 20, paddingTop: 10, paddingBottom: 18 },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  logo: { width: 40, height: 40, borderRadius: 13 },
  brand: { color: colors.ink, fontSize: 18, fontWeight: "900" },
  brandAccent: { color: colors.accent },
  intro: { marginTop: 44, marginBottom: 25 },
  eyebrow: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  title: { color: colors.ink, fontSize: 34, lineHeight: 40, fontWeight: "900", letterSpacing: -1.1, marginTop: 8 },
  subtitle: { color: colors.muted, fontSize: 14, lineHeight: 21, marginTop: 8, maxWidth: 430 },
  actions: { gap: 13 },
  intentCard: { minHeight: 164, borderRadius: 24, padding: 18, flexDirection: "row", alignItems: "center", gap: 13, borderWidth: 1 },
  solveCard: { backgroundColor: "#FDEAE6", borderColor: "#F3BDB4" },
  earnCard: { backgroundColor: "#E7F2FC", borderColor: "#B8D5ED" },
  iconShell: { width: 51, height: 51, borderRadius: 17, backgroundColor: "rgba(255,255,255,0.72)", alignItems: "center", justifyContent: "center" },
  earnIcon: { backgroundColor: "rgba(255,255,255,0.78)" },
  intentCopy: { flex: 1 },
  intentKicker: { color: "#9A463A", fontSize: 8, fontWeight: "900", letterSpacing: 0.9 },
  earnKicker: { color: "#356D98" },
  intentTitle: { color: "#70291F", fontSize: 20, lineHeight: 25, fontWeight: "900", marginTop: 5 },
  earnTitle: { color: "#153F61" },
  intentText: { color: "#744E48", fontSize: 11, lineHeight: 16, marginTop: 6 },
  earnText: { color: "#49677E" },
  pressed: { opacity: 0.74, transform: [{ scale: 0.99 }] },
  promise: { marginTop: 21, backgroundColor: colors.paper, borderRadius: 15, borderWidth: 1, borderColor: colors.line, padding: 13, flexDirection: "row", alignItems: "center", gap: 10 },
  promiseText: { flex: 1, color: colors.muted, fontSize: 11, lineHeight: 16 },
  secondaryAction: { minHeight: 48, marginTop: "auto", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4 },
  secondaryText: { color: colors.ink, fontSize: 12, fontWeight: "800" },
});
