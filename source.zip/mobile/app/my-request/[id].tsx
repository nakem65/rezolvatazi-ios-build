import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useLocalSearchParams } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Image, KeyboardAvoidingView, Modal, Platform, Pressable, RefreshControl, ScrollView, Share, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { acceptOffer, cancelRequest, createRequestShare, fetchMyRequest, rateRequest, republishRequest, reportProvider, revokeRequestShare, updateOpenRequest, updateRequestStatus } from "@/src/api";
import { colors, shadow } from "@/src/theme";
import { MyRequestDetail } from "@/src/types";

import { showAppAlert } from "@/src/alerts";
import { pickImageFromGallery } from "@/src/mediaPicker";
import { workOrderDetailChips } from "@/src/workOrderDetails";
import { pricingPresentation } from "@/src/pricing";
import { openExternalUrl } from "@/src/externalLink";

const statusCopy: Record<string, [string, string]> = {
  open: ["Cererea este activă", "Răspunsurile apar aici automat."],
  matched: ["Ai ales persoana", "Acum vă puteți contacta direct."],
  completed: ["Cerere finalizată", "Mulțumim că ai folosit RezolvatAzi."],
  cancelled: ["Cerere anulată", "Nu mai primește răspunsuri."],
  expired: ["Cererea a expirat", "Poți publica din nou dacă mai ai nevoie de ajutor."],
  cancelled_after_match: ["Colaborare anulată", "Cererea a fost închisă după alegerea persoanei."],
  no_show: ["Persoana nu s-a prezentat", "Situația a fost înregistrată."],
  disputed: ["Problemă raportată", "Nu continua dacă nu te simți în siguranță."],
};
const editableUrgencies = ["Acum", "Astăzi", "În 24 de ore"] as const;

const solutionCopy = {
  quotes: "OFERTE",
  hourly: "TARIF ORAR",
  team: "ECHIPĂ",
  recurring: "RECURENT",
  assessment: "CONSTATARE",
} as const;

function WaitingForOffers({ refreshing, onRefresh }: { refreshing: boolean; onRefresh: () => void }) {
  return (
    <View style={styles.waiting} accessibilityRole="summary" accessibilityLabel="Cererea este activă. Ofertele vor apărea aici.">
      <View style={styles.waitingSignal}>
        <MaterialCommunityIcons name="access-point" size={22} color={colors.accent} />
      </View>
      <View style={styles.waitingCopy}>
        <Text style={styles.waitingTitle}>Cererea este activă</Text>
        <Text style={styles.waitingText}>Ofertele apar aici imediat ce răspunde cineva. Te anunțăm și prin notificare.</Text>
      </View>
      <Pressable accessibilityRole="button" accessibilityLabel="Actualizează ofertele" disabled={refreshing} onPress={onRefresh} style={styles.waitingRefresh}>
        {refreshing ? <ActivityIndicator size="small" color={colors.paper} /> : <MaterialCommunityIcons name="refresh" size={19} color={colors.paper} />}
      </Pressable>
    </View>
  );
}

export default function MyRequestDetailScreen() {
  const { id, chatOfferId, published } = useLocalSearchParams<{ id: string; chatOfferId?: string; published?: string }>();
  const [detail, setDetail] = useState<MyRequestDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [sortBy, setSortBy] = useState<"eta" | "price">("eta");
  const openedDeepLinkedChat = useRef(false);
  const [score, setScore] = useState(5);
  const [comment, setComment] = useState("");
  const [mediaUrls, setMediaUrls] = useState<string[]>([]);
  const [previewPhotoUrl, setPreviewPhotoUrl] = useState<string | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [editDescription, setEditDescription] = useState("");
  const [editUrgency, setEditUrgency] = useState("Astăzi");
  const [editLocation, setEditLocation] = useState("");
  const [editBudget, setEditBudget] = useState("");

  const refresh = useCallback(async (quiet = false) => {
    if (!id) return;
    if (!quiet) setLoading(true);
    try { setDetail(await fetchMyRequest(id)); setError(""); }
    catch (caught) { setError(caught instanceof Error ? caught.message : "Cererea nu a putut fi încărcată."); }
    finally { if (!quiet) setLoading(false); }
  }, [id]);

  // Initial loading and the polling subscription intentionally start together.
  useEffect(() => { void refresh(); const timer = setInterval(() => void refresh(true), 10_000); return () => clearInterval(timer); }, [refresh]);
  useEffect(() => {
    if (!chatOfferId || !detail || openedDeepLinkedChat.current) return;
    const offer = detail.offers.find((item) => item.id === chatOfferId);
    if (!offer) return;
    openedDeepLinkedChat.current = true;
    router.replace({ pathname: "/chat", params: { requestId: detail.request.id, offerId: offer.id, role: "client", title: `Discuție cu ${offer.providerName}`, preAcceptance: offer.selected ? "0" : "1" } } as never);
  }, [chatOfferId, detail]);

  function choose(offerId: string, name: string) {
    const isHobby = detail?.request.requestMode === "hobby";
    const isTeam = detail?.workOrder?.solutionKind === "team";
    const multiple = isHobby || isTeam;
    const title = multiple ? "Adaugi această persoană?" : "Alegi această ofertă?";
    const msg = multiple ? `${name} va fi adăugat în echipă și în conversația lucrării.` : `Se va deschide Chat-ul direct și datele tale de contact vor fi trimise către ${name}.`;
    
    showAppAlert(title, msg, [
      { text: "Nu acum", style: "cancel" },
      { text: multiple ? "Adaugă în echipă" : "Alege & deschide Chat", onPress: async () => { setBusy(true); try { await acceptOffer(id, offerId); await refresh(true); const offer = detail?.offers.find((item) => item.id === offerId); router.push({ pathname: "/chat", params: { requestId: id, offerId: multiple ? "" : offerId, role: detail?.request.requestMode === "hobby" ? "hobby" : "client", title: multiple ? "Discuția lucrării" : `Discuție cu ${offer?.providerName ?? name}`, preAcceptance: "0" } } as never); } catch (caught) { setError(caught instanceof Error ? caught.message : "Răspunsul nu a putut fi ales."); } finally { setBusy(false); } } },
    ]);
  }

  function openRequestEdit() {
    if (!detail) return;
    setEditDescription(detail.request.description);
    setEditUrgency(detail.request.urgency);
    setEditLocation(detail.request.locationLabel ?? detail.request.city);
    setEditBudget(detail.workOrder?.budgetBani ? String(Math.round(detail.workOrder.budgetBani / 100)) : "");
    setError("");
    setEditOpen(true);
  }

  async function saveRequestEdit() {
    if (!detail || !id) return;
    setBusy(true);
    setError("");
    try {
      await updateOpenRequest(id, {
        description: editDescription.trim(),
        urgency: editUrgency,
        city: detail.request.city,
        locationLabel: editLocation.trim(),
        clientPrice: editBudget.trim() ? Number(editBudget) : null,
      });
      setEditOpen(false);
      await refresh(true);
      showAppAlert("Cererea a fost actualizată", "Prestatorii văd acum noile detalii.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Cererea nu a putut fi actualizată.");
    } finally {
      setBusy(false);
    }
  }

  function cancel() {
    showAppAlert("Anulezi cererea?", "Nu va mai primi răspunsuri.", [
      { text: "Păstrează", style: "cancel" },
      { text: "Anulează", style: "destructive", onPress: async () => { setBusy(true); try { await cancelRequest(id); await refresh(true); } catch (caught) { setError(caught instanceof Error ? caught.message : "Cererea nu a putut fi anulată."); } finally { setBusy(false); } } },
    ]);
  }

  function republish() {
    showAppAlert("Publici din nou cererea?", "Creăm o cerere nouă cu aceleași detalii și fotografii. Ofertele, conversațiile și persoanele din cererea veche nu sunt copiate.", [
      { text: "Nu acum", style: "cancel" },
      {
        text: "Publică din nou",
        onPress: async () => {
          setBusy(true); setError("");
          try {
            const result = await republishRequest(id);
            router.replace({ pathname: "/my-request/[id]", params: { id: result.request.id } });
          } catch (caught) {
            setError(caught instanceof Error ? caught.message : "Cererea nu a putut fi publicată din nou.");
          } finally { setBusy(false); }
        },
      },
    ]);
  }

  async function shareRequest() {
    if (!id) return;
    setBusy(true); setError("");
    try {
      const result = await createRequestShare(id);
      await Share.share({ title: "Cerere nouă pe RezolvatAzi", message: result.share.text });
      await refresh(true);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Linkul de distribuire nu a putut fi pregătit.");
    } finally { setBusy(false); }
  }

  function confirmShare() {
    showAppAlert("Distribui această cerere?", "Se trimit doar categoria, zona aproximativă, intervalul și eventualul buget. Numele, telefonul, adresa exactă, pozele și conversațiile nu sunt distribuite.", [
      { text: "Nu acum", style: "cancel" },
      { text: "Distribuie", onPress: () => void shareRequest() },
    ]);
  }

  function revokeShare() {
    showAppAlert("Oprești distribuirea?", "Linkul trimis anterior nu va mai afișa cererea. Postările deja publicate trebuie șterse de tine din canalul în care le-ai pus.", [
      { text: "Păstrează", style: "cancel" },
      { text: "Oprește linkul", style: "destructive", onPress: async () => { setBusy(true); try { await revokeRequestShare(id); await refresh(true); } catch (caught) { setError(caught instanceof Error ? caught.message : "Linkul nu a putut fi oprit."); } finally { setBusy(false); } } },
    ]);
  }

  async function rate(providerId?: string) {
    if (!id || score < 1 || score > 5) return;
    setBusy(true); setError("");
    try {
      await rateRequest(id, score, comment.trim(), mediaUrls, providerId);
      setScore(5);
      setComment("");
      setMediaUrls([]);
      await refresh(true);
    }
    catch (caught) { setError(caught instanceof Error ? caught.message : "Evaluarea nu a putut fi trimisă."); }
    finally { setBusy(false); }
  }

  function complete() {
    const recurring = detail?.workOrder?.solutionKind === "recurring";
    showAppAlert(
      recurring ? "Închei colaborarea recurentă?" : "S-a încheiat ajutorul?",
      recurring ? "Prestatorul nu va mai rămâne rezervat pentru următoarele vizite. Vei putea lăsa apoi o evaluare." : "Confirmă doar după ce lucrarea sau ajutorul s-a terminat.",
      [
      { text: "Nu încă", style: "cancel" },
      { text: recurring ? "Încheie colaborarea" : "Da, este finalizat", onPress: async () => { setBusy(true); try { await updateRequestStatus(id, "complete"); await refresh(true); } catch (caught) { setError(caught instanceof Error ? caught.message : "Finalizarea nu a putut fi salvată."); } finally { setBusy(false); } } },
    ]);
  }

  function completeRecurringCycle() {
    showAppAlert("Confirmi vizita?", "Confirmă numai după ce lucrarea din acest ciclu a fost efectuată.", [
      { text: "Nu încă", style: "cancel" },
      { text: "Confirmă vizita", onPress: async () => { setBusy(true); try { await updateRequestStatus(id, "complete_cycle"); await refresh(true); } catch (caught) { setError(caught instanceof Error ? caught.message : "Vizita nu a putut fi confirmată."); } finally { setBusy(false); } } },
    ]);
  }

  function problem(targetProviderId?: string) {
    const isHobby = detail?.request.requestMode === "hobby";
    if (isHobby) {
      showAppAlert("Raportezi persoana lipsă?", "Alegi să raportezi anonim lipsa acestui participant? Acesta va primi un minus la profil.", [
        { text: "Închide", style: "cancel" },
        { text: "Raportează participant lipsă", style: "destructive", onPress: async () => { setBusy(true); try { await updateRequestStatus(id, "no_show", targetProviderId); await refresh(true); } catch (caught) { setError(caught instanceof Error ? caught.message : "Situația nu a putut fi salvată."); } finally { setBusy(false); } } },
      ]);
    } else {
      showAppAlert("Ce s-a întâmplat?", "Dacă există pericol imediat, îndepărtează-te și sună la 112.", [
        { text: "Închide", style: "cancel" },
        { text: "Nu s-a prezentat", onPress: async () => { setBusy(true); try { await updateRequestStatus(id, "no_show", targetProviderId); await refresh(true); } catch (caught) { setError(caught instanceof Error ? caught.message : "Situația nu a putut fi salvată."); } finally { setBusy(false); } } },
        { text: "Mă simt în nesiguranță", style: "destructive", onPress: async () => { setBusy(true); try { await updateRequestStatus(id, "dispute", targetProviderId); await refresh(true); } catch (caught) { setError(caught instanceof Error ? caught.message : "Raportarea nu a putut fi salvată."); } finally { setBusy(false); } } },
      ]);
    }
  }

  function reportOffer(providerId: string, name: string) {
    showAppAlert("Raportezi și blochezi?", `Oferta lui ${name} va fi trimisă pentru verificare și nu vei mai primi răspunsuri de la acest cont.`, [
      { text: "Renunță", style: "cancel" },
      { text: "Raportează", style: "destructive", onPress: async () => { setBusy(true); try { await reportProvider(id, providerId); await refresh(true); } catch (caught) { setError(caught instanceof Error ? caught.message : "Raportarea nu a putut fi trimisă."); } finally { setBusy(false); } } },
    ]);
  }

  if (loading && !detail) return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color={colors.accent} /></SafeAreaView>;
  if (!detail) return <SafeAreaView style={styles.center}><MaterialCommunityIcons name="alert-circle-outline" size={38} color={colors.accent} /><Text style={styles.centerText}>{error || "Cererea nu este disponibilă."}</Text><Pressable onPress={() => void refresh()}><Text style={styles.retry}>Reîncearcă</Text></Pressable></SafeAreaView>;

  const request = detail.request;
  let [statusTitle, statusText] = statusCopy[request.status] ?? statusCopy.open;
  const selected = detail.offers.find((offer) => offer.selected);
  const neighbor = request.requestMode === "neighbor";
  const workOrder = detail.workOrder;
  const isTeam = workOrder?.solutionKind === "team";
  const isRecurring = workOrder?.solutionKind === "recurring";
  const recurringAgreement = detail.recurringAgreement;
  const acceptedIds = request.acceptedParticipantIds ?? [];
  const acceptedSlots = request.acceptedParticipantCount ?? detail.offers
    .filter((offer) => acceptedIds.includes(offer.providerId))
    .reduce((total, offer) => total + (offer.includedParticipants ?? 1), 0);
  const remainingTeamSlots = isTeam ? Math.max(0, (workOrder?.requiredParticipants ?? 1) - acceptedSlots) : 0;
  if (isTeam && request.status === "open" && acceptedIds.length > 0) {
    statusTitle = "Echipa este în formare";
    statusText = remainingTeamSlots === 1 ? "Mai trebuie aleasă o persoană." : `Mai trebuie alese ${remainingTeamSlots} persoane.`;
  }
  if (isRecurring && request.status === "matched") {
    statusTitle = "Colaborare recurentă activă";
    statusText = `${workOrder?.recurrenceLabel ?? "Periodic"} · confirmi fiecare vizită în aplicație.`;
  }
  const detailChips = workOrderDetailChips(workOrder?.structuredDetailsJson);
  const isExpired = request.status === "expired";
  const isActive = request.status === "open";
  const statusStyle = isActive ? styles.statusActive : isExpired ? styles.statusExpired : styles.statusDone;
  const statusIcon = isActive ? "access-point" : isExpired ? "clock-alert-outline" : request.status === "cancelled" ? "close" : "check-bold";
  const statusIconColor = isActive ? colors.mintDark : isExpired ? "#A84E00" : request.status === "cancelled" ? colors.accentDark : colors.mintDark;
  return (
    <SafeAreaView style={styles.safe} edges={["bottom"]}>
      <Modal visible={Boolean(previewPhotoUrl)} transparent animationType="fade" onRequestClose={() => setPreviewPhotoUrl(null)}>
        <Pressable accessibilityRole="button" accessibilityLabel="Închide previzualizarea fotografiei" onPress={() => setPreviewPhotoUrl(null)} style={styles.photoModalBackdrop}>
          <View style={styles.photoModalCard}>
            {previewPhotoUrl ? <Image source={{ uri: previewPhotoUrl }} resizeMode="contain" style={styles.photoModalImage} /> : null}
            <Text style={styles.photoModalHint}>Atinge pentru a închide</Text>
          </View>
        </Pressable>
      </Modal>
      <ScrollView contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={loading} onRefresh={() => void refresh()} tintColor={colors.accent} />}>
        {published === "1" ? <View style={styles.publishedBanner} accessibilityRole="alert" accessibilityLabel="Cererea ta a fost publicată"><View style={styles.publishedIcon}><MaterialCommunityIcons name="check" size={20} color={colors.paper} /></View><View style={styles.publishedCopy}><Text style={styles.publishedTitle}>Cererea ta este publicată</Text><Text style={styles.publishedText}>Ofertele și răspunsurile apar aici. Îți trimitem notificare când primești unul.</Text></View></View> : null}
        <View style={[styles.status, statusStyle]}><View style={styles.statusIcon}><MaterialCommunityIcons name={statusIcon} size={21} color={statusIconColor} /></View><View style={styles.statusCopy}><Text style={styles.statusTitle}>{statusTitle}</Text><Text style={styles.statusText}>{statusText}</Text></View></View>
        {isActive ? <Pressable accessibilityRole="button" accessibilityLabel="Modifică cererea" disabled={busy} onPress={openRequestEdit} style={styles.editRequestButton}><View style={styles.editRequestIcon}><MaterialCommunityIcons name="pencil-outline" size={18} color={colors.mintDark} /></View><View style={styles.editRequestCopy}><Text style={styles.editRequestText}>Modifică cererea</Text><Text style={styles.editRequestHint}>Text, moment, zonă sau buget</Text></View><MaterialCommunityIcons name="chevron-right" size={20} color={colors.muted} /></Pressable> : null}
        <View style={styles.request}>
          <View style={styles.badges}>
            <Text style={[styles.modeBadge, neighbor && styles.neighborBadge]}>{workOrder ? solutionCopy[workOrder.solutionKind] : neighbor ? "AJUTOR GRATUIT" : "PRESTATOR"}</Text>
            <Text style={styles.categoryBadge}>{request.category}</Text>
          </View>
          <Text style={styles.description}>{request.description}</Text>
          {workOrder ? (
            <View style={styles.intentDetails}>
              {workOrder.requiredParticipants > 1 ? <Text style={styles.intentDetail}>{workOrder.requiredParticipants} PERSOANE</Text> : null}
              {workOrder.recurrenceLabel ? <Text style={styles.intentDetail}>{workOrder.recurrenceLabel.toLocaleUpperCase("ro-RO")}</Text> : null}
              {workOrder.budgetBani ? <Text style={styles.intentDetail}>BUGET {(workOrder.budgetBani / 100).toLocaleString("ro-RO")} LEI</Text> : null}
              {workOrder.riskClass === "regulated" ? <Text style={styles.intentDetail}>PROFESIONIST VERIFICAT</Text> : null}
              {detailChips.map((detail) => <Text key={detail} style={styles.intentDetail}>{detail.toLocaleUpperCase("ro-RO")}</Text>)}
            </View>
          ) : null}
          {request.photos && request.photos.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, marginTop: 10 }}>
              {request.photos.map((url, i) => (
                <Pressable key={i} accessibilityRole="button" accessibilityLabel={`Vezi fotografia ${i + 1} mărită`} onPress={() => setPreviewPhotoUrl(url)}>
                  <Image source={{ uri: url }} style={styles.requestPhoto} />
                </Pressable>
              ))}
            </ScrollView>
          ) : null}
          <Text style={styles.meta}>{request.city} · {request.urgency}</Text>
        </View>

        {isExpired ? <View style={styles.republishCard}>
          <View style={styles.republishCopy}><Text style={styles.republishTitle}>Mai ai nevoie de ajutor?</Text><Text style={styles.republishText}>Folosești aceeași cerere ca model. Ofertele și conversațiile vechi rămân separate.</Text></View>
          <Pressable accessibilityRole="button" accessibilityLabel="Publică cererea din nou" disabled={busy} onPress={republish} style={styles.republishButton}><MaterialCommunityIcons name="content-copy" size={18} color={colors.paper} /><Text style={styles.republishButtonText}>Publică din nou</Text></Pressable>
        </View> : null}

        {request.status === "open" && request.requestMode === "professional" ? (
          <View style={styles.shareCard}>
            <View style={styles.shareCopy}><Text style={styles.shareTitle}>{request.shareActive ? "Distribuirea este activă" : "Caută mai repede persoane disponibile"}</Text><Text style={styles.shareText}>{request.shareActive ? "Poți opri oricând linkul. Mesajele deja publicate trebuie șterse din canalul în care le-ai pus." : "Distribuie tu cererea pe un canal ales. Nu includem telefonul, adresa exactă, pozele sau conversațiile."}</Text></View>
            <Pressable disabled={busy} onPress={request.shareActive ? revokeShare : confirmShare} style={[styles.shareButton, request.shareActive && styles.shareStopButton]}><MaterialCommunityIcons name={request.shareActive ? "link-off" : "share-variant-outline"} size={18} color={request.shareActive ? colors.accentDark : colors.paper} /><Text style={[styles.shareButtonText, request.shareActive && styles.shareStopButtonText]}>{request.shareActive ? "Oprește linkul" : "Distribuie"}</Text></Pressable>
          </View>
        ) : null}

        {selected || neighbor || acceptedIds.length > 0 ? <Pressable accessibilityRole="button" accessibilityLabel="Deschide conversația lucrării" onPress={() => router.push({ pathname: "/chat", params: { requestId: request.id, offerId: !isTeam && selected ? selected.id : "", role: request.requestMode === "hobby" ? "hobby" : "client", title: "Discuția lucrării", preAcceptance: "0" } } as never)} style={styles.preOfferChatButton}><MaterialCommunityIcons name="chat-processing-outline" size={17} color={colors.mintDark} /><Text style={styles.preOfferChatText}>Deschide conversația</Text><MaterialCommunityIcons name="chevron-right" size={18} color={colors.mintDark} /></Pressable> : null}

        <Modal visible={editOpen} transparent animationType="slide" onRequestClose={() => setEditOpen(false)}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.editOverlay}>
            <View style={styles.editSheet}>
              <View style={styles.editHeader}><View><Text style={styles.editKicker}>CERERE ACTIVĂ</Text><Text style={styles.editTitle}>Corectează detaliile</Text></View><Pressable accessibilityLabel="Închide editarea" onPress={() => setEditOpen(false)} hitSlop={10}><MaterialCommunityIcons name="close" size={24} color={colors.ink} /></Pressable></View>
              <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.editScroll}>
                <Text style={styles.editLabel}>Ce ai nevoie?</Text><TextInput value={editDescription} onChangeText={setEditDescription} multiline maxLength={1600} textAlignVertical="top" style={styles.editDescription} />
                <Text style={styles.editLabel}>Când ai nevoie?</Text><View style={styles.editUrgencies}>{editableUrgencies.map((item) => <Pressable key={item} accessibilityRole="radio" accessibilityState={{ checked: editUrgency === item }} onPress={() => setEditUrgency(item)} style={[styles.editUrgency, editUrgency === item && styles.editUrgencyActive]}><Text style={[styles.editUrgencyText, editUrgency === item && styles.editUrgencyTextActive]}>{item}</Text></Pressable>)}</View>
                <Text style={styles.editLabel}>Zonă sau adresă</Text><TextInput value={editLocation} onChangeText={setEditLocation} maxLength={250} placeholder="Adresă, cartier, sat sau reper" placeholderTextColor="#667269" style={styles.editInput} />
                <Text style={styles.editLabel}>Buget orientativ, opțional</Text><TextInput value={editBudget} onChangeText={(value) => setEditBudget(value.replace(/\D/g, "").slice(0, 6))} keyboardType="number-pad" placeholder="Ex: 300" placeholderTextColor="#667269" style={styles.editInput} />
                {error ? <Text style={styles.editError}>{error}</Text> : null}
                <Pressable accessibilityRole="button" disabled={busy} onPress={() => void saveRequestEdit()} style={[styles.editSaveButton, busy && styles.disabled]}><Text style={styles.editSaveText}>{busy ? "Se salvează..." : "Salvează modificările"}</Text></Pressable>
              </ScrollView>
            </View>
          </KeyboardAvoidingView>
        </Modal>

        <View style={styles.section}><Text style={styles.sectionTitle}>{isTeam ? (request.status === "open" ? "Alege persoanele din echipă" : "Echipa aleasă") : request.status === "open" ? "Răspunsuri primite" : (request.requestMode === "hobby" ? "Persoane alese" : "Persoana aleasă")}</Text><Text style={styles.count}>{isTeam ? `${acceptedSlots}/${workOrder?.requiredParticipants ?? 1}` : detail.offers.length}</Text></View>
        {request.status === "open" && !neighbor && request.requestMode !== "hobby" && detail.offers.length > 1 ? (
          <View style={styles.sortRow}>
            <Text style={styles.sortLabel}>Sortează după:</Text>
            <Pressable onPress={() => setSortBy("eta")} style={[styles.sortButton, sortBy === "eta" && styles.sortButtonActive]}><Text style={[styles.sortButtonText, sortBy === "eta" && styles.sortButtonTextActive]}>Timp sosire</Text></Pressable>
            <Pressable onPress={() => setSortBy("price")} style={[styles.sortButton, sortBy === "price" && styles.sortButtonActive]}><Text style={[styles.sortButtonText, sortBy === "price" && styles.sortButtonTextActive]}>Preț estimat</Text></Pressable>
          </View>
        ) : null}
        {request.status === "open" && !detail.offers.length ? <WaitingForOffers refreshing={loading} onRefresh={() => void refresh()} /> : null}
        {[...detail.offers].sort((a, b) => sortBy === "eta" ? a.etaMinutes - b.etaMinutes : (a.pricing?.estimatedTotalBani ?? a.price * 100) - (b.pricing?.estimatedTotalBani ?? b.price * 100)).filter((offer) => request.status === "open" || offer.selected || (request.acceptedParticipantIds && request.acceptedParticipantIds.includes(offer.providerId))).map((offer) => {
          const isAccepted = offer.selected || (request.acceptedParticipantIds && request.acceptedParticipantIds.includes(offer.providerId));
          const pricing = pricingPresentation(offer.pricing);
          return (
          <View style={[styles.offer, isAccepted && styles.offerSelected]} key={offer.id}>
            <View style={styles.providerRow}><View style={styles.avatar}><Text style={styles.avatarText}>{offer.providerName.charAt(0).toUpperCase()}</Text></View><View style={styles.providerCopy}><Text style={styles.providerName}>{offer.providerName}</Text><Text style={styles.trust}>✓ {offer.providerTrustLabel}</Text><Pressable onPress={() => router.push({ pathname: "/reviews", params: { providerId: offer.providerId, profileId: offer.earningProfileId ?? undefined } })}><Text style={[styles.rating, { color: colors.accent }]}>★ {offer.providerRating ? (offer.providerRating / 10).toFixed(1).replace(".", ",") : "Nou"} · {offer.providerReviewCount} recenzii pentru acest profil</Text></Pressable></View><View><Text style={styles.price}>{neighbor || request.requestMode === "hobby" ? "Gratuit" : pricing?.headline ?? `${offer.price} lei`}</Text><Text style={styles.eta}>{offer.etaMinutes} min</Text></View></View>
            {!neighbor && request.requestMode !== "hobby" ? <><Text style={styles.priceFormula}>{pricing?.formula ?? (offer.priceType === "fixed" ? "Preț fix pentru lucrare" : "Estimare pentru lucrare")}</Text><View style={styles.offerTerms}>{pricing?.details.slice(0, 4).map((detailItem) => <Text key={detailItem} style={styles.offerTerm}>{detailItem.toLocaleUpperCase("ro-RO")}</Text>)}</View></> : null}
            {offer.revision > 1 ? <Text style={styles.offerRevision}>Versiunea {offer.revision} · oferta a fost actualizată</Text> : null}
            {offer.message ? <Text style={styles.message}>{offer.message}</Text> : null}
            {!isAccepted && request.status === "open" && !neighbor && request.requestMode !== "hobby" ? <Pressable accessibilityRole="button" onPress={() => router.push({ pathname: "/chat", params: { requestId: request.id, offerId: offer.id, role: "client", title: `Discuție cu ${offer.providerName}`, preAcceptance: "1" } } as never)} style={styles.preOfferChatButton}><MaterialCommunityIcons name="chat-question-outline" size={17} color={colors.mintDark} /><Text style={styles.preOfferChatText}>Întreabă prestatorul înainte să alegi</Text><MaterialCommunityIcons name="chevron-right" size={18} color={colors.mintDark} /></Pressable> : null}
            {!isAccepted ? <Pressable disabled={busy} onPress={() => reportOffer(offer.providerId, offer.providerName)} style={styles.reportOffer}><MaterialCommunityIcons name="flag-outline" size={15} color={colors.muted} /><Text style={styles.reportOfferText}>Raportează și blochează</Text></Pressable> : null}
            {!isAccepted ? (
              <View style={styles.chooseWrap}>
                <Pressable disabled={busy || (isTeam && (offer.includedParticipants ?? 1) > remainingTeamSlots)} onPress={() => choose(offer.id, offer.providerName)} style={styles.choose}>
                  <Text style={styles.chooseText}>{isTeam ? (offer.includedParticipants ?? 1) > remainingTeamSlots ? "Oferta depășește locurile rămase" : `Adaugă ${offer.includedParticipants ?? 1} ${(offer.includedParticipants ?? 1) === 1 ? "persoană" : "persoane"}` : request.requestMode === "hobby" ? "Alege persoana" : neighbor ? "Alege persoana & deschide Chat" : "Alege oferta & deschide Chat"}</Text>
                  <MaterialCommunityIcons name="arrow-right" size={19} color={colors.paper} />
                </Pressable>
                <Text style={styles.chooseHint}>💬 {isTeam ? `Poți alege separat până la ${workOrder?.requiredParticipants ?? 1} persoane.` : request.requestMode === "hobby" ? "Persoana va fi inclusă în conversația de grup." : "Se deschide Chat-ul instant pentru poze, detalii și numărul de telefon."}</Text>
              </View>
            ) : null}
            {isAccepted && offer.providerPhone ? <Pressable onPress={() => void openExternalUrl(`tel:${offer.providerPhone}`, "Apelul nu poate fi inițiat pe acest dispozitiv.")} style={styles.call}><MaterialCommunityIcons name="phone" size={20} color={colors.paper} /><View><Text style={styles.callLabel}>SUNĂ PERSOANA</Text><Text style={styles.callPhone}>{offer.providerPhone}</Text></View></Pressable> : null}
            {isAccepted && (request.requestMode === "hobby" || isTeam) ? <Pressable onPress={() => problem(offer.providerId)} style={styles.problem}><MaterialCommunityIcons name="account-cancel-outline" size={18} color={colors.accentDark} /><Text style={styles.problemText}>Raportează persoana lipsă</Text></Pressable> : null}
          </View>
        )})}

        {request.status === "matched" && isRecurring ? (
          <View style={styles.recurringCard}>
            <View style={styles.recurringHeader}>
              <View style={styles.summaryIcon}><MaterialCommunityIcons name="calendar-sync-outline" size={23} color={colors.mintDark} /></View>
              <View style={styles.finishCopy}>
                <Text style={styles.finishTitle}>{workOrder?.recurrenceLabel ?? "Colaborare periodică"}</Text>
                <Text style={styles.finishText}>{recurringAgreement?.completedCycles ?? 0} vizite confirmate{recurringAgreement?.nextDueAt ? ` · următoarea estimată ${new Date(recurringAgreement.nextDueAt).toLocaleDateString("ro-RO", { day: "numeric", month: "short" })}` : ""}</Text>
              </View>
            </View>
            <Pressable disabled={busy} onPress={completeRecurringCycle} style={styles.recurringPrimary}><Text style={styles.recurringPrimaryText}>Confirmă vizita efectuată</Text><MaterialCommunityIcons name="check" size={19} color={colors.paper} /></Pressable>
            <Pressable disabled={busy} onPress={complete} style={styles.recurringEnd}><Text style={styles.recurringEndText}>Încheie colaborarea</Text></Pressable>
          </View>
        ) : (request.status === "matched" || (request.requestMode === "hobby" && acceptedIds.length > 0)) ? <View style={styles.finishCard}><MaterialCommunityIcons name="clipboard-check-outline" size={25} color={colors.mintDark} /><View style={styles.finishCopy}><Text style={styles.finishTitle}>După ce terminați</Text><Text style={styles.finishText}>Confirmarea finalizării este separată de rating.</Text></View><Pressable disabled={busy} onPress={complete} style={styles.finishButton}><Text style={styles.finishButtonText}>Finalizează</Text></Pressable></View> : null}
        {request.status === "matched" && selected && request.requestMode !== "hobby" && !isTeam ? <Pressable disabled={busy} onPress={() => problem()} style={styles.problem}><MaterialCommunityIcons name="shield-alert-outline" size={18} color={colors.accentDark} /><Text style={styles.problemText}>Nu s-a prezentat sau mă simt în nesiguranță</Text></Pressable> : null}
        {request.status === "completed" && selected && !detail.rating && request.requestMode !== "hobby" ? <View style={styles.ratingCard}><Text style={styles.ratingTitle}>Cum a fost experiența?</Text><Text style={styles.ratingSubtitle}>Evaluarea se adaugă profilului lui {selected.providerName}.</Text><View style={styles.stars}>{[1, 2, 3, 4, 5].map((value) => <Pressable key={value} onPress={() => setScore(value)}><MaterialCommunityIcons name={value <= score ? "star" : "star-outline"} size={33} color="#E4A515" /></Pressable>)}</View><TextInput value={comment} onChangeText={setComment} maxLength={500} multiline placeholder="Comentariu opțional" placeholderTextColor="#99A19A" style={styles.comment} /><Text style={styles.charCount}>{comment.length}/500</Text>
          {mediaUrls.length > 0 && (
            <View style={{ flexDirection: "row", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
              {mediaUrls.map((url, idx) => (
                <View key={idx}>
                  {url.endsWith(".mp4") || url.includes("video") ? (
                    <View style={{ width: 50, height: 50, borderRadius: 8, backgroundColor: "#E5E7E2", alignItems: "center", justifyContent: "center" }}><MaterialCommunityIcons name="video" size={24} color={colors.muted} /></View>
                  ) : (
                    <Image source={{ uri: url }} style={{ width: 50, height: 50, borderRadius: 8 }} />
                  )}
                  <Pressable hitSlop={10} onPress={() => setMediaUrls(prev => prev.filter((_, i) => i !== idx))} style={{ position: "absolute", top: -5, right: -5, backgroundColor: colors.paper, borderRadius: 10, borderWidth: 1, borderColor: colors.line }}>
                    <MaterialCommunityIcons name="close" size={12} color={colors.accentDark} />
                  </Pressable>
                </View>
              ))}
            </View>
          )}
          <View style={styles.mediaRow}>
            <Pressable onPress={async () => { if (mediaUrls.length >= 5) { showAppAlert("Limită", "Puteți adăuga maxim 5 fișiere."); return; } const url = await pickImageFromGallery(); if (url) setMediaUrls(prev => [...prev, url]); }} style={styles.mediaBtn}><MaterialCommunityIcons name="camera" size={16} color={colors.muted} /><Text style={styles.mediaBtnText}>Poză</Text></Pressable>
          </View>
          <Pressable disabled={busy} onPress={() => void rate()} style={styles.rate}><Text style={styles.rateText}>{busy ? "Se trimite..." : "Trimite evaluarea"}</Text></Pressable></View> : null}
        {request.status === "completed" && isTeam ? detail.offers
          .filter((offer) => acceptedIds.includes(offer.providerId))
          .map((offer) => {
            const submitted = detail.ratings?.find((rating) => rating.providerId === offer.providerId);
            return submitted ? (
              <View key={offer.providerId} style={styles.thanks}><MaterialCommunityIcons name="check-decagram" size={24} color={colors.mintDark} /><Text style={styles.thanksText}>{offer.providerName} · {"★".repeat(submitted.score)}</Text></View>
            ) : (
              <View key={offer.providerId} style={styles.ratingCard}>
                <Text style={styles.ratingTitle}>Cum a lucrat {offer.providerName}?</Text>
                <Text style={styles.ratingSubtitle}>Fiecare membru al echipei primește ratingul său profesional.</Text>
                <View style={styles.stars}>{[1, 2, 3, 4, 5].map((value) => <Pressable key={value} onPress={() => setScore(value)}><MaterialCommunityIcons name={value <= score ? "star" : "star-outline"} size={33} color="#E4A515" /></Pressable>)}</View>
                <TextInput value={comment} onChangeText={setComment} maxLength={500} multiline placeholder="Comentariu opțional" placeholderTextColor="#99A19A" style={styles.comment} />
                <Pressable disabled={busy} onPress={() => void rate(offer.providerId)} style={styles.rate}><Text style={styles.rateText}>{busy ? "Se trimite..." : `Evaluează pe ${offer.providerName}`}</Text></Pressable>
              </View>
            );
          }) : null}
        {detail.rating && !isTeam ? <View style={styles.thanks}><MaterialCommunityIcons name="check-decagram" size={24} color={colors.mintDark} /><Text style={styles.thanksText}>Mulțumim pentru evaluare · {"★".repeat(detail.rating.score)}</Text></View> : null}
        {request.status === "open" ? <Pressable disabled={busy} onPress={cancel} style={styles.cancel}><Text style={styles.cancelText}>Anulează cererea</Text></Pressable> : null}
        {error ? <Text style={styles.error}>{error}</Text> : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  offerRevision: { color: colors.accentDark, fontSize: 11, fontWeight: "800", marginTop: 8 },
  safe: { flex: 1, backgroundColor: colors.cream }, center: { flex: 1, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center", padding: 30 }, centerText: { color: colors.accentDark, textAlign: "center", marginTop: 12 }, retry: { color: colors.accent, fontWeight: "900", marginTop: 14 }, content: { padding: 18, paddingBottom: 38 },
  status: { borderRadius: 16, padding: 13, flexDirection: "row", alignItems: "center", marginBottom: 13 }, statusActive: { backgroundColor: "#E5F4EA" }, statusExpired: { backgroundColor: "#FFF1E5" }, statusDone: { backgroundColor: colors.mint }, statusIcon: { width: 40, height: 40, borderRadius: 12, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center" }, statusCopy: { flex: 1, marginLeft: 10 }, statusTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" }, statusText: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  request: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 15, marginBottom: 24, ...shadow }, badges: { flexDirection: "row", gap: 6 }, modeBadge: { color: colors.accentDark, backgroundColor: colors.dangerSoft, borderRadius: 99, paddingHorizontal: 9, paddingVertical: 6, fontSize: 11, fontWeight: "900" }, neighborBadge: { color: colors.mintDark, backgroundColor: colors.mint }, categoryBadge: { color: colors.muted, backgroundColor: "#ECEEEA", borderRadius: 99, paddingHorizontal: 9, paddingVertical: 6, fontSize: 11, fontWeight: "800" }, description: { color: colors.text, fontSize: 14, lineHeight: 21, marginTop: 12 }, requestPhoto: { width: 110, height: 85, borderRadius: 10, backgroundColor: "#EAECE9" }, photoModalBackdrop: { flex: 1, backgroundColor: "rgba(13, 24, 19, 0.88)", padding: 20, alignItems: "center", justifyContent: "center" }, photoModalCard: { width: "100%", maxWidth: 560, alignItems: "center" }, photoModalImage: { width: "100%", height: "78%", maxHeight: 700, borderRadius: 14, backgroundColor: colors.ink }, photoModalHint: { color: colors.paper, fontSize: 12, fontWeight: "700", marginTop: 13 }, meta: { color: colors.muted, fontSize: 12, lineHeight: 17, borderTopWidth: 1, borderTopColor: colors.line, paddingTop: 10, marginTop: 12 },
  republishCard: { backgroundColor: "#FFF8F1", borderWidth: 1, borderColor: "#F2D2B4", borderRadius: 16, padding: 14, marginTop: -12, marginBottom: 18, gap: 11 }, republishCopy: { gap: 4 }, republishTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" }, republishText: { color: "#7E562D", fontSize: 12, lineHeight: 17 }, republishButton: { minHeight: 46, borderRadius: 11, backgroundColor: "#A84E00", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 }, republishButtonText: { color: colors.paper, fontSize: 12, fontWeight: "900" },
  shareCard: { backgroundColor: colors.mint, borderRadius: 16, padding: 14, marginTop: -12, marginBottom: 18, gap: 11 }, shareCopy: { gap: 4 }, shareTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" }, shareText: { color: colors.mintDark, fontSize: 12, lineHeight: 17 }, shareButton: { minHeight: 46, borderRadius: 11, backgroundColor: colors.ink, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 }, shareButtonText: { color: colors.paper, fontSize: 12, fontWeight: "900" }, shareStopButton: { backgroundColor: colors.paper, borderWidth: 1, borderColor: "#EDB4A9" }, shareStopButtonText: { color: colors.accentDark },
  intentDetails: { flexDirection: "row", flexWrap: "wrap", gap: 5, marginTop: 10 },
  intentDetail: { color: colors.mintDark, backgroundColor: colors.mint, borderRadius: 99, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 5, fontSize: 11, fontWeight: "900" },
  section: { flexDirection: "row", alignItems: "center", marginBottom: 11 }, sectionTitle: { color: colors.ink, fontSize: 18, fontWeight: "900" }, count: { marginLeft: 7, color: colors.muted, backgroundColor: "#E5E7E2", borderRadius: 99, paddingHorizontal: 8, paddingVertical: 3, fontSize: 11, fontWeight: "900" }, waiting: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 17, padding: 16 }, waitingSignal: { width: 46, height: 46, borderRadius: 23, alignItems: "center", justifyContent: "center", backgroundColor: "#FCE6E1" }, waitingCopy: { flex: 1 }, waitingTitle: { color: colors.ink, fontSize: 15, lineHeight: 20, fontWeight: "900" }, waitingText: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 3 }, waitingRefresh: { width: 44, height: 44, borderRadius: 13, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
  sortRow: { flexDirection: "row", alignItems: "center", marginBottom: 15, gap: 8 }, sortLabel: { color: colors.muted, fontSize: 12, fontWeight: "700" }, sortButton: { backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, borderRadius: 99, paddingHorizontal: 11, paddingVertical: 7 }, sortButtonActive: { backgroundColor: colors.ink, borderColor: colors.ink }, sortButtonText: { color: colors.muted, fontSize: 12, fontWeight: "800" }, sortButtonTextActive: { color: colors.paper },
  offer: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 15, marginBottom: 11, ...shadow }, offerSelected: { borderColor: colors.mintDark, borderWidth: 2 }, providerRow: { flexDirection: "row", alignItems: "center" }, avatar: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center" }, avatarText: { color: colors.paper, fontSize: 17, fontWeight: "900" }, providerCopy: { flex: 1, marginLeft: 10 }, providerName: { color: colors.ink, fontSize: 14, fontWeight: "900" }, trust: { color: colors.mintDark, fontSize: 11, fontWeight: "800", marginTop: 2 }, rating: { color: colors.muted, fontSize: 12, marginTop: 2 }, price: { color: colors.ink, fontSize: 16, fontWeight: "900", textAlign: "right" }, eta: { color: colors.accent, fontSize: 11, fontWeight: "800", textAlign: "right", marginTop: 3 }, offerTerms: { flexDirection: "row", flexWrap: "wrap", gap: 5, marginTop: 11 }, offerTerm: { color: colors.mintDark, backgroundColor: colors.mint, borderRadius: 99, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 5, fontSize: 11, fontWeight: "900" }, message: { color: colors.text, fontSize: 13, lineHeight: 19, backgroundColor: colors.cream, borderRadius: 10, padding: 11, marginTop: 9 }, reportOffer: { minHeight: 38, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, marginTop: 5 }, reportOfferText: { color: colors.muted, fontSize: 11, fontWeight: "700" }, chooseWrap: { marginTop: 5 }, chooseHint: { color: colors.muted, fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: 5, fontWeight: "600" }, choose: { minHeight: 50, backgroundColor: colors.accent, borderRadius: 12, paddingHorizontal: 14, marginTop: 7, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, chooseText: { color: colors.paper, fontSize: 13, fontWeight: "900" }, call: { minHeight: 58, backgroundColor: colors.ink, borderRadius: 13, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", gap: 10, marginTop: 12 }, callLabel: { color: "#93A89A", fontSize: 11, fontWeight: "900" }, callPhone: { color: colors.paper, fontSize: 14, fontWeight: "900", marginTop: 3 },
  ratingCard: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 18, padding: 17, marginTop: 11 }, ratingTitle: { color: colors.ink, textAlign: "center", fontSize: 16, fontWeight: "900" }, ratingSubtitle: { color: colors.muted, textAlign: "center", fontSize: 12, lineHeight: 17, marginTop: 4 }, stars: { flexDirection: "row", justifyContent: "center", gap: 4, marginVertical: 14 }, comment: { minHeight: 74, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, borderRadius: 11, padding: 10, textAlignVertical: "top", color: colors.text, fontSize: 14, lineHeight: 20 }, charCount: { color: colors.muted, fontSize: 11, textAlign: "right", marginTop: 4 }, mediaRow: { flexDirection: "row", gap: 8, marginTop: 10 }, mediaBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, paddingVertical: 10, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, borderRadius: 11 }, mediaBtnText: { color: colors.muted, fontSize: 11, fontWeight: "800" }, rate: { minHeight: 48, backgroundColor: colors.ink, borderRadius: 11, alignItems: "center", justifyContent: "center", marginTop: 10 }, rateText: { color: colors.paper, fontSize: 12, fontWeight: "900" }, thanks: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.mint, borderRadius: 14, padding: 13, marginTop: 11 }, thanksText: { color: colors.mintDark, fontSize: 12, fontWeight: "800" }, cancel: { height: 48, alignItems: "center", justifyContent: "center", marginTop: 14 }, cancelText: { color: colors.accentDark, fontSize: 12, fontWeight: "800", textDecorationLine: "underline" }, error: { color: colors.accentDark, textAlign: "center", fontSize: 12, lineHeight: 17, marginTop: 10 },
  finishCard: { backgroundColor: colors.mint, borderRadius: 16, padding: 13, marginTop: 11, flexDirection: "row", alignItems: "center", gap: 10 }, finishCopy: { flex: 1 }, finishTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" }, finishText: { color: colors.mintDark, fontSize: 12, lineHeight: 17, marginTop: 3 }, finishButton: { backgroundColor: colors.ink, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 11 }, finishButtonText: { color: colors.paper, fontSize: 12, fontWeight: "900" }, problem: { minHeight: 46, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 5 }, problemText: { color: colors.accentDark, fontSize: 12, fontWeight: "800" },
  priceFormula: { color: colors.text, fontSize: 12, lineHeight: 18, fontWeight: "700", marginTop: 11 },
  preOfferChatButton: { minHeight: 44, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, borderWidth: 1, borderColor: "#BFD7C7", backgroundColor: colors.mint, borderRadius: 11, marginTop: 9, paddingHorizontal: 10 },
  preOfferChatText: { color: colors.mintDark, fontSize: 12, fontWeight: "900", textAlign: "center" },
  publishedBanner: { flexDirection: "row", gap: 11, alignItems: "flex-start", backgroundColor: colors.mintDark, borderRadius: 17, padding: 15, marginBottom: 12, ...shadow }, publishedIcon: { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: colors.accent }, publishedCopy: { flex: 1 }, publishedTitle: { color: colors.paper, fontSize: 15, fontWeight: "900" }, publishedText: { color: "#E0F0E5", fontSize: 12, lineHeight: 17, marginTop: 3 },
  editRequestButton: { minHeight: 64, flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: "#EAF5EE", borderWidth: 1, borderColor: "#BEDAC8", borderRadius: 16, paddingHorizontal: 13, marginBottom: 12 }, editRequestIcon: { width: 36, height: 36, borderRadius: 11, alignItems: "center", justifyContent: "center", backgroundColor: colors.paper }, editRequestCopy: { flex: 1 }, editRequestText: { color: colors.ink, fontSize: 14, fontWeight: "900" }, editRequestHint: { color: colors.mintDark, fontSize: 12, marginTop: 2 },
  editOverlay: { flex: 1, backgroundColor: "rgba(21,32,25,.42)", justifyContent: "flex-end" }, editSheet: { maxHeight: "90%", backgroundColor: colors.paper, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 18 }, editHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 20, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: colors.line }, editKicker: { color: colors.mintDark, fontSize: 11, fontWeight: "900", letterSpacing: 0.7 }, editTitle: { color: colors.ink, fontSize: 20, fontWeight: "900", marginTop: 2 }, editScroll: { padding: 20, paddingBottom: 32 }, editLabel: { color: colors.ink, fontSize: 13, fontWeight: "900", marginTop: 12, marginBottom: 7 }, editDescription: { minHeight: 112, borderWidth: 1, borderColor: colors.line, borderRadius: 13, padding: 12, color: colors.ink, fontSize: 14, lineHeight: 20 }, editUrgencies: { flexDirection: "row", gap: 7 }, editUrgency: { flex: 1, minHeight: 44, alignItems: "center", justifyContent: "center", backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, borderRadius: 11, paddingHorizontal: 5 }, editUrgencyActive: { backgroundColor: colors.ink, borderColor: colors.ink }, editUrgencyText: { color: colors.muted, fontSize: 11, fontWeight: "900", textAlign: "center" }, editUrgencyTextActive: { color: colors.paper }, editInput: { minHeight: 48, borderWidth: 1, borderColor: colors.line, borderRadius: 12, paddingHorizontal: 12, color: colors.ink, fontSize: 14 }, editError: { color: colors.accentDark, fontSize: 12, fontWeight: "800", marginTop: 10 }, editSaveButton: { minHeight: 52, backgroundColor: colors.accent, borderRadius: 14, alignItems: "center", justifyContent: "center", marginTop: 22 }, editSaveText: { color: colors.paper, fontSize: 14, fontWeight: "900" }, disabled: { opacity: 0.55 },
  recurringCard: { backgroundColor: colors.mint, borderRadius: 18, padding: 15, marginTop: 11, gap: 11 },
  recurringHeader: { flexDirection: "row", alignItems: "center", gap: 11 },
  summaryIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center" },
  recurringPrimary: { minHeight: 46, backgroundColor: colors.ink, borderRadius: 12, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  recurringPrimaryText: { color: colors.paper, fontSize: 12, fontWeight: "900" },
  recurringEnd: { alignItems: "center", paddingVertical: 7 },
  recurringEndText: { color: colors.muted, fontSize: 12, fontWeight: "800" },
});
