import { useEffect, useRef, useState } from "react";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "@/src/AuthContext";
import { colors } from "@/src/theme";
import { CityAutocompleteInput } from "@/components/CityAutocompleteInput";
import type { PlaceSelection } from "@/src/googlePlaces";
import { isValidRomanianLocation } from "@/src/cities";
import { resolveTypedRomanianLocation } from "@/src/location";

export default function OnboardingScreen() {
  const { completeOnboarding, provider } = useAuth();
  const placeholderAccount = provider?.name === "Prestator nou" || provider?.name === "Utilizator nou";
  const [name, setName] = useState(placeholderAccount ? "" : provider?.clientName ?? provider?.name ?? "");
  const [city, setCity] = useState(provider?.city ?? "București");
  const [coordinates, setCoordinates] = useState<{ latitude: number; longitude: number } | null>(
    typeof provider?.latitude === "number" && typeof provider?.longitude === "number"
      ? { latitude: provider.latitude, longitude: provider.longitude }
      : null,
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const populated = useRef(Boolean(provider));

  useEffect(() => {
    if (!provider || populated.current) return;
    setName(provider.name === "Prestator nou" || provider.name === "Utilizator nou" ? "" : provider.clientName ?? provider.name);
    setCity(provider.city);
    populated.current = true;
  }, [provider]);

  async function submit() {
    if (name.trim().length < 2 || name.trim().length > 50) return setError("Te rugăm să introduci un nume valid (2-50 caractere).");
    if (!isValidRomanianLocation(city)) return setError("Scrie localitatea, sectorul sau zona în care vei folosi aplicația.");
    setBusy(true); setError("");
    try {
      const resolved = coordinates ? null : await resolveTypedRomanianLocation(city);
      const finalCoordinates = coordinates ?? (resolved && resolved.latitude !== null && resolved.longitude !== null
        ? { latitude: resolved.latitude, longitude: resolved.longitude }
        : null);
      const finalArea = resolved?.areaLabel || city.trim();
      if (!finalCoordinates) throw new Error("Nu am putut identifica zona. Alege o sugestie din listă.");
      await completeOnboarding({
        name: name.trim(),
        clientName: name.trim(),
        city: finalArea,
        latitude: finalCoordinates.latitude,
        longitude: finalCoordinates.longitude,
        categories: provider?.categories ?? [],
        radiusKm: provider?.radiusKm ?? 18,
        helperEnabled: false,
        professionalEnabled: provider?.professionalEnabled ?? false,
        hobbyEnabled: false,
      });
      router.replace("/");
    }
    catch (caught) { setError(caught instanceof Error ? caught.message : "Profilul nu a putut fi salvat."); }
    finally { setBusy(false); }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.step}><Text style={styles.stepText}>CONFIGURARE RAPIDĂ</Text><Text style={styles.stepNumber}>1 din 1</Text></View>
          <Text style={styles.title}>Ca să găsim oameni aproape de tine</Text>
          <Text style={styles.subtitle}>Avem nevoie doar de prenume și zona de bază. Poate fi un oraș, sector, comună sau cartier.</Text>
          <Text style={styles.label}>Cum îți spunem?</Text>
          <TextInput value={name} onChangeText={setName} placeholder="Prenumele tău" placeholderTextColor="#99A19A" style={styles.input} maxLength={50} />
          <Text style={styles.label}>Care este zona ta de bază?</Text>
          <CityAutocompleteInput
            value={city}
            onChangeText={(value) => { setCity(value); setCoordinates(null); }}
            onSelectPlace={(place: PlaceSelection) => {
              setCity(place.areaLabel);
              setCoordinates(place.latitude !== null && place.longitude !== null
                ? { latitude: place.latitude, longitude: place.longitude }
                : null);
            }}
            purpose="area"
            placeholder="Oraș, sector, comună sau cartier"
          />
          <View style={styles.privacy}><MaterialCommunityIcons name="shield-check-outline" size={18} color={colors.mintDark} /><Text style={styles.privacyText}>Poți configura mai târziu un profil separat dacă vrei să primești lucrări.</Text></View>
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <Pressable disabled={busy} onPress={() => void submit()} style={({ pressed }) => [styles.primary, (pressed || busy) && styles.pressed]}><Text style={styles.primaryText}>{busy ? "Se salvează..." : "Continuă"}</Text><MaterialCommunityIcons name="arrow-right" size={20} color={colors.paper} /></Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream }, flex: { flex: 1 }, content: { width: "100%", maxWidth: 520, alignSelf: "center", padding: 24, paddingBottom: 40 },
  step: { flexDirection: "row", justifyContent: "space-between", marginTop: 5 }, stepText: { color: colors.accent, fontSize: 9, fontWeight: "900", letterSpacing: 1 }, stepNumber: { color: colors.muted, fontSize: 10, fontWeight: "800" },
  title: { color: colors.ink, fontSize: 30, lineHeight: 37, fontWeight: "900", letterSpacing: -1, marginTop: 24 }, subtitle: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 9, marginBottom: 30 },
  label: { color: colors.ink, fontSize: 14, fontWeight: "800", marginBottom: 9, marginTop: 18 }, input: { height: 58, borderWidth: 1, borderColor: colors.line, borderRadius: 15, paddingHorizontal: 16, color: colors.ink, backgroundColor: colors.paper, fontSize: 16 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, chip: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 999, paddingHorizontal: 11, paddingVertical: 9 }, chipActive: { backgroundColor: colors.ink, borderColor: colors.ink }, chipText: { color: colors.ink, fontSize: 10, fontWeight: "700" }, chipTextActive: { color: colors.paper },
  roles: { gap: 8, marginTop: 17 }, role: { minHeight: 62, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 15, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", gap: 11 }, roleFixed: { backgroundColor: colors.mint, borderColor: "#B9DDC3" }, roleActive: { borderColor: colors.mintDark, backgroundColor: "#F1FAF3" }, roleCopy: { flex: 1 }, roleTitle: { color: colors.ink, fontSize: 12, fontWeight: "900" }, roleText: { color: colors.muted, fontSize: 9, marginTop: 3 },
  professionalSetup: { marginTop: 5 },
  fieldHint: { color: colors.muted, fontSize: 9, lineHeight: 14, marginTop: -3, marginBottom: 10 },
  selectionCount: { color: colors.muted, fontSize: 9, textAlign: "right", marginTop: 7 },
  radius: { flexDirection: "row", gap: 7 }, radiusOption: { flex: 1, alignItems: "center", paddingVertical: 12, borderRadius: 11, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.paper }, radiusActive: { backgroundColor: colors.ink, borderColor: colors.ink }, radiusText: { color: colors.muted, fontSize: 10, fontWeight: "800" }, radiusTextActive: { color: colors.paper },
  privacy: { marginTop: 24, padding: 14, backgroundColor: colors.mint, borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 10 },
  privacyText: { flex: 1, color: colors.mintDark, fontSize: 12, lineHeight: 18 },
  error: { color: colors.accentDark, backgroundColor: colors.dangerSoft, borderRadius: 10, padding: 12, fontSize: 12, fontWeight: "700", marginTop: 14 }, primary: { height: 58, backgroundColor: colors.accent, borderRadius: 15, marginTop: 28, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, pressed: { opacity: 0.75 }, primaryText: { color: colors.paper, fontSize: 15, fontWeight: "900" },
});
