import { useLocalSearchParams } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { Alert, Dimensions, Image, Modal, NativeScrollEvent, NativeSyntheticEvent, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { fetchAccountProfileReviews, fetchProviderReviews, replyToReview } from "@/src/api";
import { useAuth } from "@/src/AuthContext";
import { pickImageFromGallery } from "@/src/mediaPicker";
import { colors } from "@/src/theme";
import { Review } from "@/src/types";
import { openExternalUrl } from "@/src/externalLink";

export default function ReviewsScreen() {
  const { providerId, profileId, accountProfileId, role } = useLocalSearchParams<{ providerId?: string; profileId?: string; accountProfileId?: string; role?: "client" | "provider" }>();
  const { provider } = useAuth();
  
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [attachedPhoto, setAttachedPhoto] = useState<string | null>(null);
  const [previewGallery, setPreviewGallery] = useState<{ urls: string[], initialIndex: number } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function pickReviewPhoto() {
    const url = await pickImageFromGallery();
    if (url) {
      setAttachedPhoto(url);
    }
  }

  const loadReviews = async () => {
    setLoading(true);
    try {
      const data = accountProfileId
        ? await fetchAccountProfileReviews(accountProfileId, role === "client" ? "client" : "provider")
        : await fetchProviderReviews(providerId || provider?.id || "me", profileId);
      setReviews(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let active = true;
    void (accountProfileId
      ? fetchAccountProfileReviews(accountProfileId, role === "client" ? "client" : "provider")
      : fetchProviderReviews(providerId || provider?.id || "me", profileId))
      .then((data) => {
        if (active) setReviews(data);
      })
      .catch((error) => {
        if (active) console.error(error);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => { active = false; };
  }, [provider?.id, providerId, profileId, accountProfileId, role]);

  const submitReply = async (reviewId: string) => {
    if (isSubmitting || (!replyText.trim() && !attachedPhoto)) return;
    setIsSubmitting(true);
    try {
      await replyToReview(reviewId, replyText, attachedPhoto ?? undefined);
      setReviews(prev => prev.map(r => r.id === reviewId ? { ...r, replyText, replyPhotoUrl: attachedPhoto ?? undefined, repliedAt: new Date().toISOString() } : r));
      setReplyingTo(null);
      setReplyText("");
      setAttachedPhoto(null);
    } catch {
      Alert.alert("Eroare", "A apărut o eroare la trimiterea răspunsului. Încearcă din nou.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const isMyProfile = Boolean(accountProfileId) || !providerId || providerId === provider?.id;

  return (
    <SafeAreaView style={styles.safe} edges={["bottom", "left", "right"]}>

      <Modal visible={previewGallery !== null} transparent animationType="fade" onRequestClose={() => setPreviewGallery(null)}>
        <Pressable style={styles.modalOverlay} onPress={() => setPreviewGallery(null)}>
          <Pressable style={styles.modalCloseBtn} onPress={() => setPreviewGallery(null)}>
            <MaterialCommunityIcons name="close" size={26} color={colors.paper} />
          </Pressable>
          {previewGallery && (
            <GallerySwiper urls={previewGallery.urls || []} initialIndex={previewGallery.initialIndex} />
          )}
        </Pressable>
      </Modal>

      <ScrollView 
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={loadReviews} tintColor={colors.accent} />}
      >
        {reviews.map(review => (
          <View key={review.id} style={styles.reviewCard}>
            <View style={styles.reviewHeader}>
              <View style={styles.reviewerAvatar}>
                <Text style={styles.reviewerAvatarText}>{review.reviewerName.charAt(0).toUpperCase()}</Text>
              </View>
              <View style={styles.reviewerInfo}>
                <Text style={styles.reviewerName}>{review.reviewerName}</Text>
                <Text style={styles.reviewDate}>{new Date(review.createdAt).toLocaleDateString("ro-RO")}</Text>
              </View>
              <View style={styles.scoreBadge}>
                <MaterialCommunityIcons name="star" size={16} color={colors.accent} />
                <Text style={styles.scoreText}>{review.score.toFixed(1)}</Text>
              </View>
            </View>
            
            <Text style={styles.comment}>{review.comment}</Text>
            {review.category ? <Text style={styles.category}>{review.category} · evaluare după lucrare finalizată</Text> : null}
            
            {(review.mediaUrls || []).length > 0 && (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 10 }}>
                {(review.mediaUrls || []).map((url, index) => {
                  const isVideo = url.endsWith(".mp4") || url.includes("video");
                  return (
                    <Pressable key={index} onPress={() => setPreviewGallery({ urls: review.mediaUrls || [], initialIndex: index })} style={{ marginRight: 10 }}>
                      {isVideo ? (
                        <View style={[styles.media, { backgroundColor: "#000", alignItems: "center", justifyContent: "center" }]}>
                          <MaterialCommunityIcons name="play-circle" size={40} color={colors.paper} />
                        </View>
                      ) : (
                        <Image source={{ uri: url }} style={[styles.media, { marginTop: 0 }]} resizeMode="cover" />
                      )}
                    </Pressable>
                  );
                })}
              </ScrollView>
            )}

            {review.replyText ? (
              <View style={styles.replyBox}>
                <Text style={styles.replyName}>{review.targetName} (Răspuns)</Text>
                <Text style={styles.replyContent}>{review.replyText}</Text>
                {review.replyPhotoUrl && (
                  <Pressable onPress={() => setPreviewGallery({ urls: [review.replyPhotoUrl!], initialIndex: 0 })}>
                    <Image source={{ uri: review.replyPhotoUrl }} style={styles.mediaReply} resizeMode="cover" />
                    <Text style={styles.zoomHint}>🔍 Atinge pentru a mări poza</Text>
                  </Pressable>
                )}
                {review.replyVideoUrl && (
                  <Pressable onPress={() => setPreviewGallery({ urls: [review.replyVideoUrl!], initialIndex: 0 })} style={styles.videoCard}>
                    <MaterialCommunityIcons name="play-circle" size={44} color={colors.paper} />
                    <Text style={styles.videoHint}>🎥 Clip video (Răspuns) · Atinge pentru a vizualiza</Text>
                  </Pressable>
                )}
              </View>
            ) : isMyProfile ? (
              replyingTo === review.id ? (
                <View style={styles.replyEditor}>
                  <TextInput
                    style={styles.replyInput}
                    placeholder="Scrie un răspuns public..."
                    value={replyText}
                    onChangeText={setReplyText}
                    multiline
                    maxLength={500}
                  />
                  {attachedPhoto ? (
                    <View style={styles.attachedPreview}>
                      <Image source={{ uri: attachedPhoto }} style={styles.attachedImage} />
                      <Pressable onPress={() => setAttachedPhoto(null)}><MaterialCommunityIcons name="close-circle" size={20} color={colors.accentDark} /></Pressable>
                    </View>
                  ) : null}
                  <View style={styles.replyActions}>
                    <View style={styles.mediaButtons}>
                      <Pressable onPress={pickReviewPhoto} style={styles.photoIconBtn}><MaterialCommunityIcons name="camera-outline" size={22} color={colors.ink} /></Pressable>
                    </View>
                    <View style={styles.replyButtonsRight}>
                      <Pressable onPress={() => { setReplyingTo(null); setReplyText(""); setAttachedPhoto(null); }} style={styles.cancelBtn}>
                        <Text style={styles.cancelBtnText}>Anulează</Text>
                      </Pressable>
                      <Pressable onPress={() => void submitReply(review.id)} style={styles.submitBtn}>
                        <Text style={styles.submitBtnText}>Trimite răspunsul</Text>
                      </Pressable>
                    </View>
                  </View>
                </View>
              ) : (
                <Pressable 
                    onPress={() => {
                      setReplyingTo(review.id);
                      setReplyText("");
                      setAttachedPhoto(null);
                    }} style={styles.startReplyBtn}>
                  <MaterialCommunityIcons name="reply" size={16} color={colors.muted} />
                  <Text style={styles.startReplyText}>Răspunde</Text>
                </Pressable>
              )
            ) : null}
          </View>
        ))}
        {!loading && reviews.length === 0 && (
          <Text style={styles.empty}>Nu există recenzii deocamdată.</Text>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.paper },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 10, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: colors.line },
  backBtn: { padding: 8 },
  headerTitle: { fontSize: 18, fontWeight: "800", color: colors.ink },
  content: { padding: 20, gap: 20 },
  reviewCard: { backgroundColor: "#fff", padding: 16, borderRadius: 16, borderWidth: 1, borderColor: colors.line, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 6, elevation: 2 },
  reviewHeader: { flexDirection: "row", alignItems: "center", marginBottom: 12 },
  reviewerAvatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center", marginRight: 12 },
  reviewerAvatarText: { color: colors.mintDark, fontWeight: "900", fontSize: 18 },
  reviewerInfo: { flex: 1 },
  reviewerName: { fontSize: 15, fontWeight: "700", color: colors.ink },
  reviewDate: { fontSize: 12, color: colors.muted, marginTop: 2 },
  scoreBadge: { flexDirection: "row", alignItems: "center", backgroundColor: colors.paper, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, borderWidth: 1, borderColor: colors.line },
  scoreText: { marginLeft: 4, fontSize: 14, fontWeight: "800", color: colors.ink },
  comment: { fontSize: 15, color: colors.ink, lineHeight: 22, marginBottom: 12 },
  category: { alignSelf: "flex-start", color: colors.mintDark, backgroundColor: colors.mint, borderRadius: 99, overflow: "hidden", paddingHorizontal: 9, paddingVertical: 5, fontSize: 10, fontWeight: "800", marginBottom: 10 },
  media: { width: 140, height: 140, borderRadius: 12, marginBottom: 12 },
  replyBox: { backgroundColor: "#F2F4F2", padding: 12, borderRadius: 12, borderLeftWidth: 4, borderLeftColor: colors.accent },
  replyName: { fontSize: 13, fontWeight: "800", color: colors.ink, marginBottom: 4 },
  replyContent: { fontSize: 14, color: colors.ink, lineHeight: 20 },
  mediaReply: { width: "100%", height: 120, borderRadius: 8, marginTop: 8 },
  startReplyBtn: { flexDirection: "row", alignItems: "center", alignSelf: "flex-start", gap: 6, paddingVertical: 6, paddingHorizontal: 12, borderRadius: 12, backgroundColor: "#F2F4F2" },
  startReplyText: { fontSize: 13, fontWeight: "700", color: colors.muted },
  replyEditor: { marginTop: 8 },
  replyInput: { backgroundColor: "#F2F4F2", borderRadius: 12, padding: 12, minHeight: 80, fontSize: 14, color: colors.ink },
  replyActions: { flexDirection: "row", justifyContent: "flex-end", gap: 12, marginTop: 12 },
  cancelBtn: { paddingVertical: 8, paddingHorizontal: 16 },
  cancelBtnText: { color: colors.muted, fontWeight: "700", fontSize: 14 },
  submitBtn: { backgroundColor: colors.accent, paddingVertical: 8, paddingHorizontal: 16, borderRadius: 12 },
  submitBtnText: { color: colors.paper, fontWeight: "800", fontSize: 14 },
  empty: { textAlign: "center", color: colors.muted, marginTop: 40, fontSize: 16 },
  videoCard: { backgroundColor: "#000", height: 180, borderRadius: 12, marginBottom: 12, alignItems: "center", justifyContent: "center" },
  videoHint: { color: colors.paper, fontSize: 12, marginTop: 8 },
  zoomHint: { color: colors.muted, fontSize: 11, textAlign: "center", marginTop: 4, marginBottom: 12 },
  attachedPreview: { flexDirection: "row", alignItems: "center", backgroundColor: colors.paper, padding: 8, borderRadius: 12, borderWidth: 1, borderColor: colors.line, marginTop: 8, gap: 10 },
  attachedImage: { width: 40, height: 40, borderRadius: 8 },
  attachedText: { flex: 1, color: colors.muted, fontSize: 12 },
  mediaButtons: { flexDirection: "row", gap: 12 },
  photoIconBtn: { padding: 8, backgroundColor: "#EAECE9", borderRadius: 99 },
  replyButtonsRight: { flexDirection: "row", gap: 12 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.9)", justifyContent: "center", alignItems: "center" },
  modalCloseBtn: { position: "absolute", top: 40, right: 20, zIndex: 10, padding: 10 },
  fullImage: { width: "100%", height: "80%" },
  videoModalContent: { alignItems: "center", justifyContent: "center", padding: 20 },
  videoModalTitle: { color: colors.paper, fontSize: 20, fontWeight: "800", marginTop: 16 },
  videoModalText: { color: colors.paper, fontSize: 14, textAlign: "center", marginTop: 8, opacity: 0.8 }
});

function GallerySwiper({ urls, initialIndex }: { urls: string[], initialIndex: number }) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const scrollRef = useRef<ScrollView>(null);
  
  useEffect(() => {
    setTimeout(() => {
      scrollRef.current?.scrollTo({ x: initialIndex * Dimensions.get("window").width, animated: false });
    }, 50);
  }, [initialIndex]);

  function handleScroll(event: NativeSyntheticEvent<NativeScrollEvent>) {
    const x = event.nativeEvent.contentOffset.x;
    const w = Dimensions.get("window").width;
    const newIdx = Math.round(x / w);
    if (newIdx !== currentIndex) setCurrentIndex(newIdx);
  }
  
  return (
    <View style={{ flex: 1, width: "100%" }}>
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        style={{ flex: 1, width: "100%" }}
      >
        {urls.map((url, i) => {
          const isVideo = url.endsWith(".mp4") || url.includes("video");
          return (
            <View key={i} style={{ width: Dimensions.get("window").width, height: '100%', justifyContent: 'center', alignItems: 'center' }}>
              {isVideo && Platform.OS === 'web' ? (
                // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // @ts-ignore
                <video src={url} controls style={{ maxWidth: '100%', maxHeight: '100%' }} />
              ) : isVideo ? (
                <Pressable onPress={() => void openExternalUrl(url, "Videoclipul nu poate fi deschis acum.")}>
                  <View style={styles.videoModalContent}>
                    <MaterialCommunityIcons name="play-circle" size={54} color={colors.mintDark} />
                    <Text style={styles.videoModalTitle}>Vezi Clipul Video</Text>
                    <Text style={styles.videoModalText}>Atinge pentru a reda videoclipul</Text>
                  </View>
                </Pressable>
              ) : (
                <Pressable onPress={(e) => e.stopPropagation()} style={{ width: '100%', height: '100%' }}>
                  <Image source={{ uri: url }} style={{ width: '100%', height: '100%' }} resizeMode="contain" />
                </Pressable>
              )}
            </View>
          );
        })}
      </ScrollView>
      {Platform.OS === 'web' && urls.length > 1 && (
        <>
          {currentIndex > 0 && (
            <Pressable 
              onPress={(e) => { e.stopPropagation(); scrollRef.current?.scrollTo({ x: (currentIndex - 1) * Dimensions.get("window").width, animated: true }); }}
              style={{ position: 'absolute', left: 20, top: '50%', marginTop: -25, backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 25, width: 50, height: 50, justifyContent: 'center', alignItems: 'center', zIndex: 100 }}
            >
              <MaterialCommunityIcons name="chevron-left" size={30} color="#fff" />
            </Pressable>
          )}
          {currentIndex < urls.length - 1 && (
            <Pressable 
              onPress={(e) => { e.stopPropagation(); scrollRef.current?.scrollTo({ x: (currentIndex + 1) * Dimensions.get("window").width, animated: true }); }}
              style={{ position: 'absolute', right: 20, top: '50%', marginTop: -25, backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 25, width: 50, height: 50, justifyContent: 'center', alignItems: 'center', zIndex: 100 }}
            >
              <MaterialCommunityIcons name="chevron-right" size={30} color="#fff" />
            </Pressable>
          )}
        </>
      )}
    </View>
  );
}
