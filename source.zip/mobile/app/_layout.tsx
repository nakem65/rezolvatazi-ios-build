import { useEffect } from "react";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import type { NotificationResponse } from "expo-notifications";
import { Platform } from "react-native";
import { ProviderProvider } from "@/src/ProviderContext";
import { AuthProvider } from "@/src/AuthContext";
import { ModeProvider } from "@/src/ModeContext";
import { useMode } from "@/src/ModeContext";
import { colors } from "@/src/theme";

function openNotification(response: NotificationResponse, setActiveMode: ReturnType<typeof useMode>["setActiveMode"]) {
  const data = response.notification.request.content.data;
  const type = data?.type;
  const requestMode = data?.requestMode === "neighbor"
    ? "neighbor"
    : data?.requestMode === "hobby"
      ? "hobby"
      : "professional";
  const requestId = data?.requestId;
  const earningProfileId = data?.earningProfileId;
  if (type === "chat_message" && typeof requestId === "string") {
    const recipientRole = data?.recipientRole === "client" ? "client" : requestMode;
    setActiveMode(recipientRole);
    router.push({
      pathname: "/chat" as never,
      params: {
        requestId,
        ...(typeof data?.offerId === "string" ? { offerId: data.offerId } : {}),
        title: "Mesaj nou despre lucrare",
        role: recipientRole,
      },
    } as never);
    return;
  }
  if (type === "offer_received" && typeof requestId === "string") {
    setActiveMode("client");
    router.push({ pathname: "/my-request/[id]", params: { id: requestId } });
    return;
  }
  if (type === "offer_accepted") {
    setActiveMode(requestMode);
    router.push("/(tabs)/activity");
    return;
  }
  if (typeof requestId === "string") {
    setActiveMode(requestMode);
    router.push({
      pathname: "/request/[id]",
      params: {
        id: requestId,
        ...(typeof earningProfileId === "string" ? { earningProfileId } : {}),
      },
    });
  }
}

function NotificationRouter() {
  const { setActiveMode } = useMode();
  useEffect(() => {
    if (Platform.OS === "web") return;
    let subscription: { remove: () => void } | undefined;
    let active = true;
    let openedNotificationId = "";
    void import("expo-notifications").then((Notifications) => {
      Notifications.setNotificationHandler({
        handleNotification: async () => ({
          shouldShowBanner: true,
          shouldShowList: true,
          shouldPlaySound: true,
          shouldSetBadge: true,
        }),
      });
      const handleResponse = (response: NotificationResponse) => {
        const identifier = response.notification.request.identifier;
        if (identifier && identifier === openedNotificationId) return;
        openedNotificationId = identifier;
        openNotification(response, setActiveMode);
      };
      subscription = Notifications.addNotificationResponseReceivedListener(handleResponse);
      void Notifications.getLastNotificationResponseAsync()
        .then((response) => {
          if (active && response) handleResponse(response);
        })
        .catch(() => undefined);
    }).catch(() => undefined);
    return () => {
      active = false;
      subscription?.remove();
    };
  }, [setActiveMode]);
  return null;
}

export default function RootLayout() {
  useEffect(() => {
    if (Platform.OS === "web" && typeof document !== "undefined") {
      const styleId = "rnw-focus-reset";
      if (!document.getElementById(styleId)) {
        const style = document.createElement("style");
        style.id = styleId;
        style.textContent = `
          :focus-visible {
            outline: 3px solid #D9543A !important;
            outline-offset: 3px !important;
            box-shadow: 0 0 0 2px #FFF7E8 !important;
          }
          @media (forced-colors: active) {
            :focus-visible {
              outline-color: CanvasText !important;
              box-shadow: none !important;
            }
          }
        `;
        document.head.appendChild(style);
      }
    }
  }, []);

  return (
    <AuthProvider>
      <ModeProvider>
        <ProviderProvider>
          <NotificationRouter />
          <StatusBar style="dark" />
          <Stack screenOptions={{ contentStyle: { backgroundColor: colors.cream }, headerShadowVisible: false }}>
          <Stack.Screen name="index" options={{ headerShown: false }} />
          <Stack.Screen name="sign-in" options={{ headerShown: false }} />
          <Stack.Screen name="onboarding" options={{ headerShown: false }} />
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          <Stack.Screen name="work-profile" options={{ headerShown: false }} />
          <Stack.Screen name="profiles" options={{ headerShown: false }} />
          <Stack.Screen name="support" options={{ headerShown: false }} />
          <Stack.Screen name="chat" options={{ headerShown: false }} />
          <Stack.Screen name="new-request" options={{ headerShown: false }} />
          <Stack.Screen name="my-request/[id]" options={{ title: "Cererea mea", headerBackTitle: "Înapoi", headerStyle: { backgroundColor: colors.cream }, headerTintColor: colors.ink }} />
          <Stack.Screen name="legal/[document]" options={{ title: "RezolvatAzi", headerBackTitle: "Înapoi", headerStyle: { backgroundColor: colors.cream }, headerTintColor: colors.ink }} />
          <Stack.Screen name="reviews" options={{ title: "Recenzii", headerBackTitle: "Înapoi", headerStyle: { backgroundColor: colors.paper }, headerTintColor: colors.ink }} />
          <Stack.Screen
            name="request/[id]"
            options={{
              title: "Detalii cerere",
              headerStyle: { backgroundColor: colors.cream },
              headerTintColor: colors.ink,
              headerTitleStyle: { fontWeight: "800" },
              headerBackTitle: "Înapoi",
              headerRight: () => <MaterialCommunityIcons name="share-variant-outline" size={21} color={colors.ink} />,
            }}
          />
          </Stack>
        </ProviderProvider>
      </ModeProvider>
    </AuthProvider>
  );
}
