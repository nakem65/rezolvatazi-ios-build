import { useEffect, useMemo, useState } from "react";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useLocalSearchParams } from "expo-router";
import { ActivityIndicator, Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useProvider } from "@/src/ProviderContext";
import { fetchRequestById, reportRequest, updateRequestStatus } from "@/src/api";
import { colors, shadow } from "@/src/theme";
import { workOrderDetailChips } from "@/src/workOrderDetails";
import { OfferPricingComposer } from "@/components/OfferPricingComposer";
import { createPricingDraft, defaultPricingUnit, estimatePricingDraftTotal } from "@/src/pricing";

import { useAuth } from "@/src/AuthContext";

const urgentEtaOptions = [15, 30, 45, 60, 90, 120];
const scheduledEtaOptions = [30, 60, 120, 240, 480, 1440];

function etaLabel(minutes: number) {
  if (minutes === 1440) return "24 ore";
  if (minutes >= 60) return `${minutes / 60} ${minutes === 60 ? "oră" : "ore"}`;
  return `${minutes} min`;
}
const solutionCopy = {
  quotes: "OFERTE",
  hourly: "TARIF ORAR",
  team: "ECHIPĂ",
  recurring: "RECURENT",
  assessment: "CONSTATARE",
} as const;

export default function RequestDetailScreen() {
  const { id, earningProfileId } = useLocalSearchParams<{ id: string; earningProfileId?: string }>();
  const { requests, offers, available, toggleAvailable, setAvailabilityFor, sendOffer } = useProvider();
  const { provider } = useAuth();
  const listedRequest = useMemo(() => requests.find((item) => item.id === id), [id, requests]);
  const [loadedRequest, setLoadedRequest] = useState<typeof listedRequest>(undefined);
  const [requestLoading, setRequestLoading] = useState(!listedRequest);
  const [pricingDraft, setPricingDraft] = useState(() => createPricingDraft("job"));
  const [pricingRequestId, setPricingRequestId] = useState("");
  const [eta, setEta] = useState(30);
  const [message, setMessage] = useState("Pot ajunge în timpul estimat. Confirmăm detaliile înainte să pornesc.");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const request = listedRequest ?? loadedRequest;
  const neighbor = request?.requestMode === "neighbor";
  const isHobby = request?.requestMode === "hobby";
  const detailChips = workOrderDetailChips(request?.workOrder?.structuredDetailsJson);
  const etaOptions = request?.urgency === "Acum" ? urgentEtaOptions : scheduledEtaOptions;
  const isAccepted = Boolean(provider && request?.acceptedParticipantIds?.includes(provider.id));
  const currentOffer = useMemo(() => offers.find((offer) => offer.request.id === request?.id), [offers, request?.id]);

  useEffect(() => {
    if (!id || listedRequest) return;
    let active = true;
    void fetchRequestById(id, earningProfileId).then((item) => { if (active) setLoadedRequest(item); }).catch((caught) => { if (active) setError(caught instanceof Error ? caught.message : "Cererea nu mai este disponibilă."); }).finally(() => { if (active) setRequestLoading(false); });
    return () => { active = false; };
  }, [earningProfileId, id, listedRequest]);

  useEffect(() => {
    if (!request || pricingRequestId === request.id) return;
    const unit = defaultPricingUnit(request.workOrder, request.category);
    setPricingDraft(createPricingDraft(unit, request.workOrder?.requiredParticipants ?? request.requiredParticipants ?? 1));
    setPricingRequestId(request.id);
  }, [pricingRequestId, request]);

  function report() {
    Alert.alert("Raportezi și blochezi?", "Cererea va fi trimisă pentru verificare, iar persoana nu te va mai contacta.", [
      { text: "Renunță", style: "cancel" },
      { text: "Raportează", style: "destructive", onPress: async () => { setBusy(true); try { await reportRequest(request!.id); router.back(); } catch (caught) { setError(caught instanceof Error ? caught.message : "Eroare."); } finally { setBusy(false); } } },
    ]);
  }

  async function becomeAvailable() {
    setBusy(true);
    setError("");
    try {
      if (neighbor || isHobby) await toggleAvailable();
      else await setAvailabilityFor(240, request?.matchedEarningProfileId ?? earningProfileId);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Disponibilitatea nu a putut fi activată.");
    } finally {
      setBusy(false);
    }
  }

  if (requestLoading && !request) return <SafeAreaView style={styles.missing}><ActivityIndicator size="large" color={colors.accent} /></SafeAreaView>;
  if (!request) return <SafeAreaView style={styles.missing}><MaterialCommunityIcons name="clipboard-alert-outline" size={38} color={colors.muted} /><Text style={styles.missingTitle}>Cererea nu mai este disponibilă</Text><Pressable onPress={() => router.back()}><Text style={styles.backLink}>Înapoi</Text></Pressable></SafeAreaView>;

  async function submit() {
    const numericPrice = (neighbor || isHobby) ? 0 : pricingDraft.unitPriceLei;
    if (!neighbor && !isHobby && (!Number.isFinite(numericPrice) || numericPrice < 1 || estimatePricingDraftTotal(pricingDraft) < 1)) return setError("Completează un preț și cantități valide.");
    setBusy(true); setError("");
    try {
      const numericVisitFee = pricingDraft.travelMode === "fixed"
        ? pricingDraft.travelFeeLei
        : pricingDraft.travelMode === "per_km"
          ? pricingDraft.travelRateLei * pricingDraft.estimatedTravelKm
          : 0;
      await sendOffer({
        requestId: request!.id,
        earningProfileId: request!.matchedEarningProfileId ?? earningProfileId,
        price: numericPrice,
        priceType: (neighbor || isHobby) ? "free" : pricingDraft.priceType,
        visitFee: (neighbor || isHobby) ? 0 : numericVisitFee,
        materialsIncluded: (neighbor || isHobby) ? false : pricingDraft.materialsMode === "included",
        pricing: (neighbor || isHobby) ? undefined : pricingDraft,
        etaMinutes: eta,
        message: message.trim(),
      });
      router.replace("/(tabs)/activity");
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Eroare."); } finally { setBusy(false); }
  }

  return (
    <SafeAreaView style={styles.safe} edges={["bottom"]}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.flex} keyboardVerticalOffset={90}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.requestCard}>
            <View style={styles.badges}><Text style={[styles.badge, request.urgency === "Acum" && styles.badgeUrgent]}>{request.urgency}</Text></View>
            <Text style={styles.category}>{request.category}</Text>
            <Text style={styles.description}>{request.description}</Text>
            {request.workOrder ? (
              <View style={styles.intentDetails}>
                <Text style={styles.intentDetail}>{solutionCopy[request.workOrder.solutionKind]}</Text>
                {request.workOrder.requiredParticipants > 1 ? <Text style={styles.intentDetail}>{request.workOrder.requiredParticipants} PERSOANE</Text> : null}
                {request.workOrder.recurrenceLabel ? <Text style={styles.intentDetail}>{request.workOrder.recurrenceLabel.toLocaleUpperCase("ro-RO")}</Text> : null}
                {request.workOrder.budgetBani ? <Text style={styles.intentDetail}>BUGET {(request.workOrder.budgetBani / 100).toLocaleString("ro-RO")} LEI</Text> : null}
                {request.workOrder.riskClass === "regulated" ? <Text style={styles.intentDetail}>VERIFICARE NECESARĂ</Text> : null}
                {detailChips.map((detail) => <Text key={detail} style={styles.intentDetail}>{detail.toLocaleUpperCase("ro-RO")}</Text>)}
              </View>
            ) : null}
            {request.photos && request.photos.length > 0 ? (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, marginTop: 10 }}>
                {request.photos.map((url, i) => <Image key={i} source={{ uri: url }} style={{ width: 110, height: 85, borderRadius: 10, backgroundColor: "#EAECE9" }} />)}
              </ScrollView>
            ) : null}
            <View style={styles.metaRow}><MaterialCommunityIcons name="map-marker-outline" size={18} color={colors.muted} /><Text style={styles.metaText}>{request.city}</Text></View>
            <View style={styles.metaRow}><MaterialCommunityIcons name="clock-outline" size={18} color={colors.muted} /><Text style={styles.metaText}>Publicată recent</Text></View>
          </View>

          {isAccepted ? (
            <Pressable accessibilityRole="button" accessibilityLabel="Deschide conversația lucrării" onPress={() => router.push({ pathname: "/chat", params: { requestId: id ?? "demo-1", offerId: isHobby || request.workOrder?.solutionKind === "team" ? "" : currentOffer?.id ?? "", role: neighbor ? "neighbor" : (isHobby ? "hobby" : "professional"), title: `Mesaje despre ${request.category}`, preAcceptance: "0" } } as never)} style={styles.openChat}>
              <MaterialCommunityIcons name="chat-processing-outline" size={19} color={colors.mintDark} /><Text style={styles.openChatText}>Deschide conversația</Text><MaterialCommunityIcons name="chevron-right" size={20} color={colors.mintDark} />
            </Pressable>
          ) : null}

          {isAccepted && isHobby && request.acceptedParticipantIds && request.acceptedParticipantIds.length > 1 ? (
            <View style={{ marginTop: 20 }}>
              <Text style={styles.formTitle}>Participanți Grup</Text>
              {request.acceptedParticipantIds.filter(pid => pid !== provider?.id).map((pid, idx) => (
                <View key={pid} style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: colors.paper, padding: 12, borderRadius: 12, marginBottom: 8, borderWidth: 1, borderColor: colors.line }}>
                  <Text style={{ fontWeight: "700", color: colors.ink }}>Participant {idx + 1}</Text>
                  <Pressable disabled={busy} onPress={() => {
                    Alert.alert("Raportează participant lipsă", "Raportezi anonim lipsa acestui participant?", [
                      { text: "Renunță", style: "cancel" },
                      { text: "Raportează", style: "destructive", onPress: async () => {
                        setBusy(true);
                        try {
                          await updateRequestStatus(id!, "no_show", pid);
                          Alert.alert("Succes", "Participant raportat cu succes.");
                        } catch {
                          Alert.alert("Eroare", "Raportarea a eșuat.");
                        } finally {
                          setBusy(false);
                        }
                      }}
                    ]);
                  }} style={{ minHeight: 44, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, backgroundColor: colors.dangerSoft, paddingHorizontal: 10, paddingVertical: 8, borderRadius: 8 }}>
                    <MaterialCommunityIcons name="account-cancel-outline" size={16} color={colors.accentDark} />
                    <Text style={{ color: colors.accentDark, fontWeight: "700", fontSize: 12 }}>Raportează participant lipsă</Text>
                  </Pressable>
                </View>
              ))}
            </View>
          ) : null}

          <View style={styles.privacy}><MaterialCommunityIcons name="shield-lock-outline" size={21} color={colors.mintDark} /><View style={styles.privacyCopy}><Text style={styles.privacyTitle}>Telefonul apare după ce ești ales</Text><Text style={styles.privacyText}>Până atunci poți trimite oferta și discuta despre lucrare aici.</Text></View></View>
          <View style={styles.clientTrust}><MaterialCommunityIcons name="account-star-outline" size={22} color={colors.ink} /><View style={styles.privacyCopy}><Text style={styles.clientTrustTitle}>Solicitant verificat prin telefon</Text><Text style={styles.clientTrustText}>{request.clientReviewCount ? `★ ${((request.clientRating ?? 0) / 10).toFixed(1).replace(".", ",")} · ${request.clientReviewCount} evaluări · ${request.clientCompletedJobs ?? 0} acțiuni finalizate` : "Solicitant nou · încă fără evaluări pe acest rol"}</Text></View></View>
          {neighbor ? <View style={styles.safety}><MaterialCommunityIcons name="shield-check-outline" size={22} color={colors.mintDark} /><View style={styles.privacyCopy}><Text style={styles.safetyTitle}>Ajută numai dacă este simplu și sigur</Text><Text style={styles.safetyText}>Nu gestiona bani, medicamente, copii, gaz sau electricitate. Întâlniți-vă într-un spațiu comun când este posibil.</Text></View></View> : null}

          {!isAccepted && <Text style={styles.formTitle}>Răspunsul tău</Text>}
          {neighbor ? <View style={styles.freeHelp}><MaterialCommunityIcons name="hand-heart-outline" size={22} color={colors.mintDark} /><View><Text style={styles.freeHelpTitle}>Ajutor prietenesc gratuit</Text><Text style={styles.freeHelpText}>Nu se poate adăuga preț acestei cereri.</Text></View></View> : isHobby ? <View style={styles.freeHelp}><MaterialCommunityIcons name="run" size={22} color="#D84315" /><View><Text style={styles.freeHelpTitle}>Participare grup</Text><Text style={styles.freeHelpText}>Ești gata să te alături acestui grup.</Text></View></View> : <OfferPricingComposer value={pricingDraft} onChange={setPricingDraft} requiredParticipants={request.workOrder?.requiredParticipants ?? request.requiredParticipants ?? 1} />}

          {!isHobby && (
            <>
              <Text style={styles.label}>Ajung în aproximativ</Text>
              <View style={styles.etas}>{etaOptions.map((option) => <Pressable key={option} onPress={() => setEta(option)} style={[styles.eta, eta === option && styles.etaActive]}><Text style={[styles.etaText, eta === option && styles.etaTextActive]}>{etaLabel(option)}</Text></Pressable>)}</View>
            </>
          )}

          <Text style={styles.label}>Mesaj pentru client</Text>
          <TextInput value={message} onChangeText={setMessage} multiline numberOfLines={4} textAlignVertical="top" style={styles.message} />
          <Text style={styles.messageHint}>💬 {isHobby ? "Spune-i organizatorului detalii relevante despre tine." : "Oferta poate fi o estimare. Vei putea discuta detaliile exacte și trimite poze pe Chat."}</Text>
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <Pressable disabled={busy} onPress={report} style={styles.report}><MaterialCommunityIcons name="flag-outline" size={17} color={colors.accentDark} /><Text style={styles.reportText}>Raportează cererea și blochează persoana</Text></Pressable>
        </ScrollView>

        <View style={styles.bottomBar}>
          {available ? (
            <Pressable disabled={busy} onPress={() => void submit()} style={({ pressed }) => [styles.submit, (pressed || busy) && styles.submitPressed]}><Text style={styles.submitText}>{busy ? "Se trimite..." : neighbor || isHobby ? "Trimite răspunsul" : "Trimite oferta"}</Text><MaterialCommunityIcons name="arrow-right" size={21} color={colors.paper} /></Pressable>
          ) : (
            <Pressable disabled={busy} onPress={() => void becomeAvailable()} style={styles.submit}><Text style={styles.submitText}>{busy ? "Se activează..." : "Devino disponibil pentru a răspunde"}</Text></Pressable>
          )}
          <Text style={styles.fee}>{neighbor ? "Ajutorul între vecini este întotdeauna gratuit." : isHobby ? "Participarea la grupuri locale este gratuită." : "Momentan nu se taxează nicio ofertă sau lucrare."}</Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream },
  flex: { flex: 1 },
  content: { padding: 18, paddingBottom: 22 },
  requestCard: { backgroundColor: colors.paper, borderRadius: 20, padding: 18, borderWidth: 1, borderColor: colors.line, ...shadow },
  badges: { flexDirection: "row", gap: 7 },
  badge: { color: "#8A5A00", backgroundColor: "#FFF2CE", borderRadius: 999, overflow: "hidden", paddingHorizontal: 9, paddingVertical: 5, fontSize: 12, fontWeight: "900", textTransform: "uppercase" },
  badgeUrgent: { color: colors.accentDark, backgroundColor: colors.dangerSoft },
  category: { color: colors.ink, fontSize: 22, fontWeight: "800", letterSpacing: -0.5, marginTop: 16 },
  description: { color: colors.text, fontSize: 14, lineHeight: 21, marginTop: 8, marginBottom: 15 },
  intentDetails: { flexDirection: "row", flexWrap: "wrap", gap: 5, marginTop: -5, marginBottom: 13 },
  intentDetail: { color: colors.mintDark, backgroundColor: colors.mint, borderRadius: 99, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 5, fontSize: 12, fontWeight: "900" },
  metaRow: { borderTopWidth: 1, borderTopColor: colors.line, paddingTop: 11, marginTop: 1, flexDirection: "row", alignItems: "center", gap: 6 },
  metaText: { color: colors.muted, fontSize: 12 },
  privacy: { backgroundColor: colors.mint, borderRadius: 15, padding: 13, flexDirection: "row", gap: 10, marginVertical: 20 },
  privacyCopy: { flex: 1 },
  privacyTitle: { color: colors.mintDark, fontSize: 13, fontWeight: "800" },
  privacyText: { color: colors.mintDark, opacity: 0.8, fontSize: 12, lineHeight: 18, marginTop: 3 },
  clientTrust: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 15, padding: 13, flexDirection: "row", gap: 10, marginTop: -10, marginBottom: 20 }, clientTrustTitle: { color: colors.ink, fontSize: 13, fontWeight: "900" }, clientTrustText: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 3 },
  openChat: { minHeight: 52, backgroundColor: colors.mint, borderWidth: 1, borderColor: "#B8DEC5", borderRadius: 14, paddingHorizontal: 14, marginTop: 14, flexDirection: "row", alignItems: "center", gap: 9 }, openChatText: { flex: 1, color: colors.mintDark, fontSize: 14, fontWeight: "900" },
  safety: { backgroundColor: "#FFF2CE", borderRadius: 15, padding: 13, flexDirection: "row", gap: 10, marginTop: -10, marginBottom: 20 }, safetyTitle: { color: colors.ink, fontSize: 13, fontWeight: "900" }, safetyText: { color: "#725814", fontSize: 12, lineHeight: 18, marginTop: 3 },
  formTitle: { color: colors.ink, fontSize: 21, fontWeight: "800", letterSpacing: -0.5, marginBottom: 17 },
  label: { color: colors.ink, fontSize: 13, fontWeight: "800", marginBottom: 7, marginTop: 5 },
  priceInput: { height: 55, backgroundColor: colors.paper, borderRadius: 13, borderWidth: 1, borderColor: colors.line, flexDirection: "row", alignItems: "center", paddingHorizontal: 14, marginBottom: 15 },
  priceTypes: { flexDirection: "row", gap: 8, marginBottom: 15 }, priceType: { flex: 1, minHeight: 44, alignItems: "center", justifyContent: "center", paddingVertical: 11, borderRadius: 11, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line }, priceTypeActive: { backgroundColor: colors.ink, borderColor: colors.ink }, priceTypeText: { color: colors.muted, fontSize: 12, fontWeight: "800" }, priceTypeTextActive: { color: colors.paper }, materialsRow: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 13, padding: 12, flexDirection: "row", alignItems: "center", marginBottom: 15 }, materialsCopy: { flex: 1 }, materialsTitle: { color: colors.ink, fontSize: 13, fontWeight: "800" }, materialsText: { color: colors.muted, fontSize: 12, marginTop: 3 },
  freeHelp: { backgroundColor: colors.mint, borderRadius: 14, padding: 13, flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 15 }, freeHelpTitle: { color: colors.mintDark, fontSize: 13, fontWeight: "900" }, freeHelpText: { color: colors.mintDark, fontSize: 12, marginTop: 3 },
  priceText: { flex: 1, color: colors.ink, fontSize: 18, fontWeight: "700" },
  currency: { color: colors.muted, fontSize: 12, fontWeight: "900" },
  etas: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 17 },
  eta: { width: "31%", minHeight: 44, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, paddingVertical: 11, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  etaActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  etaText: { color: colors.muted, fontSize: 12, fontWeight: "800" },
  etaTextActive: { color: colors.paper },
  message: { minHeight: 96, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 13, padding: 13, color: colors.text, fontSize: 14, lineHeight: 20 },
  messageHint: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 4, fontWeight: "600" },
  error: { color: colors.accentDark, fontSize: 12, fontWeight: "700", marginTop: 9 },
  report: { minHeight: 44, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: 10 }, reportText: { color: colors.accentDark, fontSize: 12, fontWeight: "800" },
  bottomBar: { paddingHorizontal: 18, paddingTop: 11, paddingBottom: 9, backgroundColor: colors.paper, borderTopWidth: 1, borderTopColor: colors.line },
  submit: { height: 52, borderRadius: 14, backgroundColor: colors.accent, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 17 },
  submitPressed: { backgroundColor: colors.accentDark, opacity: 0.85 },
  submitText: { color: colors.paper, fontSize: 15, fontWeight: "800" },
  fee: { color: colors.muted, textAlign: "center", fontSize: 12, lineHeight: 18, marginTop: 7 },
  missing: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.cream, padding: 30 },
  missingTitle: { color: colors.ink, fontSize: 17, fontWeight: "800", marginTop: 13 },
  backLink: { color: colors.accent, fontSize: 12, fontWeight: "800", marginTop: 12 },
});
