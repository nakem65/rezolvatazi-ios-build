import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, AppState, Pressable, RefreshControl, StyleSheet, Text, View } from "react-native";
import { AppHeader } from "@/components/AppHeader";
import { Screen } from "@/components/Screen";
import { fetchChatInbox } from "@/src/api";
import { colors } from "@/src/theme";
import type { ChatInboxConversation } from "@/src/types";

function messageTime(value: string) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "";
  const now = new Date();
  if (date.toDateString() === now.toDateString()) {
    return new Intl.DateTimeFormat("ro-RO", { hour: "2-digit", minute: "2-digit" }).format(date);
  }
  return new Intl.DateTimeFormat("ro-RO", { day: "2-digit", month: "short" }).format(date);
}

function InboxRow({ item }: { item: ChatInboxConversation }) {
  const unread = item.unreadCount > 0;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${item.title}, ${item.unreadCount} mesaje necitite`}
      onPress={() => router.push({
        pathname: "/chat" as never,
        params: {
          requestId: item.requestId,
          ...(item.offerId ? { offerId: item.offerId } : {}),
          title: item.title,
          role: item.userRole,
          preAcceptance: item.preAcceptance ? "1" : "0",
        },
      } as never)}
      style={({ pressed }) => [styles.row, unread && styles.rowUnread, pressed && styles.pressed]}
    >
      <View style={[styles.avatar, unread && styles.avatarUnread]}>
        <Text style={[styles.avatarText, unread && styles.avatarTextUnread]}>{item.title.replace(/^Discuție cu |^Echipă · /, "").charAt(0).toLocaleUpperCase("ro-RO") || "M"}</Text>
      </View>
      <View style={styles.copy}>
        <View style={styles.titleRow}>
          <Text numberOfLines={1} style={[styles.title, unread && styles.titleUnread]}>{item.title}</Text>
          <Text style={[styles.time, unread && styles.timeUnread]}>{messageTime(item.latestMessage.createdAt)}</Text>
        </View>
        <Text numberOfLines={1} style={styles.request}>{item.requestDescription}</Text>
        <View style={styles.previewRow}>
          <Text numberOfLines={1} style={[styles.preview, unread && styles.previewUnread]}>
            {item.latestMessage.isMine ? "Tu: " : ""}{item.latestMessage.preview}
          </Text>
          {unread ? <View style={styles.badge}><Text style={styles.badgeText}>{item.unreadCount > 99 ? "99+" : item.unreadCount}</Text></View> : null}
        </View>
      </View>
    </Pressable>
  );
}

export default function MessagesScreen() {
  const [items, setItems] = useState<ChatInboxConversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async (manual = false) => {
    if (manual) setRefreshing(true);
    try {
      const result = await fetchChatInbox();
      setItems(result.conversations);
      setError("");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Mesajele nu au putut fi încărcate.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { void load(); }, [load]));
  useEffect(() => {
    const interval = setInterval(() => {
      if (AppState.currentState === "active") void load();
    }, 10_000);
    return () => clearInterval(interval);
  }, [load]);

  return (
    <Screen refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void load(true)} tintColor={colors.accent} />}>
      <AppHeader eyebrow="Toate conversațiile" title="Mesaje" />
      <View style={styles.heading}>
        <Text style={styles.headingTitle}>Conversațiile tale</Text>
        <Text style={styles.headingText}>Mesajele de client și de prestator sunt adunate aici, în ordinea activității.</Text>
      </View>
      {loading ? <ActivityIndicator color={colors.accent} style={styles.loading} /> : null}
      {error ? <View style={styles.error}><MaterialCommunityIcons name="cloud-alert-outline" size={20} color={colors.accentDark} /><Text style={styles.errorText}>{error}</Text><Pressable onPress={() => void load()}><Text style={styles.retry}>Reîncearcă</Text></Pressable></View> : null}
      {!loading && !error && !items.length ? (
        <View style={styles.empty}>
          <View style={styles.emptyIcon}><MaterialCommunityIcons name="message-text-outline" size={30} color={colors.mintDark} /></View>
          <Text style={styles.emptyTitle}>Nu ai conversații încă</Text>
          <Text style={styles.emptyText}>Când primești o ofertă sau răspunzi unei cereri, discuția va apărea aici.</Text>
        </View>
      ) : null}
      <View style={styles.list}>{items.map((item) => <InboxRow key={`${item.requestId}:${item.conversationKey}`} item={item} />)}</View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  heading: { paddingVertical: 10, marginBottom: 8 },
  headingTitle: { color: colors.ink, fontSize: 27, lineHeight: 33, fontWeight: "900", letterSpacing: -0.7 },
  headingText: { color: colors.muted, fontSize: 13, lineHeight: 19, marginTop: 5, maxWidth: 440 },
  loading: { marginVertical: 42 },
  list: { gap: 8 },
  row: { minHeight: 91, flexDirection: "row", alignItems: "center", gap: 12, padding: 12, borderWidth: 1, borderColor: colors.line, borderRadius: 18, backgroundColor: colors.paper },
  rowUnread: { borderColor: "#BFDAC8", backgroundColor: "#F7FCF8" },
  pressed: { opacity: 0.68, transform: [{ scale: 0.995 }] },
  avatar: { width: 48, height: 48, flexShrink: 0, alignItems: "center", justifyContent: "center", borderRadius: 16, backgroundColor: "#EEF1EE" },
  avatarUnread: { backgroundColor: colors.mint },
  avatarText: { color: colors.muted, fontSize: 17, fontWeight: "900" },
  avatarTextUnread: { color: colors.mintDark },
  copy: { minWidth: 0, flex: 1, gap: 3 },
  titleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  title: { minWidth: 0, flex: 1, color: colors.ink, fontSize: 14, fontWeight: "700" },
  titleUnread: { fontWeight: "900" },
  time: { color: colors.muted, fontSize: 10 },
  timeUnread: { color: colors.mintDark, fontWeight: "900" },
  request: { color: colors.muted, fontSize: 11 },
  previewRow: { minWidth: 0, flexDirection: "row", alignItems: "center", gap: 8 },
  preview: { minWidth: 0, flex: 1, color: colors.muted, fontSize: 12 },
  previewUnread: { color: colors.ink, fontWeight: "700" },
  badge: { minWidth: 22, height: 22, alignItems: "center", justifyContent: "center", paddingHorizontal: 5, borderRadius: 11, backgroundColor: colors.accent },
  badgeText: { color: colors.paper, fontSize: 9, fontWeight: "900" },
  empty: { alignItems: "center", paddingHorizontal: 26, paddingVertical: 50, borderWidth: 1, borderStyle: "dashed", borderColor: colors.line, borderRadius: 21, backgroundColor: colors.paper },
  emptyIcon: { width: 58, height: 58, alignItems: "center", justifyContent: "center", borderRadius: 20, backgroundColor: colors.mint },
  emptyTitle: { color: colors.ink, fontSize: 18, fontWeight: "900", marginTop: 16 },
  emptyText: { color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 6 },
  error: { flexDirection: "row", alignItems: "center", gap: 9, padding: 13, borderRadius: 15, backgroundColor: colors.dangerSoft },
  errorText: { flex: 1, color: colors.accentDark, fontSize: 11, lineHeight: 16 },
  retry: { color: colors.accentDark, fontSize: 11, fontWeight: "900" },
});
