import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useFocusEffect, useLocalSearchParams } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { FlatList, Image, KeyboardAvoidingView, Modal, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { AppHeader } from "@/components/AppHeader";
import { MyRequestCard } from "@/components/MyRequestCard";
import { acceptWorkAssignment, assignOfferMember, fetchMyRequests, fetchOfferAssignments, fetchWorkAssignments, rateClient, updateOffer, withdrawOffer } from "@/src/api";
import { pickImageFromGallery } from "@/src/mediaPicker";
import { useMode } from "@/src/ModeContext";
import { useProvider } from "@/src/ProviderContext";
import { colors, shadow } from "@/src/theme";
import { MyRequest, OfferAssignmentMember, OfferPricingDraft, SentOffer, WorkAssignment } from "@/src/types";
import { showAppAlert } from "@/src/alerts";
import { createPricingDraft, pricingDraftFromOffer, pricingPresentation } from "@/src/pricing";
import { OfferPricingComposer } from "@/components/OfferPricingComposer";
import { openExternalUrl } from "@/src/externalLink";

function ProviderOfferActivity({ offer, neighbor, initialChatOpen = false, onRated }: { offer: SentOffer; neighbor: boolean; initialChatOpen?: boolean; onRated: () => Promise<void> }) {
  const [score, setScore] = useState(5);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [mediaUrls, setMediaUrls] = useState<string[]>([]);
  const [teamOpen, setTeamOpen] = useState(false);
  const [teamMembers, setTeamMembers] = useState<OfferAssignmentMember[]>([]);
  const [teamBusy, setTeamBusy] = useState(false);
  const openedInboundChat = useRef(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editPricing, setEditPricing] = useState<OfferPricingDraft>(() => offer.pricing
    ? pricingDraftFromOffer(offer.pricing)
    : { ...createPricingDraft("job", offer.request.requiredParticipants ?? 1), unitPriceLei: offer.price, priceType: offer.priceType });
  const [editEta, setEditEta] = useState(String(offer.etaMinutes));
  const [editMessage, setEditMessage] = useState(offer.message);
  
  const isHobby = offer.request.requestMode === "hobby";
  const isRecurring = offer.request.workOrder?.solutionKind === "recurring";
  const completed = offer.status === "accepted" && offer.request.status === "completed";
  const cancelled = offer.request.status === "cancelled" || offer.request.status === "cancelled_after_match";
  const pricing = pricingPresentation(offer.pricing);
  const canChat = !cancelled && (
    (offer.status === "pending" && !neighbor && !isHobby)
    || offer.status === "accepted"
  );

  function openChat() {
    router.push({
      pathname: "/chat",
      params: {
        requestId: offer.request.id,
        offerId: offer.status === "pending" || (!isHobby && offer.request.workOrder?.solutionKind !== "team") ? offer.id : "",
        role: isHobby ? "hobby" : neighbor ? "neighbor" : "professional",
        title: offer.status === "pending" ? "Discuție cu clientul" : `Mesaje despre ${offer.request.category}`,
        preAcceptance: offer.status === "pending" ? "1" : "0",
      },
    } as never);
  }

  useEffect(() => {
    if (initialChatOpen && !openedInboundChat.current) {
      openedInboundChat.current = true;
      router.push({
        pathname: "/chat",
        params: {
          requestId: offer.request.id,
          offerId: offer.status === "pending" || (!isHobby && offer.request.workOrder?.solutionKind !== "team") ? offer.id : "",
          role: isHobby ? "hobby" : neighbor ? "neighbor" : "professional",
          title: offer.status === "pending" ? "Discuție cu clientul" : `Mesaje despre ${offer.request.category}`,
          preAcceptance: offer.status === "pending" ? "1" : "0",
        },
      } as never);
    }
  }, [initialChatOpen, isHobby, neighbor, offer.id, offer.request.category, offer.request.id, offer.request.workOrder?.solutionKind, offer.status]);

  async function submitRating() {
    if (score < 1 || score > 5) return;
    setBusy(true); setError("");
    try { await rateClient(offer.id, score, comment.trim(), mediaUrls); await onRated(); }
    catch (caught) { setError(caught instanceof Error ? caught.message : "Evaluarea nu a putut fi trimisă."); }
    finally { setBusy(false); }
  }

  function openEditOffer() {
    setEditPricing(offer.pricing
      ? pricingDraftFromOffer(offer.pricing)
      : { ...createPricingDraft("job", offer.request.requiredParticipants ?? 1), unitPriceLei: offer.price, priceType: offer.priceType });
    setEditEta(String(offer.etaMinutes));
    setEditMessage(offer.message);
    setError("");
    setEditOpen(true);
  }

  async function saveOfferChanges() {
    setBusy(true);
    setError("");
    try {
      await updateOffer(offer.id, offer.revision, {
        pricing: editPricing,
        etaMinutes: Number(editEta),
        message: editMessage.trim(),
      });
      setEditOpen(false);
      await onRated();
      showAppAlert("Oferta a fost actualizată", "Clientul vede acum noua versiune și trebuie să verifice din nou prețul și condițiile.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Oferta nu a putut fi actualizată.");
    } finally {
      setBusy(false);
    }
  }

  function confirmWithdrawOffer() {
    showAppAlert("Retragi oferta?", "Clientul nu o va mai putea accepta. Istoricul conversației rămâne vizibil.", [
      { text: "Renunță", style: "cancel" },
      {
        text: "Retrage oferta",
        style: "destructive",
        onPress: () => void (async () => {
          setBusy(true);
          setError("");
          try {
            await withdrawOffer(offer.id, offer.revision);
            await onRated();
          } catch (caught) {
            setError(caught instanceof Error ? caught.message : "Oferta nu a putut fi retrasă.");
          } finally {
            setBusy(false);
          }
        })(),
      },
    ]);
  }

  async function openTeam() {
    setTeamBusy(true);
    setError("");
    try {
      const result = await fetchOfferAssignments(offer.id);
      setTeamMembers(result.members);
      setTeamOpen(true);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Echipa nu a putut fi încărcată.");
    } finally {
      setTeamBusy(false);
    }
  }

  async function assignMember(member: OfferAssignmentMember) {
    setTeamBusy(true);
    setError("");
    try {
      await assignOfferMember(offer.id, member.accountId);
      const result = await fetchOfferAssignments(offer.id);
      setTeamMembers(result.members);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Lucrarea nu a putut fi atribuită.");
    } finally {
      setTeamBusy(false);
    }
  }

  return (
    <View>
      <View style={styles.offer}>
        <View style={[styles.offerIcon, offer.status === "accepted" && !cancelled && styles.offerIconAccepted]}>
          <MaterialCommunityIcons 
            name={cancelled ? "cancel" : offer.status === "accepted" ? "check-bold" : offer.status === "declined" ? "close" : "clock-outline"} 
            size={21} 
            color={cancelled ? colors.accentDark : offer.status === "accepted" ? colors.mintDark : offer.status === "declined" ? colors.muted : colors.accent} 
          />
        </View>
        <View style={styles.offerCopy}>
          <Text style={styles.category}>{offer.request.category}</Text>
          <Text style={styles.location}>{offer.request.city}</Text>
          <Text style={styles.clientReputation}>
            {offer.request.clientReviewCount ? `★ ${((offer.request.clientRating ?? 0) / 10).toFixed(1).replace(".", ",")} Organizator · ${offer.request.clientReviewCount} evaluări` : "Organizator nou · telefon verificat"}
          </Text>
          {offer.status === "withdrawn" ? <Text style={[styles.pending, styles.declined]}>Ofertă retrasă</Text> : <Text style={[styles.pending, offer.status === "accepted" && !cancelled && styles.accepted, (offer.status === "declined" || cancelled) && styles.declined]}>
            {cancelled ? "Eveniment anulat de organizator" : offer.status === "accepted" ? (neighbor ? "Ajutorul tău a fost acceptat" : isHobby ? "Ai fost acceptat în grup" : isRecurring ? `Colaborare activă · ${offer.request.workOrder?.recurrenceLabel ?? "periodic"}` : "Oferta ta a fost aleasă") : offer.status === "declined" ? "A fost aleasă altă persoană" : "În așteptarea răspunsului"}
          </Text>}
        </View>
        <View>
          <Text style={styles.price}>{neighbor || isHobby ? "Gratuit" : pricing?.headline ?? `${offer.price} lei`}</Text>
          <Text style={styles.eta}>{pricing?.formula ?? `Poți ajunge în ${offer.etaMinutes} min`}</Text>
          {pricing ? <Text style={styles.eta}>Sosire: {offer.etaMinutes} min</Text> : null}
        </View>
      </View>

      <Pressable
        accessibilityLabel="Vezi cererea pentru această ofertă"
        onPress={() => router.push({ pathname: "/request/[id]", params: { id: offer.request.id, ...(offer.request.matchedEarningProfileId ? { earningProfileId: offer.request.matchedEarningProfileId } : {}) } } as never)}
        style={styles.requestDetailsButton}
      >
        <MaterialCommunityIcons name="clipboard-text-outline" size={17} color={colors.mintDark} />
        <Text style={styles.requestDetailsText}>Vezi cererea și toate detaliile</Text>
        <MaterialCommunityIcons name="chevron-right" size={18} color={colors.muted} />
      </Pressable>

      {(offer.status === "pending" || offer.status === "withdrawn") && !neighbor && !isHobby ? (
        <View style={styles.offerActions}>
          <Pressable disabled={busy} onPress={openEditOffer} style={styles.editOfferButton}>
            <MaterialCommunityIcons name="pencil-outline" size={17} color={colors.ink} />
            <Text style={styles.editOfferText}>{offer.status === "withdrawn" ? "Modifică și reactivează" : "Modifică oferta"}</Text>
          </Pressable>
          {offer.status === "pending" ? (
            <Pressable disabled={busy} onPress={confirmWithdrawOffer} style={styles.withdrawOfferButton}>
              <MaterialCommunityIcons name="close-circle-outline" size={17} color={colors.accentDark} />
              <Text style={styles.withdrawOfferText}>Retrage</Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}
      {offer.revision > 1 ? <Text style={styles.revisionNote}>Oferta a fost actualizată</Text> : null}
      {error && !completed ? <Text style={styles.offerError}>{error}</Text> : null}

      <Modal visible={editOpen} transparent animationType="slide" onRequestClose={() => setEditOpen(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.editOverlay}>
          <View style={styles.editSheet}>
            <View style={styles.editHeading}>
              <View><Text style={styles.editKicker}>OFERTĂ · VERSIUNEA {offer.revision + 1}</Text><Text style={styles.editTitle}>{offer.status === "withdrawn" ? "Modifică și reactivează" : "Modifică oferta"}</Text></View>
              <Pressable hitSlop={10} onPress={() => setEditOpen(false)}><MaterialCommunityIcons name="close" size={24} color={colors.ink} /></Pressable>
            </View>
            <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.editScroll}>
              <OfferPricingComposer value={editPricing} onChange={setEditPricing} requiredParticipants={offer.request.requiredParticipants ?? 1} />
              <Text style={styles.editLabel}>Poți ajunge în câte minute?</Text>
              <TextInput value={editEta} onChangeText={setEditEta} inputMode="numeric" placeholder="Ex: 60" placeholderTextColor="#99A19A" style={styles.editInput} />
              <Text style={styles.editLabel}>Mesaj pentru client</Text>
              <TextInput value={editMessage} onChangeText={setEditMessage} maxLength={500} multiline placeholder="Ce include oferta și când poți începe?" placeholderTextColor="#99A19A" style={styles.editMessage} />
              {error ? <Text style={styles.offerError}>{error}</Text> : null}
              <Pressable disabled={busy} onPress={() => void saveOfferChanges()} style={styles.saveOfferButton}>
                <Text style={styles.saveOfferText}>{busy ? "Se salvează..." : offer.status === "withdrawn" ? "Salvează și reactivează" : "Salvează versiunea nouă"}</Text>
              </Pressable>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {offer.status === "accepted" && !isHobby && !cancelled ? (
        <View style={styles.contact}>
          <View>
            <Text style={styles.contactLabel}>CONTACT DEBLOCAT</Text>
            <Text style={styles.contactName}>{offer.request.contactName}</Text>
            <Text style={styles.contactPhone}>{offer.request.contactPhone}</Text>
          </View>
          <Pressable accessibilityLabel={`Sună ${offer.request.contactPhone}`} onPress={() => void openExternalUrl(`tel:${offer.request.contactPhone.replace(/\s/g, "")}`, "Apelul nu poate fi inițiat pe acest dispozitiv.")} style={styles.call}>
            <MaterialCommunityIcons name="phone" size={20} color={colors.paper} />
          </Pressable>
        </View>
      ) : null}

      {offer.status === "accepted" && !cancelled && offer.request.locationLabel ? (
        <View style={styles.addressCard}>
          <View style={styles.addressIcon}><MaterialCommunityIcons name="map-marker-check-outline" size={21} color={colors.mintDark} /></View>
          <View style={styles.addressCopy}>
            <Text style={styles.contactLabel}>LOCAȚIA LUCRĂRII</Text>
            <Text style={styles.addressText}>{offer.request.locationLabel}</Text>
          </View>
          {typeof offer.request.latitude === "number" && typeof offer.request.longitude === "number" ? (
            <Pressable
              accessibilityLabel="Deschide traseul către lucrare"
              onPress={() => void openExternalUrl(`https://www.google.com/maps/dir/?api=1&destination=${offer.request.latitude},${offer.request.longitude}`, "Traseul nu poate fi deschis acum.")}
              style={styles.routeButton}
            >
              <MaterialCommunityIcons name="navigation-variant-outline" size={20} color={colors.paper} />
            </Pressable>
          ) : null}
        </View>
      ) : null}

      {offer.canManageTeam && offer.status === "accepted" && offer.request.status === "matched" ? (
        <View style={styles.teamCard}>
          <Pressable disabled={teamBusy} onPress={() => void (teamOpen ? setTeamOpen(false) : openTeam())} style={styles.teamHeader}>
            <View style={styles.teamIcon}><MaterialCommunityIcons name="account-multiple-check-outline" size={20} color={colors.mintDark} /></View>
            <View style={styles.offerCopy}>
              <Text style={styles.teamTitle}>Cine execută lucrarea?</Text>
              <Text style={styles.teamText}>Atribuie unui membru care a acceptat invitația în firmă.</Text>
            </View>
            <MaterialCommunityIcons name={teamOpen ? "chevron-up" : "chevron-down"} size={21} color={colors.muted} />
          </Pressable>
          {teamOpen ? (
            <View style={styles.teamList}>
              {teamMembers.map((member) => (
                <View key={member.accountId} style={styles.teamMember}>
                  <View style={styles.memberAvatar}><Text style={styles.memberInitial}>{member.name.charAt(0).toUpperCase()}</Text></View>
                  <View style={styles.offerCopy}>
                    <Text style={styles.memberName}>{member.name}</Text>
                    <Text style={styles.teamText}>{member.assignment ? (member.assignment.status === "assigned" ? "Așteaptă confirmarea" : member.assignment.status === "accepted" ? "A acceptat lucrarea" : "Lucrare finalizată") : "Disponibil pentru atribuire"}</Text>
                  </View>
                  <Pressable disabled={teamBusy || Boolean(member.assignment)} onPress={() => void assignMember(member)} style={[styles.assignButton, member.assignment && styles.assignButtonDone]}>
                    <Text style={[styles.assignButtonText, member.assignment && styles.assignButtonTextDone]}>{member.assignment ? "Atribuit" : "Atribuie"}</Text>
                  </Pressable>
                </View>
              ))}
              {!teamMembers.length ? <Text style={styles.teamEmpty}>Invită mai întâi un membru din „Profiluri și echipe”.</Text> : null}
            </View>
          ) : null}
        </View>
      ) : null}

      {canChat ? (
        <Pressable accessibilityRole="button" accessibilityLabel="Deschide conversația" onPress={openChat} style={styles.chatToggle}>
          <MaterialCommunityIcons name="chat-processing-outline" size={19} color={colors.mintDark} />
          <Text style={styles.chatToggleText}>Deschide conversația</Text>
          <MaterialCommunityIcons name="chevron-right" size={20} color={colors.muted} />
        </Pressable>
      ) : null}

      {completed && !offer.customerRating ? (
        <View style={styles.ratingCard}>
          <Text style={styles.ratingTitle}>Cum a fost colaborarea cu solicitantul?</Text>
          <Text style={styles.ratingSubtitle}>Evaluarea ajută comunitatea să aleagă în siguranță.</Text>
          <View style={styles.stars}>
            {[1, 2, 3, 4, 5].map((value) => (
              <Pressable accessibilityLabel={`${value} stele`} key={value} onPress={() => setScore(value)}>
                <MaterialCommunityIcons name={value <= score ? "star" : "star-outline"} size={31} color="#E4A515" />
              </Pressable>
            ))}
          </View>
          <TextInput value={comment} onChangeText={setComment} maxLength={500} multiline placeholder="Comentariu opțional" placeholderTextColor="#99A19A" style={styles.comment} />
          <Text style={styles.charCount}>{comment.length}/500</Text>
          
          {mediaUrls.length > 0 && (
            <View style={{ flexDirection: "row", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
              {mediaUrls.map((url, idx) => (
                <View key={idx}>
                  {url.endsWith(".mp4") || url.includes("video") ? (
                    <View style={{ width: 50, height: 50, borderRadius: 8, backgroundColor: "#E5E7E2", alignItems: "center", justifyContent: "center" }}>
                      <MaterialCommunityIcons name="video" size={24} color={colors.muted} />
                    </View>
                  ) : (
                    <Image source={{ uri: url }} style={{ width: 50, height: 50, borderRadius: 8 }} />
                  )}
                  <Pressable hitSlop={10} onPress={() => setMediaUrls(prev => prev.filter((_, i) => i !== idx))} style={{ position: "absolute", top: -5, right: -5, backgroundColor: colors.paper, borderRadius: 10, borderWidth: 1, borderColor: colors.line }}>
                    <MaterialCommunityIcons name="close" size={12} color={colors.accentDark} />
                  </Pressable>
                </View>
              ))}
            </View>
          )}
          
          <View style={styles.mediaRow}>
            <Pressable onPress={async () => { if (mediaUrls.length >= 5) { showAppAlert("Limită", "Puteți adăuga maxim 5 fișiere."); return; } const url = await pickImageFromGallery(); if (url) setMediaUrls(prev => [...prev, url]); }} style={styles.mediaBtn}>
              <MaterialCommunityIcons name="camera" size={16} color={colors.muted} />
              <Text style={styles.mediaBtnText}>Poză</Text>
            </Pressable>
          </View>

          {error ? <Text style={styles.ratingError}>{error}</Text> : null}
          <Pressable disabled={busy} onPress={() => void submitRating()} style={styles.rate}>
            <Text style={styles.rateText}>{busy ? "Se trimite..." : "Trimite evaluarea"}</Text>
          </Pressable>
        </View>
      ) : null}

      {completed && offer.customerRating ? (
        <View style={styles.rated}>
          <MaterialCommunityIcons name="check-decagram" size={21} color={colors.mintDark} />
          <Text style={styles.ratedText}>Evaluare trimisă · {"★".repeat(offer.customerRating.score)}</Text>
        </View>
      ) : null}
    </View>
  );
}

function AssignedWorkCard({ assignment, onAccepted }: { assignment: WorkAssignment; onAccepted: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  async function accept() {
    setBusy(true);
    try {
      await acceptWorkAssignment(assignment.id);
      await onAccepted();
    } catch (caught) {
      showAppAlert("Nu am putut confirma", caught instanceof Error ? caught.message : "Încearcă din nou.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <View style={styles.assignedCard}>
      <View style={styles.assignedTop}>
        <View style={styles.teamIcon}><MaterialCommunityIcons name="briefcase-account-outline" size={20} color={colors.mintDark} /></View>
        <View style={styles.offerCopy}>
          <Text style={styles.assignedEyebrow}>LUCRARE PRIMITĂ PRIN {assignment.profileName.toLocaleUpperCase("ro-RO")}</Text>
          <Text style={styles.assignedTitle}>{assignment.request.category}</Text>
          <Text numberOfLines={2} style={styles.teamText}>{assignment.request.description}</Text>
        </View>
      </View>
      <View style={styles.assignedDetails}>
        <Text style={styles.assignedDetail}>📍 {assignment.request.locationLabel}</Text>
        <Text style={styles.assignedDetail}>Contact: {assignment.request.contactName} · {assignment.request.contactPhone}</Text>
      </View>
      {assignment.status === "assigned" ? (
        <Pressable disabled={busy} onPress={() => void accept()} style={styles.acceptAssignment}>
          <Text style={styles.acceptAssignmentText}>{busy ? "Se confirmă..." : "Accept lucrarea"}</Text>
        </Pressable>
      ) : (
        <View style={styles.assignmentAccepted}><MaterialCommunityIcons name="check-circle" size={17} color={colors.mintDark} /><Text style={styles.assignmentAcceptedText}>{assignment.status === "completed" ? "Lucrare finalizată" : "Ai acceptat lucrarea"}</Text></View>
      )}
    </View>
  );
}

export default function ActivityScreen() {
  const { chatRequestId, chatOfferId } = useLocalSearchParams<{ chatRequestId?: string; chatOfferId?: string }>();
  const { activeMode } = useMode();
  const { offers, billing, source, loading, refresh } = useProvider();
  const [mine, setMine] = useState<MyRequest[]>([]);
  const [mineLoading, setMineLoading] = useState(false);
  const [assignments, setAssignments] = useState<WorkAssignment[]>([]);
  const refreshAssignments = useCallback(async () => {
    if (activeMode !== "professional") return;
    try {
      const result = await fetchWorkAssignments();
      setAssignments(result.assignments);
    } catch {
      setAssignments([]);
    }
  }, [activeMode]);
  const refreshMine = useCallback(async () => {
    if (activeMode !== "client") return;
    setMineLoading(true);
    try {
      const data = await fetchMyRequests();
      setMine(data.filter((item) => item.status !== "open"));
    } finally {
      setMineLoading(false);
    }
  }, [activeMode]);
  
  useFocusEffect(useCallback(() => {
    let active = true;
    if (activeMode === "client") {
      fetchMyRequests().then(data => {
        if (active) setMine(data.filter((item) => item.status !== "open"));
      });
    } else {
      void refresh();
      if (activeMode === "professional") void refreshAssignments();
    }
    return () => { active = false; };
  }, [activeMode, refresh, refreshAssignments]));

  const neighbor = activeMode === "neighbor";
  const modeOffers = offers.filter((offer) => offer.request.requestMode === activeMode);

  return activeMode === "client" ? (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.cream }} edges={["top"]}>
      <FlatList
        data={mine}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <MyRequestCard request={item} />}
        contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 12, paddingBottom: 48 }}
        refreshControl={<RefreshControl refreshing={mineLoading} onRefresh={refreshMine} tintColor={colors.accent} />}
        ListHeaderComponent={<AppHeader eyebrow="Alese și finalizate" title="Activitate" source={source} />}
        ListEmptyComponent={!mineLoading ? <View style={styles.empty}><View style={styles.emptyIcon}><MaterialCommunityIcons name="history" size={31} color={colors.muted} /></View><Text style={styles.emptyTitle}>Activitatea apare aici</Text><Text style={styles.emptyText}>După ce alegi o ofertă, cererea se mută în această listă.</Text></View> : null}
      />
    </SafeAreaView>
  ) : (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.cream }} edges={["top"]}>
      <FlatList
        data={modeOffers}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ProviderOfferActivity
            offer={item}
            neighbor={neighbor}
            initialChatOpen={chatRequestId === item.request.id && (!chatOfferId || chatOfferId === item.id)}
            onRated={refresh}
          />
        )}
        contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 12, paddingBottom: 48 }}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refresh} tintColor={colors.accent} />}
        ListHeaderComponent={
          <>
            <AppHeader eyebrow={neighbor ? "Ajutor oferit" : "Oferte și lucrări"} title="Activitate" source={source} />
            {activeMode === "professional" && assignments.length ? (
              <View style={styles.assignmentSection}>
                <Text style={styles.sectionTitle}>Lucrări atribuite mie</Text>
                {assignments.map((assignment) => <AssignedWorkCard key={assignment.id} assignment={assignment} onAccepted={refreshAssignments} />)}
              </View>
            ) : null}
            <View style={styles.summary}><View><Text style={styles.summaryNumber}>{modeOffers.length}</Text><Text style={styles.summaryLabel}>{neighbor ? "răspunsuri trimise" : "oferte trimise"}</Text></View><View style={styles.divider} /><View><Text style={styles.summaryNumber}>{billing.betaFree ? "0 lei" : `${(billing.pendingBani / 100).toFixed(0)} lei`}</Text><Text style={styles.summaryLabel}>{billing.betaFree ? "gratuit" : "de plată momentan"}</Text></View></View>
            <Text style={styles.sectionTitle}>{neighbor ? "Ajutor oferit" : "Oferte trimise"}</Text>
          </>
        }
        ListEmptyComponent={!loading ? <View style={styles.empty}><View style={styles.emptyIcon}><MaterialCommunityIcons name={neighbor ? "hand-heart-outline" : "briefcase-outline"} size={32} color={colors.muted} /></View><Text style={styles.emptyTitle}>{neighbor ? "Primul ajutor apare aici" : "Prima ofertă apare aici"}</Text><Text style={styles.emptyText}>{neighbor ? "Deschide o cerere simplă și spune persoanei când poți ajunge." : "Deschide o cerere potrivită și trimite prețul și timpul de sosire."}</Text></View> : null}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  offerActions: { flexDirection: "row", gap: 8, marginTop: -3, marginBottom: 8 },
  requestDetailsButton: { minHeight: 44, flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.mint, borderRadius: 12, paddingHorizontal: 12, marginTop: -3, marginBottom: 8 },
  requestDetailsText: { flex: 1, color: colors.mintDark, fontSize: 12, fontWeight: "900" },
  editOfferButton: { flex: 1, minHeight: 43, borderRadius: 12, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  editOfferText: { color: colors.ink, fontSize: 10, fontWeight: "900" },
  withdrawOfferButton: { minHeight: 43, borderRadius: 12, backgroundColor: colors.dangerSoft, borderWidth: 1, borderColor: "#F0CCC3", paddingHorizontal: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  withdrawOfferText: { color: colors.accentDark, fontSize: 10, fontWeight: "900" },
  revisionNote: { color: colors.muted, fontSize: 9, marginBottom: 10, paddingHorizontal: 4 },
  offerError: { color: colors.accentDark, fontSize: 10, lineHeight: 15, marginBottom: 10, textAlign: "center" },
  editOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  editSheet: { maxHeight: "94%", backgroundColor: colors.cream, borderTopLeftRadius: 24, borderTopRightRadius: 24, overflow: "hidden" },
  editHeading: { backgroundColor: colors.paper, paddingHorizontal: 18, paddingVertical: 15, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: colors.line },
  editKicker: { color: colors.accent, fontSize: 9, fontWeight: "900", letterSpacing: 0.5 },
  editTitle: { color: colors.ink, fontSize: 18, fontWeight: "900", marginTop: 3 },
  editScroll: { padding: 16, paddingBottom: 34 },
  editLabel: { color: colors.ink, fontSize: 12, fontWeight: "900", marginBottom: 6 },
  editInput: { height: 48, borderWidth: 1, borderColor: colors.line, borderRadius: 12, backgroundColor: colors.paper, color: colors.ink, paddingHorizontal: 12, marginBottom: 14 },
  editMessage: { minHeight: 88, borderWidth: 1, borderColor: colors.line, borderRadius: 12, backgroundColor: colors.paper, color: colors.ink, padding: 12, textAlignVertical: "top", marginBottom: 14 },
  saveOfferButton: { minHeight: 50, borderRadius: 13, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center" },
  saveOfferText: { color: colors.paper, fontSize: 11, fontWeight: "900" },
  summary: { backgroundColor: colors.ink, borderRadius: 20, padding: 19, flexDirection: "row", alignItems: "center", marginBottom: 25 }, summaryNumber: { color: colors.paper, fontSize: 22, fontWeight: "800" }, summaryLabel: { color: "#AEBAB2", fontSize: 10, marginTop: 4 }, divider: { height: 38, width: 1, backgroundColor: "#415047", marginHorizontal: 28 }, sectionTitle: { color: colors.ink, fontSize: 18, fontWeight: "800", marginBottom: 12 },
  chatToggle: { minHeight: 48, backgroundColor: colors.paper, borderRadius: 14, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 14, marginTop: -3, marginBottom: 12, flexDirection: "row", alignItems: "center", gap: 9 },
  chatToggleText: { flex: 1, color: colors.ink, fontSize: 12, fontWeight: "800" },
  offer: { backgroundColor: colors.paper, borderRadius: 17, padding: 15, borderWidth: 1, borderColor: colors.line, flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 10, ...shadow }, offerIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.dangerSoft, alignItems: "center", justifyContent: "center" }, offerIconAccepted: { backgroundColor: colors.mint }, offerCopy: { flex: 1 }, category: { color: colors.ink, fontSize: 13, fontWeight: "800" }, location: { color: colors.muted, fontSize: 10, marginTop: 3 }, clientReputation: { color: colors.muted, fontSize: 8, fontWeight: "700", marginTop: 4 }, pending: { color: "#A36C00", fontSize: 9, fontWeight: "800", marginTop: 7 }, accepted: { color: colors.mintDark }, declined: { color: colors.muted }, price: { color: colors.ink, fontSize: 14, fontWeight: "800", textAlign: "right" }, eta: { color: colors.muted, fontSize: 10, textAlign: "right", marginTop: 4 },
  empty: { marginTop: 35, alignItems: "center", paddingHorizontal: 35 }, emptyIcon: { width: 64, height: 64, borderRadius: 22, backgroundColor: "#E8EAE5", alignItems: "center", justifyContent: "center" }, emptyTitle: { color: colors.ink, fontSize: 17, fontWeight: "800", marginTop: 16 }, emptyText: { color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 6 }, contact: { backgroundColor: colors.ink, borderRadius: 15, marginTop: -3, marginBottom: 12, padding: 14, flexDirection: "row", alignItems: "center" }, contactLabel: { color: "#85E6A5", fontSize: 8, fontWeight: "900", letterSpacing: 0.9 }, contactName: { color: colors.paper, fontSize: 13, fontWeight: "800", marginTop: 6 }, contactPhone: { color: "#B9C5BD", fontSize: 11, marginTop: 3 }, call: { marginLeft: "auto", width: 43, height: 43, borderRadius: 14, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
  addressCard: { backgroundColor: colors.ink, borderRadius: 15, marginTop: -3, marginBottom: 12, padding: 14, flexDirection: "row", alignItems: "center", gap: 11 },
  addressIcon: { width: 39, height: 39, borderRadius: 12, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  addressCopy: { flex: 1 },
  addressText: { color: colors.paper, fontSize: 11, lineHeight: 16, fontWeight: "700", marginTop: 5 },
  routeButton: { width: 43, height: 43, borderRadius: 14, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
  teamCard: { backgroundColor: colors.paper, borderRadius: 15, borderWidth: 1, borderColor: colors.line, marginTop: -3, marginBottom: 12, overflow: "hidden" },
  teamHeader: { minHeight: 66, flexDirection: "row", alignItems: "center", gap: 11, padding: 13 },
  teamIcon: { width: 39, height: 39, borderRadius: 12, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  teamTitle: { color: colors.ink, fontSize: 12, fontWeight: "900" },
  teamText: { color: colors.muted, fontSize: 9, lineHeight: 13, marginTop: 2 },
  teamList: { borderTopWidth: 1, borderTopColor: colors.line, paddingHorizontal: 13 },
  teamMember: { minHeight: 58, flexDirection: "row", alignItems: "center", gap: 9, borderBottomWidth: 1, borderBottomColor: colors.line },
  memberAvatar: { width: 34, height: 34, borderRadius: 11, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center" },
  memberInitial: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  memberName: { color: colors.ink, fontSize: 11, fontWeight: "800" },
  assignButton: { minHeight: 32, borderRadius: 10, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center", paddingHorizontal: 10 },
  assignButtonDone: { backgroundColor: colors.mint },
  assignButtonText: { color: colors.paper, fontSize: 9, fontWeight: "900" },
  assignButtonTextDone: { color: colors.mintDark },
  teamEmpty: { color: colors.muted, fontSize: 10, textAlign: "center", paddingVertical: 16 },
  assignmentSection: { marginBottom: 18 },
  assignedCard: { backgroundColor: colors.paper, borderRadius: 17, borderWidth: 1, borderColor: colors.line, padding: 14, marginBottom: 10, ...shadow },
  assignedTop: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  assignedEyebrow: { color: colors.mintDark, fontSize: 8, lineHeight: 12, fontWeight: "900", letterSpacing: 0.5 },
  assignedTitle: { color: colors.ink, fontSize: 13, fontWeight: "900", marginTop: 3 },
  assignedDetails: { backgroundColor: colors.cream, borderRadius: 11, padding: 10, marginTop: 10, gap: 4 },
  assignedDetail: { color: colors.ink, fontSize: 10, lineHeight: 15 },
  acceptAssignment: { minHeight: 42, borderRadius: 12, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center", marginTop: 10 },
  acceptAssignmentText: { color: colors.paper, fontSize: 11, fontWeight: "900" },
  assignmentAccepted: { minHeight: 40, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, backgroundColor: colors.mint, borderRadius: 12, marginTop: 10 },
  assignmentAcceptedText: { color: colors.mintDark, fontSize: 10, fontWeight: "900" },
  ratingCard: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 17, padding: 15, marginTop: -3, marginBottom: 12 }, ratingTitle: { color: colors.ink, textAlign: "center", fontSize: 14, fontWeight: "900" }, ratingSubtitle: { color: colors.muted, textAlign: "center", fontSize: 9, marginTop: 4 }, stars: { flexDirection: "row", justifyContent: "center", gap: 4, marginVertical: 12 }, comment: { minHeight: 65, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, borderRadius: 11, padding: 10, textAlignVertical: "top", color: colors.text }, charCount: { color: colors.muted, fontSize: 10, textAlign: "right", marginTop: 4 }, mediaRow: { flexDirection: "row", gap: 8, marginTop: 10 }, mediaBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, paddingVertical: 10, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, borderRadius: 11 }, mediaBtnText: { color: colors.muted, fontSize: 10, fontWeight: "800" }, ratingError: { color: colors.accentDark, fontSize: 9, textAlign: "center", marginTop: 7 }, rate: { height: 43, backgroundColor: colors.ink, borderRadius: 11, alignItems: "center", justifyContent: "center", marginTop: 9 }, rateText: { color: colors.paper, fontSize: 10, fontWeight: "900" }, rated: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.mint, borderRadius: 13, padding: 12, marginTop: -3, marginBottom: 12 }, ratedText: { color: colors.mintDark, fontSize: 10, fontWeight: "800" },
});
