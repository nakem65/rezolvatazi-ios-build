import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { Redirect, Tabs } from "expo-router";
import { useEffect, useState } from "react";
import { AppState } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { colors } from "@/src/theme";
import { useAuth } from "@/src/AuthContext";
import { useMode } from "@/src/ModeContext";
import { fetchChatInbox } from "@/src/api";

type IconName = React.ComponentProps<typeof MaterialCommunityIcons>["name"];

const icons: Record<string, IconName> = {
  index: "view-dashboard-outline",
  requests: "clipboard-text-outline",
  messages: "message-text-outline",
  activity: "briefcase-check-outline",
  profile: "account-circle-outline",
};

export default function TabLayout() {
  const { status, provider } = useAuth();
  const { setActiveMode } = useMode();
  const insets = useSafeAreaInsets();
  const [unreadMessages, setUnreadMessages] = useState(0);
  const bottomInset = Math.max(insets.bottom, 9);

  useEffect(() => {
    if (status !== "ready") {
      setUnreadMessages(0);
      return;
    }
    let active = true;
    async function refreshUnread() {
      try {
        const result = await fetchChatInbox();
        if (active) setUnreadMessages(result.totalUnread);
      } catch {
        // Păstrăm ultimul contor cunoscut până la următoarea sincronizare.
      }
    }
    void refreshUnread();
    const interval = setInterval(() => {
      if (AppState.currentState === "active") void refreshUnread();
    }, 15_000);
    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "active") void refreshUnread();
    });
    return () => {
      active = false;
      clearInterval(interval);
      subscription.remove();
    };
  }, [status]);

  if (status === "signedOut") return <Redirect href="/" />;
  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: "#89938C",
        // Five tabs still fit on a narrow phone at 11pt and remain readable on
        // a tablet. Nine-point labels were effectively unreadable in store
        // screenshots and at normal viewing distance.
        tabBarLabelStyle: { fontSize: 11, fontWeight: "800", marginTop: 2 },
        tabBarStyle: {
          height: 66 + bottomInset,
          paddingTop: 8,
          paddingBottom: bottomInset,
          backgroundColor: colors.paper,
          borderTopColor: "transparent",
          elevation: 18,
          shadowColor: colors.ink,
          shadowOpacity: 0.1,
          shadowRadius: 18,
          shadowOffset: { width: 0, height: -7 },
        },
        tabBarIcon: ({ color, size, focused }) => (
          <MaterialCommunityIcons
            name={icons[route.name] ?? "circle-outline"}
            size={focused ? size + 3 : size + 1}
            color={color}
          />
        ),
      })}
    >
      <Tabs.Screen name="index" options={{ title: "Acasă" }} />
      <Tabs.Screen
        name="requests"
        options={{ title: "Oportunități", href: provider?.professionalEnabled ? undefined : null }}
        listeners={{ tabPress: () => setActiveMode("professional") }}
      />
      <Tabs.Screen name="messages" options={{ title: "Mesaje", tabBarBadge: unreadMessages > 0 ? (unreadMessages > 99 ? "99+" : unreadMessages) : undefined, tabBarBadgeStyle: { backgroundColor: colors.accent, color: colors.paper, fontSize: 11, fontWeight: "900" } }} />
      <Tabs.Screen name="activity" options={{ title: "Activitate" }} />
      <Tabs.Screen name="profile" options={{ title: "Cont" }} />
    </Tabs>
  );
}
