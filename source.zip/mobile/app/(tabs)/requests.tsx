import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useMemo, useRef, useState, type ComponentRef } from "react";
import { Animated, FlatList, Modal, PanResponder, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View, Platform } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import * as Location from "expo-location";
let MapView = View as unknown as typeof import("react-native-maps").default;
let Marker = View as unknown as typeof import("react-native-maps").Marker;
if (Platform.OS === "ios") {
  // Android needs a separately configured Google Maps SDK key. Do not load the
  // native map there until that configuration exists: a missing key can close
  // the native view on some devices. The Android fallback below keeps nearby
  // work fully usable in the meantime.
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const maps: typeof import("react-native-maps") = require("react-native-maps");
  MapView = maps.default;
  Marker = maps.Marker;
}
import { AppHeader } from "@/components/AppHeader";
import { MyRequestCard } from "@/components/MyRequestCard";
import { RequestCard } from "@/components/RequestCard";
import { WebMapView } from "@/components/WebMapView";
import { fetchMyRequests } from "@/src/api";
import { categories } from "@/src/classify";
import { useMode } from "@/src/ModeContext";
import { useProvider } from "@/src/ProviderContext";
import { useAuth } from "@/src/AuthContext";
import { colors } from "@/src/theme";
import { MyRequest } from "@/src/types";

const urgencyFilters = ["Toate", "Acum", "Astăzi", "În 24 de ore"];
const distanceFilters = ["Orice", "Sub 5 km", "Sub 10 km"];
const budgetFilters = ["Orice", "Sub 100 lei", "100 - 500 lei", "Peste 500 lei"];

function getDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371;
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function AndroidNearbyFallback({
  requests,
  onSelectRequest,
}: {
  requests: ReturnType<typeof useProvider>["requests"];
  onSelectRequest: (id: string) => void;
}) {
  return (
    <ScrollView contentContainerStyle={styles.androidNearbyContent}>
      <View style={styles.androidNearbyNotice}>
        <View style={styles.androidNearbyIcon}>
          <MaterialCommunityIcons name="map-marker-radius-outline" size={24} color={colors.mintDark} />
        </View>
        <View style={styles.androidNearbyCopy}>
          <Text style={styles.androidNearbyTitle}>Lucrări apropiate</Text>
          <Text style={styles.androidNearbyText}>Vezi cererile ordonate după urgență și distanță. Atinge una pentru toate detaliile.</Text>
        </View>
      </View>
      {requests.length ? requests.map((request) => (
        <Pressable key={request.id} onPress={() => onSelectRequest(request.id)} style={styles.androidNearbyRow}>
          <View style={styles.androidNearbyPin}><MaterialCommunityIcons name="map-marker" size={19} color={colors.accent} /></View>
          <View style={styles.androidNearbyRowCopy}>
            <Text style={styles.androidNearbyCategory}>{request.category}</Text>
            <Text numberOfLines={2} style={styles.androidNearbyDescription}>{request.description}</Text>
            <Text style={styles.androidNearbyMeta}>{request.city}{typeof request.distanceKm === "number" ? ` · ${request.distanceKm.toFixed(1).replace(".", ",")} km` : ""}</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={21} color={colors.muted} />
        </Pressable>
      )) : <Text style={styles.empty}>Nu există lucrări pentru filtrele alese. Schimbă filtrele sau verifică din nou mai târziu.</Text>}
    </ScrollView>
  );
}

export default function RequestsScreen() {
  const { provider } = useAuth();
  const { activeMode } = useMode();
  const { requests, loading, refresh, source } = useProvider();
  
  const [urgency, setUrgency] = useState("Toate");
  const [category, setCategory] = useState("Toate");
  const [distance, setDistance] = useState("Orice");
  const [budget, setBudget] = useState("Orice");
  
  const [viewMode, setViewMode] = useState<"list" | "map">("list");
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);

  const [showFilters, setShowFilters] = useState(false);
  const [mine, setMine] = useState<MyRequest[]>([]);
  const [mineLoading, setMineLoading] = useState(false);
  
  const refreshMine = useCallback(async () => { if (activeMode !== "client") return; setMineLoading(true); try { setMine(await fetchMyRequests()); } catch (error) { console.error("Failed to fetch my requests:", error); } finally { setMineLoading(false); } }, [activeMode]);
  useFocusEffect(useCallback(() => { void refreshMine(); }, [refreshMine]));
  
  const activeFiltersCount = (category !== "Toate" ? 1 : 0) + (distance !== "Orice" ? 1 : 0) + (budget !== "Orice" ? 1 : 0);

  const requestsWithDistance = useMemo(() => {
    return requests.map(req => {
      if (typeof req.distanceKm === "number") return req;
      if (req.latitude && req.longitude && provider?.latitude && provider?.longitude) {
        return { ...req, distanceKm: Math.round(getDistanceKm(provider.latitude, provider.longitude, req.latitude, req.longitude) * 10) / 10 };
      }
      return req;
    });
  }, [requests, provider]);

  const visible = useMemo(() => {
    return requestsWithDistance.filter((request) => {
      if (urgency !== "Toate" && request.urgency !== urgency) return false;
      if (category !== "Toate" && request.category !== category) return false;
      if (distance !== "Orice") {
        const maxDist = distance === "Sub 5 km" ? 5 : 10;
        if (request.distanceKm && request.distanceKm > maxDist) return false;
      }
      if (budget !== "Orice") {
        if (!request.clientPrice) return false;
        if (budget === "Sub 100 lei" && request.clientPrice >= 100) return false;
        if (budget === "100 - 500 lei" && (request.clientPrice < 100 || request.clientPrice > 500)) return false;
        if (budget === "Peste 500 lei" && request.clientPrice <= 500) return false;
      }
      return true;
    }).sort((a, b) => {
      const urgencyRank = (value: string) => value === "Acum" ? 0 : value === "Astăzi" ? 1 : 2;
      const urgencyDifference = urgencyRank(a.urgency) - urgencyRank(b.urgency);
      if (urgencyDifference) return urgencyDifference;
      const matchDifference = (b.match?.score ?? 0) - (a.match?.score ?? 0);
      if (matchDifference) return matchDifference;
      return (a.distanceKm ?? 999) - (b.distanceKm ?? 999);
    });
  }, [requestsWithDistance, urgency, category, distance, budget]);

  const selectedRequest = useMemo(() => visible.find(r => r.id === selectedRequestId), [visible, selectedRequestId]);
  const mappableRequests = useMemo(
    () => visible.filter((request) => typeof request.latitude === "number" && typeof request.longitude === "number"),
    [visible],
  );

  const neighbor = activeMode === "neighbor";

  const panResponder = useMemo(
    () => PanResponder.create({
      onMoveShouldSetPanResponder: (_, gestureState) => Math.abs(gestureState.dy) > 15,
      onPanResponderRelease: (_, gestureState) => {
        if (gestureState.dy > 50) {
          setSelectedRequestId(null);
        }
      }
    }),
    [],
  );

  const mapRef = useRef<ComponentRef<typeof MapView>>(null);
  const [location, setLocation] = useState<Location.LocationObject | null>(null);

  useFocusEffect(
    useCallback(() => {
      let isActive = true;
      async function requestLocation() {
        if (!isActive) return;
        try {
          const { status } = await Location.requestForegroundPermissionsAsync();
          if (status !== 'granted') return;
          const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
          if (isActive) setLocation(loc);
        } catch (error) {
          console.error("Location error:", error);
        }
      }
      if (viewMode === "map" && !location) {
        void requestLocation();
      }
      return () => { isActive = false; };
    }, [viewMode, location])
  );

  const centerMapOnMe = () => {
    const lat = location?.coords.latitude ?? provider?.latitude;
    const lng = location?.coords.longitude ?? provider?.longitude;
    if (lat && lng) {
      if (Platform.OS !== "web" && mapRef.current) {
        mapRef.current.animateToRegion({
          latitude: lat,
          longitude: lng,
          latitudeDelta: 0.1,
          longitudeDelta: 0.1
        }, 500);
      }
    }
  };

  const filterHeaderJsx = (
    <>
      <AppHeader eyebrow={neighbor ? "Persoane din zona ta" : "Potrivite profilului tău"} title={neighbor ? "Ajutor în apropiere" : "Cereri active"} source={source} />
      <View style={styles.filtersWrapper}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filters}>
          <Pressable onPress={() => setShowFilters(true)} style={[styles.filter, activeFiltersCount > 0 && styles.filterActive, { paddingRight: 15 }]}>
            <MaterialCommunityIcons name="filter-variant" size={12} color={activeFiltersCount > 0 ? colors.paper : colors.muted} style={{ marginRight: 4 }} />
            <Text style={[styles.filterText, activeFiltersCount > 0 && styles.filterTextActive]}>Filtre {activeFiltersCount > 0 ? `(${activeFiltersCount})` : ""}</Text>
          </Pressable>
          <View style={styles.toggleGroup}>
            <Pressable onPress={() => setViewMode("list")} style={[styles.toggleBtn, viewMode === "list" && styles.toggleBtnActive]}>
              <MaterialCommunityIcons name="format-list-bulleted" size={14} color={viewMode === "list" ? colors.paper : colors.muted} />
            </Pressable>
            <Pressable onPress={() => setViewMode("map")} style={[styles.toggleBtn, viewMode === "map" && styles.toggleBtnActive]}>
              <MaterialCommunityIcons name="map-outline" size={14} color={viewMode === "map" ? colors.paper : colors.muted} />
            </Pressable>
          </View>
          {urgencyFilters.map((item) => <Pressable key={item} onPress={() => setUrgency(item)} style={[styles.filter, item === urgency && styles.filterActive]}><Text style={[styles.filterText, item === urgency && styles.filterTextActive]}>{item}</Text></Pressable>)}
        </ScrollView>
      </View>
    </>
  );

  return activeMode === "client" ? (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.cream }} edges={["top"]}>
      <FlatList
        data={mine}
        keyExtractor={req => req.id}
        refreshControl={<RefreshControl refreshing={mineLoading} onRefresh={refreshMine} tintColor={colors.accent} />}
        contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 12, flexGrow: 1, paddingBottom: 48 }}
        ListHeaderComponent={<>
          <AppHeader eyebrow="Tot ce ai publicat" title="Cererile mele" source={source} />
          <Pressable onPress={() => router.push("/new-request" as never)} style={styles.newButton}><View style={styles.newIcon}><MaterialCommunityIcons name="plus" size={20} color={colors.paper} /></View><View style={styles.newCopy}><Text style={styles.newTitle}>Publică o lucrare nouă</Text><Text style={styles.newText}>Ofertă, tarif orar, echipă sau recurență</Text></View><MaterialCommunityIcons name="chevron-right" size={22} color={colors.paper} /></Pressable>
        </>}
        renderItem={({ item }) => <MyRequestCard request={item} />}
        ListEmptyComponent={!mineLoading ? <Text style={styles.empty}>Nu ai publicat încă nicio cerere.</Text> : null}
      />
    </SafeAreaView>
  ) : (
    <>
      {viewMode === "list" ? (
        <SafeAreaView style={{ flex: 1, backgroundColor: colors.cream }} edges={["top"]}>
          <FlatList
            data={visible}
            keyExtractor={req => req.id}
            refreshControl={<RefreshControl refreshing={loading} onRefresh={refresh} tintColor={colors.accent} />}
            contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 12, flexGrow: 1, paddingBottom: 48 }}
            ListHeaderComponent={<>
              {filterHeaderJsx}
              <View style={styles.countRow}><Text style={styles.count}>{visible.length} {visible.length === 1 ? "cerere găsită" : "cereri găsite"}</Text><Text style={styles.order}>Cele mai urgente primele</Text></View>
            </>}
            renderItem={({ item }) => <RequestCard request={item} />}
            ListEmptyComponent={!loading ? <Text style={styles.empty}>Nu sunt cereri pentru filtrele alese.</Text> : null}
          />
        </SafeAreaView>
      ) : (
      <SafeAreaView style={styles.mapSafe} edges={["top"]}>
        <View style={styles.mapHeaderWrap}>{filterHeaderJsx}</View>
        <View style={styles.mapContainer}>
          {Platform.OS === "web" ? (
            <WebMapView
              latitude={provider?.latitude ?? 44.4268}
              longitude={provider?.longitude ?? 26.1025}
              requests={visible}
              selectedRequestId={selectedRequestId}
              onSelectRequest={(id) => setSelectedRequestId(prev => prev === id ? null : id)}
            />
          ) : Platform.OS === "ios" ? (
            <View style={{ flex: 1, position: "relative" }}>
              <MapView 
                ref={mapRef}
                style={styles.map} 
                showsUserLocation={true}
                showsMyLocationButton={false}
                initialRegion={{ 
                  latitude: provider?.latitude ?? 44.4268, 
                  longitude: provider?.longitude ?? 26.1025, 
                  latitudeDelta: 0.1, 
                  longitudeDelta: 0.1 
                }}
                onPress={() => setSelectedRequestId(null)}
              >
                {provider?.latitude && provider?.longitude ? (
                  <Marker coordinate={{ latitude: provider.latitude, longitude: provider.longitude }} title="Locația ta" pinColor="blue" />
                ) : null}
                {mappableRequests.map(request => {
                  return (
                    <Marker 
                      key={request.id} 
                      coordinate={{ latitude: request.latitude!, longitude: request.longitude! }}
                      stopPropagation
                      onPress={() => setSelectedRequestId(request.id)}
                      pinColor={selectedRequestId === request.id ? "red" : "green"}
                    />
                  );
                })}
              </MapView>

              <View pointerEvents="box-none" style={styles.mapHelpWrap}>
                <View pointerEvents="none" style={styles.mapHelp}>
                  <MaterialCommunityIcons name="map-marker-radius-outline" size={19} color={colors.mintDark} />
                  <Text style={styles.mapHelpText}>Harta arată lucrările disponibile. Atinge un marcaj pentru detalii.</Text>
                </View>
                {!loading && visible.length === 0 ? (
                  <View style={styles.mapEmptyCard}>
                    <Text style={styles.mapEmptyTitle}>Nu există lucrări aici acum</Text>
                    <Text style={styles.mapEmptyText}>Schimbă filtrele sau verifică lista mai târziu.</Text>
                    <Pressable onPress={() => setViewMode("list")} style={styles.mapEmptyButton}><Text style={styles.mapEmptyButtonText}>Vezi lista</Text></Pressable>
                  </View>
                ) : visible.length > 0 && mappableRequests.length === 0 ? (
                  <View style={styles.mapEmptyCard}>
                    <Text style={styles.mapEmptyTitle}>Lucrările sunt în listă</Text>
                    <Text style={styles.mapEmptyText}>Aceste cereri nu au încă o poziție aproximativă pe hartă.</Text>
                    <Pressable onPress={() => setViewMode("list")} style={styles.mapEmptyButton}><Text style={styles.mapEmptyButtonText}>Vezi lucrările</Text></Pressable>
                  </View>
                ) : null}
              </View>

              <Pressable onPress={centerMapOnMe} style={styles.myLocationBtnNative}>
                <MaterialCommunityIcons name="crosshairs-gps" size={24} color={colors.ink} />
              </Pressable>
            </View>
          ) : (
            <AndroidNearbyFallback requests={visible} onSelectRequest={setSelectedRequestId} />
          )}
          {selectedRequest && (
            <View style={styles.mapCardOverlay} pointerEvents="box-none">
              <Animated.View {...panResponder.panHandlers} style={{ width: "100%", alignItems: "center" }}>
                <View style={{ width: 36, height: 5, backgroundColor: "rgba(0,0,0,0.2)", borderRadius: 3, marginBottom: 8 }} />
                <View style={{ width: "100%" }}>
                  <RequestCard request={selectedRequest} compact onClose={() => setSelectedRequestId(null)} />
                </View>
              </Animated.View>
              <View style={styles.approximateLocationNote}><MaterialCommunityIcons name="shield-lock-outline" size={16} color={colors.mintDark} /><Text style={styles.approximateLocationText}>Poziție aproximativă. Traseul exact apare numai dacă oferta ta este acceptată.</Text></View>
            </View>
          )}
        </View>
      </SafeAreaView>
    )}


      <Modal visible={showFilters} animationType="slide" presentationStyle="formSheet" onRequestClose={() => setShowFilters(false)}>
        <SafeAreaView style={styles.modalSafe}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Filtre avansate</Text>
            <Pressable onPress={() => setShowFilters(false)} style={styles.modalClose}>
              <MaterialCommunityIcons name="close" size={24} color={colors.ink} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={styles.modalContent}>
            
            <Text style={styles.modalLabel}>Categorie</Text>
            <View style={styles.modalChips}>
              {["Toate", ...categories].map((item) => (
                <Pressable key={item} onPress={() => setCategory(item)} style={[styles.chip, category === item && styles.chipActive]}>
                  <Text style={[styles.chipText, category === item && styles.chipTextActive]}>{item}</Text>
                </Pressable>
              ))}
            </View>

            <Text style={styles.modalLabel}>Distanță</Text>
            <View style={styles.modalChips}>
              {distanceFilters.map((item) => (
                <Pressable key={item} onPress={() => setDistance(item)} style={[styles.chip, distance === item && styles.chipActive]}>
                  <Text style={[styles.chipText, distance === item && styles.chipTextActive]}>{item}</Text>
                </Pressable>
              ))}
            </View>

            {!neighbor && (
              <>
                <Text style={styles.modalLabel}>Buget</Text>
                <View style={styles.modalChips}>
                  {budgetFilters.map((item) => (
                    <Pressable key={item} onPress={() => setBudget(item)} style={[styles.chip, budget === item && styles.chipActive]}>
                      <Text style={[styles.chipText, budget === item && styles.chipTextActive]}>{item}</Text>
                    </Pressable>
                  ))}
                </View>
              </>
            )}

            <Pressable onPress={() => setShowFilters(false)} style={styles.modalApply}>
              <Text style={styles.modalApplyText}>Aplică filtre</Text>
            </Pressable>
            {(activeFiltersCount > 0 || urgency !== "Toate") && (
              <Pressable onPress={() => { setUrgency("Toate"); setCategory("Toate"); setDistance("Orice"); setBudget("Orice"); }} style={styles.modalReset}>
                <Text style={styles.modalResetText}>Resetează tot</Text>
              </Pressable>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>

    </>
  );
}

const styles = StyleSheet.create({
  mapSafe: { flex: 1, backgroundColor: colors.cream },
  mapHeaderWrap: { paddingHorizontal: 18, paddingTop: 12 },
  mapContainer: { flex: 1, position: "relative" },
  map: { flex: 1 },
  mapHelpWrap: { position: "absolute", top: 12, left: 12, right: 64, alignItems: "flex-start" },
  mapHelp: { flexDirection: "row", alignItems: "center", gap: 7, backgroundColor: colors.paper, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 5, elevation: 3 },
  mapHelpText: { flexShrink: 1, color: colors.ink, fontSize: 11, lineHeight: 15, fontWeight: "800" },
  mapEmptyCard: { width: "100%", backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 14, padding: 14, marginTop: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 5, elevation: 3 },
  mapEmptyTitle: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  mapEmptyText: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 3 },
  mapEmptyButton: { alignSelf: "flex-start", minHeight: 34, justifyContent: "center", paddingHorizontal: 11, borderRadius: 10, backgroundColor: colors.ink, marginTop: 10 },
  mapEmptyButtonText: { color: colors.paper, fontSize: 11, fontWeight: "900" },
  androidNearbyContent: { padding: 18, paddingBottom: 40, gap: 10 },
  androidNearbyNotice: { flexDirection: "row", gap: 12, padding: 14, borderRadius: 16, backgroundColor: colors.mint, borderWidth: 1, borderColor: "#B7D7C0" },
  androidNearbyIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center" },
  androidNearbyCopy: { flex: 1 },
  androidNearbyTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" },
  androidNearbyText: { color: colors.mintDark, fontSize: 11, lineHeight: 16, marginTop: 3 },
  androidNearbyRow: { minHeight: 76, flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 15, padding: 12 },
  androidNearbyPin: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.dangerSoft, alignItems: "center", justifyContent: "center" },
  androidNearbyRowCopy: { flex: 1 },
  androidNearbyCategory: { color: colors.ink, fontSize: 11, fontWeight: "900" },
  androidNearbyDescription: { color: colors.text, fontSize: 11, lineHeight: 16, marginTop: 2 },
  androidNearbyMeta: { color: colors.muted, fontSize: 10, fontWeight: "700", marginTop: 4 },
  mapCardOverlay: { position: "absolute", bottom: 20, left: 16, right: 16, backgroundColor: "transparent", padding: 0, zIndex: 100 },
  myLocationBtnNative: { position: "absolute", top: 12, right: 12, backgroundColor: colors.paper, width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.15, shadowRadius: 6, elevation: 4 },
  approximateLocationNote: { backgroundColor: colors.mint, borderRadius: 12, padding: 10, flexDirection: "row", alignItems: "center", gap: 7, marginTop: 8 },
  approximateLocationText: { color: colors.mintDark, fontSize: 12, lineHeight: 17, flex: 1, fontWeight: "700" },
  toggleGroup: { flexDirection: "row", backgroundColor: colors.paper, borderRadius: 999, borderWidth: 1, borderColor: colors.line, overflow: "hidden" },
  toggleBtn: { minHeight: 44, paddingHorizontal: 14, paddingVertical: 8, justifyContent: "center", alignItems: "center" },
  toggleBtnActive: { backgroundColor: colors.ink },
  newButton: { backgroundColor: colors.ink, borderRadius: 17, padding: 14, flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 18 }, newIcon: { width: 44, height: 44, borderRadius: 13, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" }, newCopy: { flex: 1 }, newTitle: { color: colors.paper, fontSize: 14, fontWeight: "900" }, newText: { color: "#D5DDD7", fontSize: 12, lineHeight: 17, marginTop: 3 },
  filtersWrapper: { marginBottom: 18 },
  filters: { flexDirection: "row", gap: 7, paddingRight: 20 }, filter: { minHeight: 44, flexDirection: "row", alignItems: "center", paddingHorizontal: 13, paddingVertical: 8, borderRadius: 999, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line }, filterActive: { backgroundColor: colors.ink, borderColor: colors.ink }, filterText: { color: colors.muted, fontSize: 12, fontWeight: "700" }, filterTextActive: { color: colors.paper }, countRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 10 }, count: { color: colors.ink, fontSize: 12, fontWeight: "800" }, order: { color: colors.muted, fontSize: 12 }, empty: { textAlign: "center", color: colors.muted, paddingVertical: 50 },
  
  modalSafe: { flex: 1, backgroundColor: colors.cream },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 18, borderBottomWidth: 1, borderBottomColor: colors.line },
  modalTitle: { color: colors.ink, fontSize: 18, fontWeight: "900" },
  modalClose: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  modalContent: { padding: 18, paddingBottom: 40 },
  modalLabel: { color: colors.ink, fontSize: 13, fontWeight: "800", marginBottom: 10, marginTop: 20 },
  modalChips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { minHeight: 44, justifyContent: "center", backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 99, paddingHorizontal: 14, paddingVertical: 10 },
  chipActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  chipText: { color: colors.muted, fontSize: 12, fontWeight: "700" },
  chipTextActive: { color: colors.paper },
  modalApply: { backgroundColor: colors.ink, borderRadius: 14, paddingVertical: 16, alignItems: "center", marginTop: 40 },
  modalApplyText: { color: colors.paper, fontSize: 14, fontWeight: "900" },
  modalReset: { minHeight: 44, alignItems: "center", justifyContent: "center", marginTop: 15, paddingVertical: 10 },
  modalResetText: { color: colors.accentDark, fontSize: 12, fontWeight: "800" },
});
