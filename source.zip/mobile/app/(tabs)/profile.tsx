import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { useState } from "react";
import { Alert, Image, Modal, Pressable, StyleSheet, Text, View } from "react-native";
import { AppHeader } from "@/components/AppHeader";
import { Screen } from "@/components/Screen";
import { useProvider } from "@/src/ProviderContext";
import { useAuth } from "@/src/AuthContext";
import { colors, shadow } from "@/src/theme";
import { updateProviderPreferences } from "@/src/api";
import { pickImageFromGallery } from "@/src/mediaPicker";
import { showAppAlert } from "@/src/alerts";

export default function ProfileScreen() {
  const { provider, isDemo, setProvider, signOut, deleteAccount, addPasskey, passkeySupported } = useAuth();
  const { notificationEnabled, notificationMessage, toggleNotifications, billing, source } = useProvider();
  const [showAvatarModal, setShowAvatarModal] = useState(false);

  if (!provider) return null;
  const activeRating = provider.clientRating;
  const activeReviewCount = provider.clientReviewCount;
  const activeCompleted = provider.clientCompletedJobs;
  const initials = provider.name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toLocaleUpperCase("ro-RO");
  const rows = [
    { icon: "map-marker-outline" as const, label: "Oraș", value: provider.city },
    { icon: "shield-check-outline" as const, label: "Telefon", value: "Verificat" },
  ];
  const avatarUri = provider.avatarUrl;

  async function createPasskey() {
    try {
      await addPasskey();
      Alert.alert("Acces rapid activat", "Data viitoare poți intra pe acest dispozitiv cu Face ID, Touch ID, amprenta sau codul telefonului, fără SMS.");
    } catch (error) {
      Alert.alert("Passkey indisponibilă", error instanceof Error ? error.message : "Passkey-ul nu a putut fi creat. Poți folosi în continuare SMS-ul.");
    }
  }

  async function pickAvatar() {
    const uri = await pickImageFromGallery();
    if (uri) {
      if (isDemo) { setProvider({ ...provider!, avatarUrl: uri }); return; }
      try {
        const result = await updateProviderPreferences({ avatarUrl: uri });
        setProvider(result.provider);
        setShowAvatarModal(false);
      }
      catch { Alert.alert("Eroare", "Fotografia nu a putut fi salvată."); }
    }
  }

  async function deleteAvatar() {
    if (isDemo) { setProvider({ ...provider!, avatarUrl: null }); return; }
    try {
      const result = await updateProviderPreferences({ avatarUrl: null });
      setProvider(result.provider);
      setShowAvatarModal(false);
    }
    catch { Alert.alert("Eroare", "Fotografia nu a putut fi ștearsă."); }
  }

  return (
    <Screen>
      <AppHeader title="Profilul meu" source={source} />

      {/* Full-screen Avatar Preview Modal */}
      <Modal visible={showAvatarModal} transparent animationType="fade" onRequestClose={() => setShowAvatarModal(false)}>
        <View style={styles.modalOverlay}>
          <Pressable style={styles.modalCloseBtn} onPress={() => setShowAvatarModal(false)}>
            <MaterialCommunityIcons name="close" size={26} color={colors.paper} />
          </Pressable>

          {avatarUri ? (
            <Image source={{ uri: avatarUri }} style={styles.fullAvatarImage} resizeMode="contain" />
          ) : (
            <View style={[styles.fullAvatarImage, styles.fullAvatarFallback]}><Text style={styles.fullAvatarText}>{initials || "RA"}</Text></View>
          )}

          <View style={{ flexDirection: 'row', gap: 15 }}>
            <Pressable style={styles.changeInModalBtn} onPress={() => { setShowAvatarModal(false); void pickAvatar(); }}>
              <MaterialCommunityIcons name="camera" size={18} color={colors.paper} />
              <Text style={styles.changeInModalText}>Schimbă fotografia</Text>
            </Pressable>
            {avatarUri ? (
              <Pressable style={[styles.changeInModalBtn, { backgroundColor: colors.dangerSoft }]} onPress={() => { setShowAvatarModal(false); void deleteAvatar(); }}>
                <MaterialCommunityIcons name="trash-can" size={18} color={colors.accentDark} />
                <Text style={[styles.changeInModalText, { color: colors.accentDark }]}>Șterge</Text>
              </Pressable>
            ) : null}
          </View>
          <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11, marginTop: 20 }}>Aceasta este fotografia profilului tău.</Text>
        </View>
      </Modal>

      <View style={styles.profileCard}>
        <View style={styles.avatarWrap}>
          <Pressable onPress={() => setShowAvatarModal(true)}>
            {avatarUri ? (
              <Image source={{ uri: avatarUri }} style={styles.avatarImage} resizeMode="cover" />
            ) : (
              <View style={styles.avatar}><Text style={styles.avatarText}>{initials || "RA"}</Text></View>
            )}
          </Pressable>
          <Pressable onPress={() => void pickAvatar()} style={styles.avatarCameraBadge}>
            <MaterialCommunityIcons name="camera" size={12} color={colors.paper} />
          </Pressable>
          {provider.professionalEnabled && provider.isVerified ? (
            <View style={styles.verified}>
              <MaterialCommunityIcons name="check" size={11} color={colors.paper} />
            </View>
          ) : null}
        </View>
        <Text style={styles.name}>{provider.name}</Text>
        <Text style={styles.location}>{provider.city} · rază {provider.radiusKm} km</Text>
        {activeReviewCount > 0 ? <View style={styles.rating}><MaterialCommunityIcons name="star" size={16} color="#E4A515" /><Text style={styles.ratingValue}>{activeRating ? (activeRating / 10).toFixed(1).replace(".", ",") : "Nou"}</Text><Text style={styles.reviews}>({activeReviewCount} recenzii) · {activeCompleted} cereri finalizate</Text></View> : null}

        {provider.professionalEnabled && provider.kycStatus === "unverified" ? (
          <Pressable style={styles.kycBanner} onPress={() => router.push("/kyc")}>
            <MaterialCommunityIcons name="shield-alert-outline" size={20} color="#D84315" />
            <View style={styles.kycBannerText}>
              <Text style={styles.kycBannerTitle}>Verifică profilul de lucru</Text>
              <Text style={styles.kycBannerDesc}>Trimite cererea, iar noi îți spunem ce este necesar.</Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={20} color="#D84315" />
          </Pressable>
        ) : provider.professionalEnabled && provider.kycStatus === "pending" ? (
          <View style={[styles.kycBanner, { backgroundColor: "#FFF2CE", borderColor: "#F5D37B" }]}>
            <MaterialCommunityIcons name="clock-outline" size={20} color="#8A5A00" />
            <View style={styles.kycBannerText}>
              <Text style={[styles.kycBannerTitle, { color: "#8A5A00" }]}>Verificare în curs</Text>
              <Text style={[styles.kycBannerDesc, { color: "#8A5A00" }]}>Cererea ta este în curs de verificare.</Text>
            </View>
          </View>
        ) : null}

        <Pressable style={styles.editProfileButton} onPress={() => router.push("/onboarding")}><MaterialCommunityIcons name="pencil-outline" size={15} color={colors.ink} /><Text style={styles.editProfileText}>Editează datele personale</Text></Pressable>
        <Pressable style={styles.workProfileButton} onPress={() => router.push("/profiles" as never)}>
          <MaterialCommunityIcons name="account-multiple-outline" size={18} color={colors.ink} />
          <View style={{ flex: 1 }}>
            <Text style={styles.workProfileTitle}>Profiluri și echipe</Text>
            <Text style={styles.workProfileText}>Persoană, PFA sau firmă · poze și recenzii separate</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={20} color={colors.muted} />
        </Pressable>
        <Pressable style={styles.workProfileButton} onPress={() => router.push("/work-profile" as never)}>
          <MaterialCommunityIcons name="briefcase-edit-outline" size={17} color={colors.paper} />
          <View style={styles.workProfileCopy}>
            <Text style={styles.workProfileTitle}>{provider.professionalEnabled ? "Profilul tău de lucru" : "Vrei să primești lucrări?"}</Text>
            <Text style={styles.workProfileText}>{provider.professionalEnabled ? "Servicii, tarif, echipament și forma juridică" : "Configurează separat ce poți face și cum lucrezi"}</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={20} color={colors.paper} />
        </Pressable>
      </View>

      {activeReviewCount > 0 ? (
        <Pressable style={styles.ratingOverview} onPress={() => router.push("/reviews")}>
          <View style={styles.ratingOverviewIcon}><MaterialCommunityIcons name="star-outline" size={20} color="#A96D00" /></View>
          <View style={styles.ratingOverviewCopy}>
            <Text style={styles.ratingOverviewTitle}>Evaluările tale</Text>
            <Text style={styles.ratingOverviewText}>{(activeRating / 10).toFixed(1).replace(".", ",")} din {activeReviewCount} evaluări · {activeCompleted} lucrări finalizate</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={20} color={colors.muted} />
        </Pressable>
      ) : null}

      <Text style={styles.sectionLabel}>CONT</Text>
      <View style={styles.settings}>
        {rows.map((row) => (
          <Pressable style={styles.row} key={row.label} onPress={() => router.push("/onboarding")}>
            <View style={styles.rowIcon}><MaterialCommunityIcons name={row.icon} size={19} color={colors.ink} /></View>
            <Text style={styles.rowLabel}>{row.label}</Text><Text style={styles.rowValue}>{row.value}</Text><MaterialCommunityIcons name="chevron-right" size={20} color="#A4ABA5" />
          </Pressable>
        ))}
      </View>

      <Text style={styles.sectionLabel}>PREFERINȚE</Text>
      <View style={styles.settings}>
        <Pressable style={styles.row} onPress={() => void toggleNotifications()}>
          <View style={[styles.rowIcon, notificationEnabled && styles.rowIconActive]}><MaterialCommunityIcons name="bell-outline" size={19} color={notificationEnabled ? colors.mintDark : colors.ink} /></View>
          <Text style={styles.rowLabel}>Notificări</Text><Text style={[styles.rowValue, notificationEnabled && styles.activeText]}>{notificationEnabled ? "Active" : "Oprite"}</Text><MaterialCommunityIcons name="chevron-right" size={20} color="#A4ABA5" />
        </Pressable>
        {passkeySupported ? (
          <Pressable style={styles.row} onPress={() => void createPasskey()}>
            <View style={[styles.rowIcon, styles.rowIconActive]}><MaterialCommunityIcons name="key-variant" size={19} color={colors.mintDark} /></View>
            <View style={styles.preferenceCopy}>
              <Text style={styles.preferenceLabel}>Activează acces rapid</Text>
              <Text style={styles.preferenceHint}>Reintri pe acest telefon fără cod SMS</Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={20} color="#A4ABA5" />
          </Pressable>
        ) : null}
        <Pressable style={styles.row} onPress={() => showAppAlert("Costuri și comisioane", billing.betaFree ? "Momentan, primirea lucrărilor este gratuită. Nu există taxe ascunse sau abonamente." : "Taxa se aplică numai dacă oferta ta este acceptată.")}>
          <View style={styles.rowIcon}><MaterialCommunityIcons name="wallet-outline" size={19} color={colors.ink} /></View>
          <Text style={styles.rowLabel}>Cost pentru lucrări</Text><Text style={styles.rowValue}>{billing.betaFree ? "Gratuit" : `${(billing.pendingBani / 100).toFixed(0)} lei`}</Text><MaterialCommunityIcons name="chevron-right" size={20} color="#A4ABA5" />
        </Pressable>
      </View>

      <Text style={styles.sectionLabel}>AJUTOR ȘI CONFIDENȚIALITATE</Text>
      <View style={styles.settings}>
        <Pressable style={styles.row} onPress={() => router.push("/support" as never)}><View style={[styles.rowIcon, styles.rowIconActive]}><MaterialCommunityIcons name="chat-question-outline" size={19} color={colors.mintDark} /></View><Text style={styles.rowLabel}>Ajutor și suport</Text><MaterialCommunityIcons name="chevron-right" size={20} color="#A4ABA5" /></Pressable>
        <Pressable style={styles.row} onPress={() => router.push({ pathname: "/legal/[document]", params: { document: "safety" } })}><View style={[styles.rowIcon, styles.rowIconActive]}><MaterialCommunityIcons name="shield-check-outline" size={19} color={colors.mintDark} /></View><Text style={styles.rowLabel}>Siguranță</Text><MaterialCommunityIcons name="chevron-right" size={20} color="#A4ABA5" /></Pressable>
        <Pressable style={styles.row} onPress={() => router.push({ pathname: "/legal/[document]", params: { document: "community" } })}><View style={styles.rowIcon}><MaterialCommunityIcons name="account-group-outline" size={19} color={colors.ink} /></View><Text style={styles.rowLabel}>Regulile comunității</Text><MaterialCommunityIcons name="chevron-right" size={20} color="#A4ABA5" /></Pressable>
        <Pressable style={styles.row} onPress={() => router.push({ pathname: "/legal/[document]", params: { document: "privacy" } })}><View style={styles.rowIcon}><MaterialCommunityIcons name="lock-outline" size={19} color={colors.ink} /></View><Text style={styles.rowLabel}>Confidențialitate</Text><MaterialCommunityIcons name="chevron-right" size={20} color="#A4ABA5" /></Pressable>
      </View>
      {notificationMessage ? <Text style={styles.note}>{notificationMessage}</Text> : null}
      <View style={styles.billingNote}><MaterialCommunityIcons name="information-outline" size={18} color={colors.mintDark} /><Text style={styles.billingText}>{billing.betaFree ? "Momentan, primirea lucrărilor este gratuită." : billing.freeJobsRemaining > 0 ? `Mai ai ${billing.freeJobsRemaining} lucrări câștigate gratuite.` : "Taxa se aplică numai când oferta ta este aleasă."}</Text></View>
      <Pressable onPress={() => void signOut()} style={styles.signOut}><MaterialCommunityIcons name="logout" size={18} color={colors.accentDark} /><Text style={styles.signOutText}>Ieși din cont</Text></Pressable>
      <Pressable onPress={() => showAppAlert("Ștergi contul?", "Numărul de telefon, profilul și dispozitivele de notificare vor fi eliminate. Acțiunea nu poate fi anulată.", [{ text: "Renunță", style: "cancel" }, { text: "Șterge definitiv", style: "destructive", onPress: () => void deleteAccount() }])} style={styles.deleteAccount}><Text style={styles.deleteAccountText}>Șterge definitiv contul</Text></Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  profileCard: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 21, alignItems: "center", padding: 18, marginBottom: 22, ...shadow },
  avatar: { width: 66, height: 66, borderRadius: 22, backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
  avatarWrap: { position: "relative", width: 66, height: 66, marginBottom: 4 },
  avatarImage: { width: 66, height: 66, borderRadius: 22, backgroundColor: colors.accent },
  avatarCameraBadge: { position: "absolute", bottom: -2, right: -2, width: 22, height: 22, borderRadius: 11, backgroundColor: colors.ink, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: colors.paper },
  avatarText: { color: colors.paper, fontSize: 21, fontWeight: "900" },
  verified: { position: "absolute", right: -3, top: -3, width: 22, height: 22, borderRadius: 11, backgroundColor: "#2C82E0", borderWidth: 2, borderColor: colors.paper, alignItems: "center", justifyContent: "center" },
  name: { color: colors.ink, fontSize: 20, fontWeight: "800", marginTop: 14 },
  location: { color: colors.muted, fontSize: 13, marginTop: 4 },
  rating: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 12 },
  ratingValue: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  reviews: { color: colors.muted, fontSize: 12 },
  kycBanner: { flexDirection: "row", alignItems: "center", backgroundColor: "#FCE4D6", borderWidth: 1, borderColor: "#F7C3A6", padding: 12, borderRadius: 12, marginHorizontal: 16, marginBottom: 15 },
  kycBannerText: { flex: 1, marginHorizontal: 10 },
  kycBannerTitle: { color: "#D84315", fontSize: 13, fontWeight: "800" },
  kycBannerDesc: { color: "#D84315", fontSize: 11, marginTop: 2 },
  editProfileButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, height: 44, backgroundColor: colors.cream, borderRadius: 11, marginHorizontal: 10, paddingVertical: 7, marginTop: 12 },
  editProfileText: { color: colors.ink, fontSize: 13, fontWeight: "800" },
  workProfileButton: { flexDirection: "row", alignItems: "center", gap: 10, minHeight: 62, backgroundColor: colors.ink, borderRadius: 13, marginHorizontal: 10, paddingHorizontal: 14, marginTop: 9 },
  workProfileCopy: { flex: 1 },
  workProfileTitle: { color: colors.paper, fontSize: 14, fontWeight: "900" },
  workProfileText: { color: "#C3D0C7", fontSize: 12, lineHeight: 16, marginTop: 3 },
  changePhotoButton: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.cream, borderBottomWidth: 1, borderBottomColor: colors.line, borderRadius: 99, paddingHorizontal: 13, paddingVertical: 7, marginTop: 10 },
  changePhotoText: { color: colors.ink, fontSize: 10, fontWeight: "800" },
  clientIdentity: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.mint, borderRadius: 99, paddingHorizontal: 10, paddingVertical: 7, marginTop: 12 }, clientIdentityText: { color: colors.mintDark, fontSize: 9, fontWeight: "800" },
  sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8, marginTop: 15 },
  sectionLabel: { color: colors.muted, fontSize: 11, fontWeight: "900", letterSpacing: 1, marginLeft: 4, marginBottom: 7 },
  allLink: { color: colors.accent, fontSize: 11, fontWeight: "800", marginRight: 4 },
  settings: { backgroundColor: colors.paper, borderRadius: 17, borderWidth: 1, borderColor: colors.line, overflow: "hidden", marginBottom: 20 },
  row: { minHeight: 57, flexDirection: "row", alignItems: "center", paddingHorizontal: 14, borderBottomWidth: 1, borderBottomColor: colors.line },
  rowIcon: { width: 35, height: 35, borderRadius: 11, backgroundColor: "#EEF0EC", alignItems: "center", justifyContent: "center", marginRight: 11 },
  rowIconActive: { backgroundColor: colors.mint },
  rowLabel: { flex: 1, color: colors.ink, fontSize: 14, fontWeight: "700" },
  preferenceCopy: { flex: 1, paddingRight: 8 },
  // rowLabel are flex: 1 pentru rândurile cu o valoare la dreapta. Într-un
  // container vertical ar împinge însă explicația în partea de jos a rândului.
  preferenceLabel: { color: colors.ink, fontSize: 14, fontWeight: "700" },
  preferenceHint: { color: colors.muted, fontSize: 12, lineHeight: 16, marginTop: 2 },
  rowValue: { color: colors.muted, fontSize: 13 },
  activeText: { color: colors.mintDark, fontWeight: "800" },
  note: { color: colors.muted, fontSize: 10, lineHeight: 15, marginTop: -15, marginBottom: 20, paddingHorizontal: 4 },
  billingNote: { backgroundColor: colors.mint, borderRadius: 14, padding: 13, flexDirection: "row", alignItems: "flex-start", gap: 9 },
  billingText: { color: colors.mintDark, fontSize: 12, lineHeight: 17, flex: 1, fontWeight: "600" },
  signOut: { marginTop: 18, height: 48, borderRadius: 13, borderWidth: 1, borderColor: "#F0C8BF", backgroundColor: colors.dangerSoft, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  signOutText: { color: colors.accentDark, fontSize: 13, fontWeight: "800" },
  deleteAccount: { height: 42, alignItems: "center", justifyContent: "center" },
  deleteAccountText: { color: colors.muted, fontSize: 10, fontWeight: "700", textDecorationLine: "underline" },
  reviewsList: { gap: 12, marginBottom: 26 },
  ratingOverview: { minHeight: 76, marginBottom: 26, padding: 14, borderWidth: 1, borderColor: colors.line, borderRadius: 17, backgroundColor: colors.paper, flexDirection: "row", alignItems: "center", gap: 11 },
  ratingOverviewIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: "#FFF2CE", alignItems: "center", justifyContent: "center" },
  ratingOverviewCopy: { flex: 1 },
  ratingOverviewTitle: { color: colors.ink, fontSize: 12, fontWeight: "900" },
  ratingOverviewText: { color: colors.muted, fontSize: 9, lineHeight: 14, marginTop: 3 },
  reviewCard: { backgroundColor: colors.paper, borderRadius: 17, padding: 16, borderWidth: 1, borderColor: colors.line },
  reviewHeader: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  reviewAvatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center", marginRight: 10 },
  reviewAvatarText: { color: colors.mintDark, fontSize: 13, fontWeight: "900" },
  reviewAuthor: { flex: 1 },
  reviewAuthorName: { color: colors.ink, fontSize: 13, fontWeight: "800" },
  reviewAuthorDate: { color: colors.muted, fontSize: 10, marginTop: 2 },
  reviewStars: { flexDirection: "row", gap: 2 },
  reviewText: { color: colors.ink, fontSize: 12, lineHeight: 18, fontStyle: "italic" },
  modalOverlay: { position: "absolute", top: 0, bottom: 0, left: 0, right: 0, backgroundColor: "rgba(0,0,0,0.92)", zIndex: 999, alignItems: "center", justifyContent: "center", padding: 20 },
  modalCloseBtn: { position: "absolute", top: 50, right: 20, zIndex: 1000, padding: 10, backgroundColor: "rgba(0,0,0,0.5)", borderRadius: 20 },
  fullAvatarImage: { width: 280, height: 280, borderRadius: 140, marginBottom: 30, borderWidth: 3, borderColor: colors.paper },
  fullAvatarFallback: { backgroundColor: colors.accent, alignItems: "center", justifyContent: "center" },
  fullAvatarText: { color: colors.paper, fontSize: 72, fontWeight: "900" },
  changeInModalBtn: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.accent, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14 },
  changeInModalText: { color: colors.paper, fontSize: 13, fontWeight: "800" },
});
