import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useState } from "react";
import { Pressable, RefreshControl, StyleSheet, Text, View } from "react-native";
import { AppHeader } from "@/components/AppHeader";
import { MyRequestCard } from "@/components/MyRequestCard";
import { Screen } from "@/components/Screen";
import { fetchMyRequests } from "@/src/api";
import { useAuth } from "@/src/AuthContext";
import { useMode } from "@/src/ModeContext";
import { useProvider } from "@/src/ProviderContext";
import { colors, shadow } from "@/src/theme";
import { MyRequest } from "@/src/types";

export default function DashboardScreen() {
  const { provider } = useAuth();
  const { setActiveMode } = useMode();
  const { source } = useProvider();
  const [myRequests, setMyRequests] = useState<MyRequest[]>([]);
  const [mineLoading, setMineLoading] = useState(false);

  const refreshMine = useCallback(async () => {
    setMineLoading(true);
    try { setMyRequests(await fetchMyRequests()); } catch { setMyRequests([]); }
    finally { setMineLoading(false); }
  }, []);
  useFocusEffect(useCallback(() => {
    setActiveMode("client");
    void refreshMine();
  }, [refreshMine, setActiveMode]));

  return (
      <Screen refreshControl={<RefreshControl refreshing={mineLoading} onRefresh={refreshMine} tintColor={colors.accent} />}>
        <AppHeader eyebrow="Bun venit" title={provider?.clientName ?? provider?.name ?? "RezolvatAzi"} source={source} />

        <View style={styles.cleanHero}>
          <Text style={styles.cleanHeroTitle}>Ce ai nevoie să rezolvi?</Text>
          <Text style={styles.cleanHeroText}>Descrie în cuvintele tale. Te ghidăm apoi, pas cu pas.</Text>
          <Pressable onPress={() => router.push("/new-request" as never)} style={({ pressed }) => [styles.cleanInput, pressed && styles.pressed]}>
            <Text style={styles.cleanPlaceholder}>Ex: Am nevoie de ajutor la mutare mâine...</Text>
            <MaterialCommunityIcons name="arrow-right" size={21} color={colors.paper} style={styles.cleanArrow} />
          </Pressable>
          <View style={styles.cleanPrivacy}>
            <MaterialCommunityIcons name="shield-lock-outline" size={16} color={colors.mintDark} />
            <Text style={styles.cleanPrivacyText}>Numărul și adresa exactă rămân private.</Text>
          </View>
        </View>

        {myRequests.length > 0 && <View style={styles.sectionRow}><Text style={styles.sectionTitle}>În desfășurare</Text><Pressable onPress={() => router.push("/(tabs)/activity")}><Text style={styles.allLink}>Vezi activitatea</Text></Pressable></View>}
        {myRequests.slice(0, 1).map((request) => <MyRequestCard request={request} key={request.id} />)}

        <Pressable
          onPress={() => {
            if (provider?.professionalEnabled) {
              setActiveMode("professional");
              router.push("/(tabs)/requests");
            } else {
              router.push("/work-profile");
            }
          }}
          style={({ pressed }) => [styles.workEntry, pressed && styles.pressed]}
        >
          <View style={styles.workEntryIcon}><MaterialCommunityIcons name="briefcase-outline" size={21} color={colors.ink} /></View>
          <View style={styles.workEntryCopy}>
            <Text style={styles.workEntryTitle}>Cauți lucrări?</Text>
            <Text style={styles.workEntryText}>{provider?.professionalEnabled ? "Vezi oportunitățile potrivite pentru tine." : "Configurează separat ce poți face și cum lucrezi."}</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={22} color={colors.muted} />
        </Pressable>
      </Screen>
  );
}

const styles = StyleSheet.create({
  cleanHero: { backgroundColor: colors.paper, borderRadius: 22, borderWidth: 1, borderColor: colors.line, padding: 22, marginBottom: 30 },
  cleanHeroTitle: { color: colors.ink, fontSize: 29, lineHeight: 35, fontWeight: "900", letterSpacing: -0.9 },
  cleanHeroText: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 8 },
  cleanInput: { minHeight: 88, borderRadius: 16, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.cream, marginTop: 24, paddingLeft: 16, paddingRight: 9, flexDirection: "row", alignItems: "center", gap: 12 },
  cleanPlaceholder: { flex: 1, color: colors.muted, fontSize: 15, lineHeight: 21 },
  cleanArrow: { backgroundColor: colors.accent, borderRadius: 13, padding: 11, overflow: "hidden" },
  cleanPrivacy: { flexDirection: "row", alignItems: "center", gap: 7, marginTop: 15 },
  cleanPrivacyText: { color: colors.muted, fontSize: 12 },
  workEntry: { minHeight: 82, borderTopWidth: 1, borderTopColor: colors.line, marginTop: 30, paddingVertical: 18, flexDirection: "row", alignItems: "center", gap: 13 },
  workEntryIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.mint, alignItems: "center", justifyContent: "center" },
  workEntryCopy: { flex: 1 },
  workEntryTitle: { color: colors.ink, fontSize: 15, fontWeight: "900" },
  workEntryText: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  pressed: { opacity: 0.72 },
  intentHero: { backgroundColor: colors.ink, borderRadius: 26, padding: 19, marginBottom: 14, overflow: "hidden", ...shadow },
  intentTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  aiBadge: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: colors.lime, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 6 },
  aiBadgeText: { color: colors.ink, fontSize: 8, fontWeight: "900", letterSpacing: 0.7 },
  cityLabel: { color: "#A9BBB0", fontSize: 9, fontWeight: "700" },
  intentTitle: { color: colors.paper, fontSize: 28, lineHeight: 33, fontWeight: "900", letterSpacing: -0.9, marginTop: 20 },
  intentText: { color: "#B7C8BD", fontSize: 12, lineHeight: 18, marginTop: 7, maxWidth: 420 },
  intentInput: { backgroundColor: colors.paper, minHeight: 96, borderRadius: 19, marginTop: 18, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  intentInputIcon: { width: 39, height: 39, borderRadius: 12, backgroundColor: colors.dangerSoft, alignItems: "center", justifyContent: "center" },
  intentInputCopy: { flex: 1 },
  intentPlaceholder: { color: colors.ink, fontSize: 11, lineHeight: 16, fontWeight: "800" },
  intentHint: { color: colors.muted, fontSize: 9, marginTop: 4 },
  intentArrow: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.lime, alignItems: "center", justifyContent: "center" },
  quickLabel: { color: "#81948A", fontSize: 8, fontWeight: "900", letterSpacing: 1, marginTop: 17 },
  quickActions: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 8 },
  quickAction: { minHeight: 35, flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 999, backgroundColor: colors.inkSoft, borderWidth: 1, borderColor: "#335345", paddingHorizontal: 10 },
  quickActionText: { color: colors.paper, fontSize: 9, fontWeight: "800" },
  promise: { backgroundColor: colors.mint, borderRadius: 18, padding: 14, flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 20 },
  promiseNumber: { width: 32, height: 32, borderRadius: 10, backgroundColor: colors.mintDark, alignItems: "center", justifyContent: "center" },
  promiseNumberText: { color: colors.paper, fontSize: 13, fontWeight: "900" },
  promiseCopy: { flex: 1 },
  promiseTitle: { color: colors.ink, fontSize: 11, fontWeight: "900" },
  promiseText: { color: colors.mintDark, fontSize: 9, lineHeight: 14, marginTop: 2 },
  clientSectionRow: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 10 },
  clientSectionTitle: { color: colors.ink, fontSize: 17, fontWeight: "900" },
  statusRail: { backgroundColor: colors.paper, borderRadius: 19, borderWidth: 1, borderColor: colors.line, padding: 14, flexDirection: "row", alignItems: "center", marginBottom: 20, ...shadow },
  statusRailItem: { flex: 1, alignItems: "center" },
  statusRailDivider: { width: 1, alignSelf: "stretch", backgroundColor: colors.line, marginHorizontal: 8 },
  statusRailIcon: { width: 35, height: 35, borderRadius: 11, alignItems: "center", justifyContent: "center", marginBottom: 7 },
  statusRailValue: { color: colors.ink, fontSize: 18, fontWeight: "900" },
  statusRailLabel: { color: colors.muted, fontSize: 9, marginTop: 1, fontWeight: "600" },

  pulseCard: { backgroundColor: colors.mint, borderRadius: 16, padding: 16, flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 16 },
  pulseIcon: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.paper, alignItems: "center", justifyContent: "center", ...shadow },
  pulseTitle: { color: colors.mintDark, fontSize: 12, fontWeight: "900", textTransform: "uppercase", letterSpacing: 0.5 },
  pulseText: { color: colors.ink, fontSize: 13, lineHeight: 18, marginTop: 2, fontWeight: "500" },

  shortcutsGrid: { flexDirection: "row", gap: 12, marginBottom: 24 },
  shortcutCard: { flex: 1, backgroundColor: colors.paper, borderRadius: 18, padding: 16, borderWidth: 1, borderColor: colors.line, ...shadow },
  shortcutIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", marginBottom: 12 },
  shortcutTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" },
  shortcutSubtitle: { color: colors.muted, fontSize: 11, marginTop: 4 },

  stats: { flexDirection: "row", gap: 10, marginBottom: 24 },
  stat: { flex: 1, backgroundColor: colors.paper, borderRadius: 16, padding: 14, alignItems: "center", borderWidth: 1, borderColor: colors.line, ...shadow },
  statValue: { color: colors.ink, fontSize: 18, fontWeight: "900", marginTop: 6 },
  statLabel: { color: colors.muted, fontSize: 10, marginTop: 2, textAlign: "center", fontWeight: "600" },

  smartCta: { backgroundColor: colors.paper, borderRadius: 16, padding: 24, alignItems: "center", borderWidth: 1, borderColor: colors.line, borderStyle: "dashed" },
  smartCtaTitle: { color: colors.ink, fontSize: 16, fontWeight: "800", marginTop: 12 },
  smartCtaText: { color: colors.muted, fontSize: 13, textAlign: "center", marginTop: 6, lineHeight: 18 },

  activate: { backgroundColor: colors.dangerSoft, borderRadius: 16, padding: 13, flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 11 }, activateCopy: { flex: 1 }, activateTitle: { color: colors.ink, fontSize: 12, fontWeight: "900" }, activateText: { color: colors.muted, fontSize: 9, lineHeight: 14, marginTop: 3 }, activateLink: { color: colors.accent, fontSize: 9, fontWeight: "900" },
  availability: { minHeight: 126, borderRadius: 22, padding: 18, flexDirection: "row", alignItems: "center", marginBottom: 16, borderWidth: 1, ...shadow }, online: { backgroundColor: colors.ink, borderColor: colors.ink }, offline: { backgroundColor: "#E8E9E5", borderColor: "#D8DBD5" }, statusCopy: { flex: 1, paddingRight: 12 }, statusLine: { flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 10 }, statusDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#909790" }, statusDotOnline: { backgroundColor: "#67D68D" }, statusLabel: { color: colors.muted, fontSize: 9, fontWeight: "900", letterSpacing: 1.1 }, statusLabelOnline: { color: "#85E6A5" }, statusTitle: { color: colors.paper, fontSize: 20, fontWeight: "800" }, statusTitleOffline: { color: colors.ink }, statusHint: { color: "#ACB9B0", fontSize: 11, marginTop: 5 }, statusHintOffline: { color: colors.muted },
  availabilityDurations: { marginTop: -7, marginBottom: 16, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 15, padding: 12 },
  availabilityDurationsLabel: { color: colors.muted, fontSize: 9, fontWeight: "800", marginBottom: 8 },
  availabilityDurationOptions: { flexDirection: "row", gap: 7 },
  availabilityDuration: { flex: 1, minHeight: 38, borderRadius: 10, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center" },
  availabilityDurationText: { color: colors.ink, fontSize: 9, fontWeight: "900" },
  error: { backgroundColor: colors.dangerSoft, borderRadius: 14, padding: 14, flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 16 }, errorText: { color: colors.accentDark, fontSize: 11, flex: 1, lineHeight: 16 }, noticeBanner: { backgroundColor: colors.mint, borderRadius: 14, padding: 14, flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 16 }, noticeText: { color: colors.mintDark, fontSize: 12, flex: 1, lineHeight: 16 },
  notificationCard: { backgroundColor: "#FCECD4", borderRadius: 18, padding: 15, flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 16 }, notificationIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: "#F7D8A9", alignItems: "center", justifyContent: "center" }, notificationCopy: { flex: 1 }, notificationTitle: { color: colors.ink, fontSize: 13, fontWeight: "900" }, notificationText: { color: "#8A5A00", fontSize: 11, marginTop: 2, lineHeight: 15 },
  safetyCard: { backgroundColor: colors.mint, borderRadius: 18, padding: 15, flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 24 }, safetyTitle: { color: colors.mintDark, fontSize: 13, fontWeight: "900" }, safetyText: { color: colors.mintDark, fontSize: 11, marginTop: 2, lineHeight: 15 },
  sectionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 14, marginTop: 10 }, sectionKicker: { color: colors.muted, fontSize: 10, fontWeight: "900", letterSpacing: 0.5, marginBottom: 4 }, sectionTitle: { color: colors.ink, fontSize: 18, fontWeight: "900" }, allLink: { color: colors.accent, fontSize: 13, fontWeight: "800", paddingBottom: 2 },
  empty: { textAlign: "center", color: colors.muted, paddingVertical: 24 }
});
