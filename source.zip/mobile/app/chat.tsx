import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router, useLocalSearchParams } from "expo-router";
import { KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { AppChat } from "@/components/AppChat";
import { colors } from "@/src/theme";

function first(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}

export default function ChatScreen() {
  const params = useLocalSearchParams<{
    requestId?: string;
    offerId?: string;
    title?: string;
    role?: "client" | "neighbor" | "professional" | "hobby";
    preAcceptance?: string;
  }>();
  const requestId = first(params.requestId);
  const offerId = first(params.offerId) || null;
  const title = first(params.title) || "Conversație";
  const role = first(params.role) as "client" | "neighbor" | "professional" | "hobby" | undefined;

  if (!requestId) {
    return <SafeAreaView style={styles.missing}><Text style={styles.missingTitle}>Conversația nu poate fi deschisă.</Text><Pressable onPress={() => router.back()}><Text style={styles.backLink}>Înapoi</Text></Pressable></SafeAreaView>;
  }

  return (
    <SafeAreaView style={styles.safe} edges={["top", "bottom"]}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={0}>
        <View style={styles.header}>
          <Pressable accessibilityLabel="Înapoi la mesaje" onPress={() => router.back()} style={styles.back}><MaterialCommunityIcons name="arrow-left" size={23} color={colors.ink} /></Pressable>
          <View style={styles.headerCopy}><Text numberOfLines={1} style={styles.title}>{title}</Text></View>
        </View>
        <AppChat requestId={requestId} offerId={offerId} userRole={role ?? "client"} title={title} preAcceptance={first(params.preAcceptance) === "1"} standalone />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.paper },
  flex: { flex: 1 },
  header: { minHeight: 64, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: colors.line },
  back: { width: 43, height: 43, alignItems: "center", justifyContent: "center", borderRadius: 14, backgroundColor: colors.cream },
  headerCopy: { minWidth: 0, flex: 1 },
  title: { color: colors.ink, fontSize: 16, fontWeight: "900" },
  missing: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12, backgroundColor: colors.cream },
  missingTitle: { color: colors.ink, fontSize: 16, fontWeight: "800" },
  backLink: { color: colors.accent, fontWeight: "900" },
});
