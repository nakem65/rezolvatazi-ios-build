import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useLocalSearchParams } from "expo-router";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/src/theme";

const documents = {
  terms: {
    title: "Termeni de utilizare",
    intro: "RezolvatAzi este o platformă de intermediere. Nu execută lucrările și nu garantează disponibilitatea, prețul sau rezultatul unei colaborări.",
    sections: [
      ["Cont și conduită", "Folosește date reale, păstrează contul în siguranță și nu publica spam, conținut ilegal, discriminatoriu sau înșelător."],
      ["Solicitanți și prestatori", "Solicitantul publică o lucrare. Persoana, PFA-ul sau firma care răspunde trimite propria ofertă și este responsabilă pentru autorizațiile, taxele și obligațiile sale."],
      ["Oferte și colaborări", "Prețul și timpul sunt estimări ale prestatorului. Clarifică materialele, deplasarea și condițiile înainte de acceptare. RezolvatAzi nu este parte în contractul dintre utilizatori."],
      ["Suspendare", "Putem limita conturi sau conținut pentru siguranță, abuz, fraudă ori încălcarea regulilor comunității."],
    ],
  },
  privacy: {
    title: "Confidențialitate",
    intro: "Colectăm numai datele necesare pentru autentificare, potrivire, comunicare, siguranță și funcționarea serviciului.",
    sections: [
      ["Date folosite", "Număr de telefon, nume, zonă, adresa și coordonatele lucrării, zona și raza prestatorului, profiluri personale/PFA/de firmă, date opționale de facturare, membri și invitații de echipă, alocări, cereri, oferte, mesaje și atașamentele alese de tine, logo-uri, fotografii de profil și portofoliu, ratinguri, raportări, token de notificare și evenimente tehnice de securitate. Numărul invitat într-o echipă este păstrat mascat și sub forma unui identificator criptografic. Locația poate fi introdusă manual sau preluată punctual cu permisiunea ta. Microfonul este folosit numai când înregistrezi un mesaj vocal; fotografiile și filmările sunt preluate numai după ce le selectezi."],
      ["Locație și vizibilitate", "Înainte de acceptare, persoanele eligibile văd numai zona și o poziție aproximativă. Numărul și adresa exactă se deblochează numai persoanei alese. Textul adresei ori coordonatele pot fi trimise furnizorului de geocodare pentru căutare și transformare în coordonate. Locația exactă a prestatorului nu este afișată clienților."],
      ["Alte date vizibile", "Descrierea și fotografiile cererii sunt vizibile persoanelor eligibile. Mesajele text, fotografiile, filmările și mesajele vocale dintr-o conversație sunt vizibile numai clientului și prestatorului ofertei respective sau participanților acceptați ai lucrării. Chatul nu este criptat end-to-end. Evaluările confirmate pot fi publice cu numele redus; datele fiscale nu apar în feed. Nu publica acte, date bancare sau informații medicale."],
      ["Ștergere", "Din Profil poți șterge contul. Cererile active sunt închise, identificatorii direcți și textele asociate sunt eliminați, iar sesizările strict necesare prevenirii abuzului pot fi păstrate pe durata impusă de siguranță și lege."],
      ["Contact", "Pentru întrebări despre datele tale sau exercitarea drepturilor, folosește adresa publică de suport afișată în pagina de confidențialitate."],
    ],
  },
  safety: {
    title: "Siguranță",
    intro: "Dacă există pericol imediat, îndepărtează-te și sună la 112. RezolvatAzi nu înlocuiește serviciile de urgență.",
    sections: [
      ["Înainte de întâlnire", "Verifică profilul, forma juridică și ratingul relevant pentru lucrare. Nu trimite bani, coduri, copii de acte sau date bancare. Spune unei persoane de încredere unde mergi."],
      ["Lucrări cu risc", "Pentru gaz, electricitate, instalații, lucru la înălțime sau activități reglementate folosește numai profesioniști eligibili și verifică autorizațiile necesare."],
      ["În timpul colaborării", "Oprește întâlnirea dacă situația diferă de cerere sau dacă te simți presat. Folosește Raportează și Blochează; pentru amenințări sau pericol, sună la 112."],
      ["Prestatori", "Folosește profesioniști autorizați când legea sau riscul o cere. Badge-urile vor descrie separat telefonul, identitatea și calificarea verificate."],
    ],
  },
  community: {
    title: "Regulile comunității",
    intro: "Comunitatea funcționează când cererile sunt reale, ofertele sunt clare și fiecare persoană este tratată cu respect.",
    sections: [
      ["Permis", "Cererile reale, ofertele oneste, prețurile explicate, comunicarea respectuoasă și feedbackul despre o colaborare finalizată."],
      ["Interzis", "Hărțuire, discriminare, amenințări, servicii ilegale, recenzii false, fraudă, cereri care ocolesc calificările obligatorii și solicitarea de bani, date bancare sau coduri."],
      ["Raportare și blocare", "Orice cerere poate fi raportată și autorul blocat. După acceptare, clientul poate raporta persoana aleasă și opri colaborarea."],
      ["Consecințe", "Conținutul poate fi ascuns, iar accesul poate fi limitat sau închis în funcție de risc și istoricul incidentelor."],
    ],
  },
} as const;

export default function LegalDocumentScreen() {
  const { document } = useLocalSearchParams<{ document: keyof typeof documents }>();
  const content = documents[document] ?? documents.safety;
  return (
    <SafeAreaView style={styles.safe} edges={["bottom"]}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.hero}><MaterialCommunityIcons name="shield-check-outline" size={29} color={colors.mintDark} /><Text style={styles.title}>{content.title}</Text><Text style={styles.intro}>{content.intro}</Text></View>
        {content.sections.map(([title, copy]) => <View style={styles.section} key={title}><Text style={styles.sectionTitle}>{title}</Text><Text style={styles.copy}>{copy}</Text></View>)}
        <Text style={styles.updated}>Actualizat 14 septembrie 2026</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream }, content: { padding: 18, paddingBottom: 38 }, hero: { backgroundColor: colors.mint, borderRadius: 20, padding: 18, marginBottom: 13 }, title: { color: colors.ink, fontSize: 23, fontWeight: "900", marginTop: 12 }, intro: { color: colors.mintDark, fontSize: 11, lineHeight: 18, marginTop: 7 }, section: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 15, padding: 15, marginBottom: 10 }, sectionTitle: { color: colors.ink, fontSize: 13, fontWeight: "900" }, copy: { color: colors.text, fontSize: 10, lineHeight: 17, marginTop: 6 }, updated: { color: colors.muted, fontSize: 9, textAlign: "center", marginTop: 8 },
});
