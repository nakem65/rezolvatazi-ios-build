import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Keyboard, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { CityAutocompleteInput } from "@/components/CityAutocompleteInput";
import {
  createEarningProfile,
  analyzeWorkIntentRemote,
  fetchAccountProfiles,
  fetchEarningProfiles,
  startEarningAvailability,
  stopEarningAvailability,
  updateEarningProfile,
} from "@/src/api";
import { useAuth } from "@/src/AuthContext";
import { useProvider } from "@/src/ProviderContext";
import type { PlaceSelection } from "@/src/googlePlaces";
import { resolveTypedRomanianLocation } from "@/src/location";
import { serviceCategories } from "@/src/serviceCategories";
import { colors } from "@/src/theme";
import { analyzeWorkIntent } from "@/src/workIntent";
import { isValidRomanianTaxId, normalizeRomanianTaxId } from "@/src/romanianTaxId";
import { createCustomCapabilityId, customCapabilityLabel } from "@/src/customCapabilities";
import type {
  EarningProfile,
  AccountProfile,
  ProviderCapabilityLevel,
  ProviderEntityType,
  ProviderEquipmentId,
} from "@/src/types";
import { capabilityLevelOptions, equipmentOptions, providerEntityOptions } from "@/src/workProfile";

type CapabilityDraft = {
  categoryId: string;
  level: ProviderCapabilityLevel;
  hourlyRateLei: number | null;
  minimumPriceLei: number | null;
};
type AvailabilityHours = 1 | 2 | 4 | 8 | null;

const STEP_TITLES = [
  "Ce poți face?",
  "Cum vrei să lucrezi?",
  "Unde și când lucrezi?",
  "Cu ce profil lucrezi?",
  "Verifică și activează",
] as const;

function meaningfulPublicName(value: string | null | undefined) {
  const normalized = (value ?? "").trim().toLocaleLowerCase("ro-RO");
  return normalized === "utilizator nou" || normalized === "prestator nou" ? "" : (value ?? "");
}

export default function WorkProfileScreen() {
  const { provider, setProvider, status } = useAuth();
  const [step, setStep] = useState(0);
  const [profiles, setProfiles] = useState<EarningProfile[]>([]);
  const [legalProfiles, setLegalProfiles] = useState<AccountProfile[]>([]);
  const [selectedProfileId, setSelectedProfileId] = useState("");
  const [selectedAccountProfileId, setSelectedAccountProfileId] = useState("");
  const [creatingProfile, setCreatingProfile] = useState(false);
  const [capabilities, setCapabilities] = useState<CapabilityDraft[]>([]);
  const [equipment, setEquipment] = useState<ProviderEquipmentId[]>([]);
  const [baseHourlyRate, setBaseHourlyRate] = useState("");
  const [minimumHours, setMinimumHours] = useState(1);
  const [bio, setBio] = useState("");
  const [customSkill, setCustomSkill] = useState("");
  const [customSkillBusy, setCustomSkillBusy] = useState(false);
  const [customSkillFeedback, setCustomSkillFeedback] = useState("");
  const [availabilityHours, setAvailabilityHours] = useState<AvailabilityHours>(null);
  const [alwaysReceiveMatches, setAlwaysReceiveMatches] = useState(false);
  const [workCity, setWorkCity] = useState(provider?.city ?? "");
  const [workLatitude, setWorkLatitude] = useState<number | null>(provider?.latitude ?? null);
  const [workLongitude, setWorkLongitude] = useState<number | null>(provider?.longitude ?? null);
  const [radiusKm, setRadiusKm] = useState(provider?.radiusKm ?? 15);
  const [entityType, setEntityType] = useState<ProviderEntityType>("individual");
  const [profileLabel, setProfileLabel] = useState("Eu");
  const [publicName, setPublicName] = useState(meaningfulPublicName(provider?.name));
  const [legalName, setLegalName] = useState("");
  const [taxId, setTaxId] = useState("");
  const [loading, setLoading] = useState(Boolean(provider));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const { enableNotifications, notificationEnabled, setAvailabilityFor } = useProvider();

  const selectedProfile = useMemo(
    () => profiles.find((profile) => profile.id === selectedProfileId) ?? null,
    [profiles, selectedProfileId],
  );
  const meaningfulLegalProfiles = useMemo(
    () => legalProfiles.filter((profile) => profile.canManage && profile.profileType !== "organization" && meaningfulPublicName(profile.displayName).trim().length > 0),
    [legalProfiles],
  );

  function loadProfile(profile: EarningProfile) {
    setSelectedProfileId(profile.id);
    setSelectedAccountProfileId(profile.accountProfileId ?? "");
    setCreatingProfile(false);
    setCapabilities(profile.capabilities.map((item) => ({ ...item })));
    setEquipment(profile.equipment);
    setBaseHourlyRate(profile.baseHourlyRateLei === null ? "" : String(profile.baseHourlyRateLei));
    setMinimumHours(profile.minimumHours);
    setBio(profile.bio);
    setAlwaysReceiveMatches(profile.alerts.alwaysReceiveMatches);
    setWorkCity(profile.city);
    setWorkLatitude(profile.latitude ?? null);
    setWorkLongitude(profile.longitude ?? null);
    setRadiusKm(profile.radiusKm);
    setEntityType(profile.entityType);
    setProfileLabel(profile.label);
    setPublicName(meaningfulPublicName(profile.publicName));
    setLegalName(profile.legalName ?? "");
    setTaxId(profile.taxId ?? "");
    if (profile.availability) {
      const remaining = Math.max(0, Date.parse(profile.availability.endsAt) - Date.now());
      const roundedHours = Math.max(1, Math.round(remaining / 3_600_000));
      setAvailabilityHours(roundedHours <= 1 ? 1 : roundedHours <= 2 ? 2 : roundedHours <= 4 ? 4 : 8);
    } else setAvailabilityHours(null);
  }

  function selectLegalProfile(profile: AccountProfile) {
    const nextEntityType: ProviderEntityType = profile.profileType === "pfa"
      ? "pfa"
      : profile.profileType === "company"
        ? "company"
        : "individual";
    setSelectedAccountProfileId(profile.id);
    setEntityType(nextEntityType);
    setProfileLabel(profile.label);
    setPublicName(meaningfulPublicName(profile.displayName));
    setLegalName(profile.legalName ?? "");
    setTaxId(profile.taxId ?? "");
    if (selectedProfile?.accountProfileId !== profile.id) {
      setSelectedProfileId("");
      setCreatingProfile(true);
    } else {
      setCreatingProfile(false);
    }
  }

  useEffect(() => {
    if (!provider) return;
    let active = true;
    void Promise.all([fetchEarningProfiles(), fetchAccountProfiles()]).then(([{ profiles: rows }, { profiles: identities }]) => {
      if (!active) return;
      setProfiles(rows);
      setLegalProfiles(identities);
      const initial = rows.find((profile) => profile.canManage && profile.isActive)
        ?? rows.find((profile) => profile.canManage && profile.isDefault)
        ?? rows.find((profile) => profile.canManage)
        ?? rows.find((profile) => profile.isActive)
        ?? rows.find((profile) => profile.isDefault)
        ?? rows[0];
      if (initial) loadProfile(initial);
      else {
        setPublicName(meaningfulPublicName(provider.name));
        setWorkCity(provider.city);
        setWorkLatitude(provider.latitude ?? null);
        setWorkLongitude(provider.longitude ?? null);
        setRadiusKm(provider.radiusKm);
        setCapabilities((provider.categories ?? []).map((categoryId) => ({
          categoryId,
          level: "can_do",
          hourlyRateLei: null,
          minimumPriceLei: null,
        })));
      }
    }).catch((caught) => {
      if (active) setError(caught instanceof Error ? caught.message : "Profilurile nu au putut fi încărcate.");
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, [provider]);

  function startNewProfile() {
    setCreatingProfile(true);
    setSelectedProfileId("");
    setSelectedAccountProfileId("");
    setProfileLabel(entityType === "company" ? "Firma mea" : entityType === "pfa" ? "PFA-ul meu" : "Eu");
    setPublicName(meaningfulPublicName(provider?.name));
    setLegalName("");
    setTaxId("");
    setWorkCity(provider?.city ?? "");
    setWorkLatitude(provider?.latitude ?? null);
    setWorkLongitude(provider?.longitude ?? null);
    setRadiusKm(provider?.radiusKm ?? 15);
  }

  function toggleCapability(categoryId: string) {
    if (!capabilities.some((item) => item.categoryId === categoryId) && capabilities.length >= 10) {
      setError("Ai ajuns la 10 categorii. Elimină una sau creează un profil separat.");
      return;
    }
    setError("");
    setCapabilities((current) => {
      const existing = current.find((item) => item.categoryId === categoryId);
      if (existing) return current.filter((item) => item.categoryId !== categoryId);
      if (current.length >= 10) return current;
      return [...current, { categoryId, level: "can_do", hourlyRateLei: null, minimumPriceLei: null }];
    });
  }

  function setCapabilityLevel(categoryId: string, level: ProviderCapabilityLevel) {
    setCapabilities((current) => current.map((item) => item.categoryId === categoryId ? { ...item, level } : item));
  }

  function removeCapability(categoryId: string) {
    setCapabilities((current) => current.filter((item) => item.categoryId !== categoryId));
    setCustomSkillFeedback("");
  }

  async function addCustomSkill() {
    const skill = customSkill.trim().replace(/\s+/g, " ");
    setError("");
    setCustomSkillFeedback("");
    if (skill.length < 3) {
      setError("Scrie mai clar ce activitate poți face.");
      return;
    }

    setCustomSkillBusy(true);
    const localCategory = analyzeWorkIntent(skill).category;
    let suggestedCategory = localCategory;
    try {
      const analysis = await analyzeWorkIntentRemote({
        description: `Pot presta următoarea activitate: ${skill}`,
      });
      suggestedCategory = analysis.categoryId;
    } catch {
      // Clasificarea locală păstrează fluxul utilizabil și fără conexiune.
    } finally {
      setCustomSkillBusy(false);
    }

    const mappedCategory = serviceCategories.find((item) => item === suggestedCategory) ?? "Altele";
    const capabilityId = mappedCategory === "Altele" ? createCustomCapabilityId(skill) : mappedCategory;
    const alreadySelected = capabilities.some((item) => item.categoryId.toLocaleLowerCase("ro-RO") === capabilityId.toLocaleLowerCase("ro-RO"));
    if (!alreadySelected && capabilities.length >= 10) {
      setError("Poți urmări maximum 10 categorii. Elimină una înainte să adaugi alta.");
      return;
    }
    if (!alreadySelected) {
      setCapabilities((current) => [
        ...current,
        { categoryId: capabilityId, level: "can_do", hourlyRateLei: null, minimumPriceLei: null },
      ]);
    }

    setBio((current) => {
      if (current.toLocaleLowerCase("ro-RO").includes(skill.toLocaleLowerCase("ro-RO"))) return current;
      const detail = `Pot face: ${skill}.`;
      return `${current.trim()}${current.trim() ? "\n" : ""}${detail}`.slice(0, 500);
    });
    setCustomSkill("");
    setCustomSkillFeedback(
      mappedCategory === "Altele"
        ? `Am păstrat activitatea „${skill}”. Vei primi doar cereri „Altele” care au legătură cu această activitate.`
        : `Am păstrat „${skill}” și am încadrat alertele la „${mappedCategory}”. Poți schimba sau elimina categoria.`,
    );
    Keyboard.dismiss();
  }

  function toggleEquipment(equipmentId: ProviderEquipmentId) {
    setEquipment((current) => current.includes(equipmentId)
      ? current.filter((item) => item !== equipmentId)
      : [...current, equipmentId]);
  }

  function applyWorkLocation(place: PlaceSelection) {
    setWorkCity(place.areaLabel || place.fullLabel);
    setWorkLatitude(place.latitude);
    setWorkLongitude(place.longitude);
  }

  async function resolveWorkLocation() {
    if (workLatitude !== null && workLongitude !== null) {
      return { areaLabel: workCity.trim(), latitude: workLatitude, longitude: workLongitude };
    }
    const resolved = await resolveTypedRomanianLocation(workCity);
    if (!resolved || resolved.latitude === null || resolved.longitude === null) {
      setError("Alege zona din sugestii sau scrie o localitate pe care o putem găsi.");
      return null;
    }
    applyWorkLocation(resolved);
    return { areaLabel: resolved.areaLabel || resolved.fullLabel, latitude: resolved.latitude, longitude: resolved.longitude };
  }

  async function continueFlow() {
    Keyboard.dismiss();
    setError("");
    if (step === 0 && !capabilities.length) return setError("Alege cel puțin un tip de lucrare.");
    if (step === 0 && capabilities.some((capability) => capability.categoryId === "Altele")) {
      return setError("Profilul vechi conține „Altele”. Elimină această opțiune și scrie concret activitatea în câmpul de mai sus.");
    }
    if (step === 1) {
      const rate = baseHourlyRate.trim() ? Number(baseHourlyRate.replace(",", ".")) : null;
      if (rate !== null && (!Number.isFinite(rate) || rate < 20 || rate > 1_000)) {
        return setError("Tariful trebuie să fie între 20 și 1.000 lei/oră.");
      }
    }
    if (step === 2) {
      if (!(await resolveWorkLocation())) return;
      if (!availabilityHours && !alwaysReceiveMatches) {
        return setError("Alege o perioadă de disponibilitate sau alertele permanente.");
      }
    }
    if (step === 3) {
      if (profileLabel.trim().length < 1 || publicName.trim().length < 2) {
        return setError("Completează eticheta și numele public.");
      }
      if (entityType !== "individual" && (legalName.trim().length < 2 || taxId.trim().length < 2)) {
        return setError("Pentru PFA sau firmă completează denumirea legală și CUI/CIF.");
      }
      if (entityType !== "individual" && !isValidRomanianTaxId(taxId)) {
        return setError("CUI/CIF nu este valid. Verifică cifrele introduse.");
      }
    }
    setStep((current) => Math.min(4, current + 1));
  }

  async function submit() {
    if (!provider || status === "signedOut") {
      router.push({ pathname: "/sign-in", params: { returnTo: "/work-profile" } });
      return;
    }
    const rate = baseHourlyRate.trim() ? Number(baseHourlyRate.replace(",", ".")) : null;
    setBusy(true);
    setError("");
    try {
      const resolvedLocation = await resolveWorkLocation();
      if (!resolvedLocation) return;
      const payload = {
        accountProfileId: selectedAccountProfileId || undefined,
        label: profileLabel.trim(),
        entityType,
        publicName: publicName.trim(),
        legalName: entityType === "individual" ? null : legalName.trim(),
        taxId: entityType === "individual" ? null : normalizeRomanianTaxId(taxId),
        canInvoice: entityType !== "individual",
        city: resolvedLocation.areaLabel,
        latitude: resolvedLocation.latitude,
        longitude: resolvedLocation.longitude,
        radiusKm,
        baseHourlyRateLei: rate,
        minimumHours,
        bio: bio.trim(),
        isDefault: selectedProfile?.isDefault ?? !profiles.length,
        isActive: true,
        capabilities,
        equipment,
        alerts: {
          alwaysReceiveMatches,
          quietHoursStart: selectedProfile?.alerts.quietHoursStart ?? null,
          quietHoursEnd: selectedProfile?.alerts.quietHoursEnd ?? null,
          days: selectedProfile?.alerts.days ?? [1, 2, 3, 4, 5, 6, 7],
          urgentEnabled: selectedProfile?.alerts.urgentEnabled ?? true,
          dailyLimit: selectedProfile?.alerts.dailyLimit ?? null,
        },
      };
      const result = creatingProfile || !selectedProfileId
        ? await createEarningProfile(payload)
        : await updateEarningProfile(selectedProfileId, payload);
      setProfiles((current) => {
        const exists = current.some((profile) => profile.id === result.profile.id);
        return exists
          ? current.map((profile) => profile.id === result.profile.id ? result.profile : profile)
          : [result.profile, ...current];
      });
      setSelectedProfileId(result.profile.id);
      setCreatingProfile(false);
      if (availabilityHours) await startEarningAvailability(result.profile.id, availabilityHours);
      else await stopEarningAvailability(result.profile.id);
      let notificationsReady = notificationEnabled;
      let notificationFailureMessage = "";
      if (alwaysReceiveMatches && !notificationEnabled) {
        const activation = await enableNotifications();
        notificationsReady = activation.enabled;
        notificationFailureMessage = activation.message;
      }
      setProvider({
        ...provider,
        name: result.profile.publicName,
        categories: capabilities.map((item) => item.categoryId),
        city: resolvedLocation.areaLabel,
        latitude: resolvedLocation.latitude,
        longitude: resolvedLocation.longitude,
        radiusKm,
        professionalEnabled: true,
        professionalAvailable: Boolean(availabilityHours),
        professionalAvailableUntil: availabilityHours
          ? new Date(Date.now() + availabilityHours * 3_600_000).toISOString()
          : null,
        notificationEnabled: notificationsReady,
      });
      if (alwaysReceiveMatches && !notificationsReady) {
        setError(notificationFailureMessage || "Profilul a fost salvat, dar alertele nu sunt încă active.");
        return;
      }
      router.replace("/(tabs)/requests");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Profilul nu a putut fi activat.");
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color={colors.accent} /><Text style={styles.loadingText}>Pregătim opțiunile...</Text></SafeAreaView>;
  }

  if (!provider) {
    return (
      <SafeAreaView style={styles.center}>
        <MaterialCommunityIcons name="account-lock-outline" size={34} color={colors.mintDark} />
        <Text style={styles.signedOutTitle}>Intră în cont ca să primești lucrări</Text>
        <Text style={styles.signedOutText}>Numărul verificat protejează atât clienții, cât și persoanele care lucrează.</Text>
        <Pressable onPress={() => router.push({ pathname: "/sign-in", params: { returnTo: "/work-profile" } })} style={styles.signInButton}><Text style={styles.signInButtonText}>Continuă cu SMS</Text></Pressable>
      </SafeAreaView>
    );
  }

  async function activateSharedAvailability(hours: 1 | 2 | 4 | 8) {
    if (!selectedProfile) return;
    setBusy(true);
    setError("");
    try {
      await setAvailabilityFor(hours * 60, selectedProfile.id);
      router.replace("/(tabs)/requests");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Disponibilitatea nu a putut fi activată.");
    } finally {
      setBusy(false);
    }
  }

  if (selectedProfile?.canManage === false && !creatingProfile) {
    return (
      <SafeAreaView style={styles.center}>
        <ProfileSwitcher profiles={profiles} selectedId={selectedProfile.id} onSelect={loadProfile} />
        <MaterialCommunityIcons name="account-group-outline" size={38} color={colors.mintDark} />
        <Text style={styles.signedOutTitle}>{selectedProfile.publicName}</Text>
        <Text style={styles.signedOutText}>
          Acesta este un profil de firmă partajat cu tine. Îl poți folosi pentru lucrările potrivite, dar activitățile, tarifele și datele firmei sunt administrate de proprietarul profilului.
        </Text>
        <Text style={styles.sharedAvailabilityTitle}>Cât timp vrei să primești lucrări?</Text>
        <View style={styles.sharedAvailabilityGrid}>
          {([1, 2, 4, 8] as const).map((hours) => (
            <Pressable
              key={hours}
              disabled={busy}
              onPress={() => void activateSharedAvailability(hours)}
              style={({ pressed }) => [styles.sharedAvailabilityButton, (pressed || busy) && styles.pressed]}
            >
              <Text style={styles.sharedAvailabilityValue}>{hours}</Text>
              <Text style={styles.sharedAvailabilityUnit}>{hours === 1 ? "oră" : "ore"}</Text>
            </Pressable>
          ))}
        </View>
        {error ? <Text style={styles.error}>{error}</Text> : null}
        {selectedProfile.availability ? (
          <Pressable onPress={() => router.replace("/(tabs)/requests")} style={styles.signInButton}>
            <Text style={styles.signInButtonText}>Vezi lucrările potrivite</Text>
          </Pressable>
        ) : null}
        <Pressable onPress={startNewProfile} style={styles.sharedSecondaryButton}>
          <Text style={styles.sharedSecondaryText}>Creează propriul profil de lucru</Text>
        </Pressable>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={["bottom"]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 10 : 0}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}
          automaticallyAdjustKeyboardInsets={Platform.OS === "ios"}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.topRow}>
            <Pressable onPress={() => step ? setStep(step - 1) : router.back()} style={styles.back}><MaterialCommunityIcons name="arrow-left" size={21} color={colors.ink} /></Pressable>
            <Text style={styles.stepLabel}>PASUL {step + 1} DIN 5</Text>
          </View>
          <View style={styles.progress}>{STEP_TITLES.map((_, index) => <View key={index} style={[styles.progressItem, index <= step && styles.progressItemActive]} />)}</View>
          <Text style={styles.title}>{STEP_TITLES[step]}</Text>

          {step === 0 ? (
            <>
              {profiles.length > 1 ? (
                <ProfileSwitcher profiles={profiles} selectedId={selectedProfileId} onSelect={loadProfile} />
              ) : null}
              <Text style={styles.subtitle}>Scrie exact ce poți face. Îți propunem o categorie pentru alerte, iar tu o poți corecta.</Text>
              <View style={styles.customSkillBox}>
                <Text style={styles.customSkillLabel}>DESCRIE O ACTIVITATE</Text>
                <View style={styles.customSkillRow}>
                  <TextInput
                    value={customSkill}
                    onChangeText={setCustomSkill}
                    onSubmitEditing={() => void addCustomSkill()}
                    placeholder="Ex: repar biciclete sau montez decoruri"
                    placeholderTextColor="#77837C"
                    returnKeyType="done"
                    maxLength={80}
                    style={styles.customSkillInput}
                  />
                  <Pressable
                    disabled={customSkillBusy}
                    onPress={() => void addCustomSkill()}
                    style={({ pressed }) => [styles.customSkillButton, (pressed || customSkillBusy) && styles.pressed]}
                  >
                    {customSkillBusy
                      ? <ActivityIndicator size="small" color={colors.paper} />
                      : <MaterialCommunityIcons name="arrow-right" size={21} color={colors.paper} />}
                  </Pressable>
                </View>
                <Text style={styles.customSkillHint}>Poți adăuga pe rând activități foarte diferite. Formularea ta rămâne în descrierea profilului.</Text>
                {customSkillFeedback ? <Text style={styles.customSkillFeedback}>{customSkillFeedback}</Text> : null}
              </View>

              <Text style={styles.quickCategoryLabel}>SAU ALEGE RAPID CATEGORIILE PENTRU ALERTE</Text>
              <View style={styles.chips}>
                {serviceCategories.filter((category) => category !== "Altele").map((category) => {
                  const active = capabilities.some((item) => item.categoryId === category);
                  return (
                    <Pressable key={category} onPress={() => toggleCapability(category)} style={[styles.chip, active && styles.chipActive]}>
                      <MaterialCommunityIcons name={active ? "check" : "plus"} size={15} color={active ? colors.paper : colors.ink} />
                      <Text style={[styles.chipText, active && styles.chipTextActive]}>{category}</Text>
                    </Pressable>
                  );
                })}
              </View>
              <Text style={styles.count}>{capabilities.length}/10 selectate</Text>
              {capabilities.some((capability) => capability.categoryId === "Altele") ? (
                <Text style={styles.legacyCapabilityWarning}>Descrie activitatea concret ca să primești lucrări potrivite.</Text>
              ) : null}
              {capabilities.map((capability) => (
                <View key={capability.categoryId} style={styles.capability}>
                  <View style={styles.capabilityHeader}>
                    <Text style={styles.capabilityTitle}>{customCapabilityLabel(capability.categoryId) ?? capability.categoryId}</Text>
                    <Pressable
                      accessibilityLabel={`Elimină ${customCapabilityLabel(capability.categoryId) ?? capability.categoryId}`}
                      hitSlop={10}
                      onPress={() => removeCapability(capability.categoryId)}
                      style={styles.capabilityRemove}
                    >
                      <MaterialCommunityIcons name="close" size={18} color={colors.muted} />
                    </Pressable>
                  </View>
                  <View style={styles.levels}>
                    {capabilityLevelOptions.map((level) => (
                      <Pressable key={level.value} onPress={() => setCapabilityLevel(capability.categoryId, level.value)} style={[styles.level, capability.level === level.value && styles.levelActive]}>
                        <Text style={[styles.levelText, capability.level === level.value && styles.levelTextActive]}>{level.label}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
              ))}
            </>
          ) : null}

          {step === 1 ? (
            <>
              <Text style={styles.subtitle}>Tariful este orientativ. Prețul final rămâne în oferta pe care o trimiți.</Text>
              <Text style={styles.fieldLabel}>Tarif de bază</Text>
              <View style={styles.rateInput}>
                <TextInput value={baseHourlyRate} onChangeText={setBaseHourlyRate} keyboardType="decimal-pad" placeholder="Ex: 50" placeholderTextColor="#99A19A" style={styles.rateText} />
                <Text style={styles.rateUnit}>LEI / ORĂ</Text>
              </View>
              <Text style={styles.fieldLabel}>Durată minimă</Text>
              <View style={styles.minimumOptions}>
                {[1, 2, 3, 4].map((hours) => (
                  <Pressable key={hours} onPress={() => setMinimumHours(hours)} style={[styles.minimum, minimumHours === hours && styles.minimumActive]}>
                    <Text style={[styles.minimumText, minimumHours === hours && styles.minimumTextActive]}>{hours} {hours === 1 ? "oră" : "ore"}</Text>
                  </Pressable>
                ))}
              </View>
              <Text style={styles.fieldLabel}>Ce ai la dispoziție?</Text>
              <View style={styles.equipmentGrid}>
                {equipmentOptions.map((option) => {
                  const active = equipment.includes(option.value);
                  return (
                    <Pressable key={option.value} onPress={() => toggleEquipment(option.value)} style={[styles.equipment, active && styles.equipmentActive]}>
                      <MaterialCommunityIcons name={option.icon as never} size={20} color={active ? colors.paper : colors.ink} />
                      <Text style={[styles.equipmentText, active && styles.equipmentTextActive]}>{option.label}</Text>
                    </Pressable>
                  );
                })}
              </View>
              <Text style={styles.fieldLabel}>Despre experiența ta (opțional)</Text>
              <TextInput value={bio} onChangeText={setBio} multiline maxLength={500} numberOfLines={4} textAlignVertical="top" placeholder="Ex: Lucrez de 5 ani în montaj mobilier." placeholderTextColor="#99A19A" style={styles.bio} />
            </>
          ) : null}

          {step === 2 ? (
            <>
              <Text style={styles.subtitle}>Alegem lucrările după distanța reală față de zona ta, nu doar după numele orașului.</Text>
              <Text style={styles.sectionTitle}>ZONA DE PORNIRE</Text>
              <CityAutocompleteInput
                value={workCity}
                purpose="area"
                placeholder="Oraș, sector, comună sau cartier"
                onChangeText={(value) => {
                  setWorkCity(value);
                  setWorkLatitude(null);
                  setWorkLongitude(null);
                }}
                onSelectPlace={applyWorkLocation}
              />
              <Text style={styles.locationHint}>Adresa ta exactă nu este afișată clienților. Zona este folosită numai pentru calculul distanței.</Text>
              <Text style={styles.sectionTitle}>CÂT DE DEPARTE TE DEPLASEZI?</Text>
              <View style={styles.radiusGrid}>
                {[5, 10, 20, 50].map((distance) => (
                  <Pressable key={distance} onPress={() => setRadiusKm(distance)} style={[styles.radius, radiusKm === distance && styles.radiusActive]}>
                    <Text style={[styles.radiusText, radiusKm === distance && styles.radiusTextActive]}>{distance} km</Text>
                  </Pressable>
                ))}
              </View>
              <Text style={styles.sectionTitle}>SUNT DISPONIBIL ACUM</Text>
              <View style={styles.availabilityGrid}>
                {([1, 2, 4, 8] as const).map((hours) => (
                  <Pressable key={hours} onPress={() => setAvailabilityHours(hours)} style={[styles.availability, availabilityHours === hours && styles.availabilityActive]}>
                    <Text style={[styles.availabilityValue, availabilityHours === hours && styles.availabilityValueActive]}>{hours}</Text>
                    <Text style={[styles.availabilityUnit, availabilityHours === hours && styles.availabilityValueActive]}>{hours === 1 ? "oră" : "ore"}</Text>
                  </Pressable>
                ))}
              </View>
              <Pressable onPress={() => setAvailabilityHours(null)} style={styles.notNow}><MaterialCommunityIcons name={availabilityHours === null ? "radiobox-marked" : "radiobox-blank"} size={19} color={colors.muted} /><Text style={styles.notNowText}>Nu sunt disponibil chiar acum</Text></Pressable>
              <Text style={styles.sectionTitle}>ALERTE PE TERMEN LUNG</Text>
              <Pressable onPress={() => setAlwaysReceiveMatches((current) => !current)} style={[styles.permanentAlerts, alwaysReceiveMatches && styles.permanentAlertsActive]}>
                <View style={[styles.alertIcon, alwaysReceiveMatches && styles.alertIconActive]}><MaterialCommunityIcons name="bell-ring-outline" size={23} color={alwaysReceiveMatches ? colors.paper : colors.ink} /></View>
                <View style={styles.alertCopy}><Text style={styles.alertTitle}>Primesc permanent lucrări potrivite</Text><Text style={styles.alertText}>Primești sugestii potrivite, fără să apari ca disponibil fizic non-stop.</Text></View>
                <MaterialCommunityIcons name={alwaysReceiveMatches ? "check-circle" : "circle-outline"} size={23} color={alwaysReceiveMatches ? colors.mintDark : colors.muted} />
              </Pressable>
            </>
          ) : null}

          {step === 3 ? (
            <>
              <Text style={styles.subtitle}>Alege identitatea cu care vei presta. Competențele și tariful rămân cele completate mai sus.</Text>
              {meaningfulLegalProfiles.length ? (
                <View style={styles.profileList}>
                  {meaningfulLegalProfiles.map((profile) => (
                    <Pressable key={profile.id} onPress={() => selectLegalProfile(profile)} style={[styles.profileCard, selectedAccountProfileId === profile.id && styles.profileCardActive]}>
                      <View style={styles.profileCardCopy}>
                        <Text style={styles.profileCardTitle}>{profile.label}</Text>
                        <Text style={styles.profileCardText}>{profile.displayName} · {profile.profileType === "person" ? "persoană fizică" : profile.profileType.toUpperCase()}</Text>
                        <Text style={styles.profileCardText}>{profile.providerReviewCount ? `★ ${(profile.providerRating / 10).toFixed(1).replace(".", ",")} · ${profile.providerReviewCount} evaluări` : "Profil nou, fără evaluări"} · {profile.providerCompletedJobs} lucrări</Text>
                      </View>
                      <MaterialCommunityIcons name={selectedAccountProfileId === profile.id ? "check-circle" : "circle-outline"} size={22} color={selectedAccountProfileId === profile.id ? colors.mintDark : colors.muted} />
                    </Pressable>
                  ))}
                  <Pressable onPress={startNewProfile} style={styles.newProfile}><MaterialCommunityIcons name="plus" size={18} color={colors.ink} /><Text style={styles.newProfileText}>Adaugă alt profil</Text></Pressable>
                </View>
              ) : null}
              {creatingProfile ? (
                <Text style={styles.identityHint}>
                  {selectedAccountProfileId
                    ? "Configurezi activitățile pentru profilul existent. Evaluările primite ca prestator vor rămâne separate de evaluările primite ca client."
                    : "Creezi un profil nou. Activitățile și tariful completate anterior vor fi folosite pentru acest profil de lucru."}
                </Text>
              ) : null}
              <Text style={styles.fieldLabel}>Forma în care lucrezi</Text>
              <View style={styles.entityList}>
                {providerEntityOptions.map((option) => (
                  <Pressable key={option.value} onPress={() => {
                    if (selectedAccountProfileId) {
                      setSelectedAccountProfileId("");
                      setSelectedProfileId("");
                      setCreatingProfile(true);
                    }
                    setEntityType(option.value);
                  }} style={[styles.entity, entityType === option.value && styles.entityActive]}>
                    <View style={[styles.radio, entityType === option.value && styles.radioActive]}>{entityType === option.value ? <View style={styles.radioDot} /> : null}</View>
                    <View style={styles.entityCopy}><Text style={styles.entityTitle}>{option.label}</Text><Text style={styles.entityText}>{option.description}</Text></View>
                  </Pressable>
                ))}
              </View>
              <TextInput value={profileLabel} onChangeText={setProfileLabel} placeholder="Etichetă: Eu, PFA-ul meu..." placeholderTextColor="#99A19A" style={styles.input} />
              <TextInput value={publicName} onChangeText={setPublicName} placeholder="Numele afișat clienților" placeholderTextColor="#99A19A" style={styles.input} />
              {entityType !== "individual" ? (
                <>
                  <TextInput value={legalName} onChangeText={setLegalName} placeholder="Denumirea legală" placeholderTextColor="#99A19A" style={styles.input} />
                  <TextInput value={taxId} onChangeText={setTaxId} placeholder="CUI / CIF" autoCapitalize="characters" placeholderTextColor="#99A19A" style={styles.input} />
                  <View style={styles.verificationNote}><MaterialCommunityIcons name="shield-check-outline" size={18} color="#725814" /><Text style={styles.verificationText}>Datele firmei trebuie verificate înainte să primești lucrări care cer factură.</Text></View>
                </>
              ) : (
                <View style={styles.verificationNote}><MaterialCommunityIcons name="information-outline" size={18} color="#725814" /><Text style={styles.verificationText}>Persoana fizică nu este prezentată ca emitent de factură. Unele categorii pot necesita PFA, firmă sau autorizații.</Text></View>
              )}
            </>
          ) : null}

          {step === 4 ? (
            <>
              <Text style={styles.subtitle}>Așa vei primi cereri potrivite.</Text>
              <View style={styles.summary}>
                <SummaryRow label="Lucrări" value={`${capabilities.length} competențe`} />
                <SummaryRow label="Tarif" value={baseHourlyRate ? `${baseHourlyRate} lei/oră` : "Stabilesc prin ofertă"} />
                <SummaryRow label="Zonă" value={`${workCity} · ${radiusKm} km`} />
                <SummaryRow label="Acum" value={availabilityHours ? `${availabilityHours} ${availabilityHours === 1 ? "oră" : "ore"}` : "Indisponibil"} />
                <SummaryRow label="Alerte" value={alwaysReceiveMatches ? "Permanente, pentru potriviri" : "Doar când sunt disponibil"} />
                <SummaryRow label="Profil" value={`${profileLabel} · ${entityType === "individual" ? "persoană fizică" : entityType.toUpperCase()}`} />
                <SummaryRow label="Factură" value={entityType === "individual" ? "Nu" : "După verificare"} />
              </View>
              <View style={styles.activationNote}><MaterialCommunityIcons name="shield-check-outline" size={20} color={colors.mintDark} /><Text style={styles.activationText}>Pentru lucrările care cer autorizații, trebuie să le poți dovedi separat.</Text></View>
            </>
          ) : null}
        </ScrollView>

        <View style={styles.footer}>
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={step === 4 ? "Activează și arată-mi lucrări" : "Continuă"}
            disabled={busy}
            onPress={() => void (step === 4 ? submit() : continueFlow())}
            style={({ pressed }) => [styles.primary, (pressed || busy) && styles.pressed]}
          >
            <Text style={styles.primaryText}>{busy ? "Se activează..." : step === 4 ? "Activează și arată-mi lucrări" : "Continuă"}</Text>
            <MaterialCommunityIcons name={step === 4 ? "check" : "arrow-right"} size={21} color={colors.paper} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return <View style={styles.summaryRow}><Text style={styles.summaryLabel}>{label}</Text><Text style={styles.summaryValue}>{value}</Text></View>;
}

function ProfileSwitcher({ profiles, selectedId, onSelect }: { profiles: EarningProfile[]; selectedId: string; onSelect: (profile: EarningProfile) => void }) {
  if (profiles.length < 2) return null;
  return (
    <View style={styles.profileSwitcher}>
      <Text style={styles.profileSwitcherLabel}>PROFILUL CU CARE VREI SĂ LUCREZI</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.profileSwitcherList}>
        {profiles.map((profile) => {
          const active = profile.id === selectedId;
          return (
            <Pressable key={profile.id} onPress={() => onSelect(profile)} style={[styles.profileSwitcherButton, active && styles.profileSwitcherButtonActive]}>
              <Text style={[styles.profileSwitcherTitle, active && styles.profileSwitcherTitleActive]}>{profile.label}</Text>
              <Text style={[styles.profileSwitcherMeta, active && styles.profileSwitcherMetaActive]}>{profile.canManage === false ? "Profil partajat" : "Profil propriu"}</Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.cream },
  flex: { flex: 1 },
  center: { flex: 1, paddingHorizontal: 28, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center" },
  loadingText: { color: colors.muted, fontSize: 12, marginTop: 10 },
  signedOutTitle: { color: colors.ink, fontSize: 21, lineHeight: 27, fontWeight: "900", textAlign: "center", marginTop: 15 },
  signedOutText: { color: colors.muted, fontSize: 13, lineHeight: 19, textAlign: "center", marginTop: 7 },
  signInButton: { minHeight: 52, paddingHorizontal: 24, backgroundColor: colors.accent, borderRadius: 15, alignItems: "center", justifyContent: "center", marginTop: 20 },
  signInButtonText: { color: colors.paper, fontSize: 13, fontWeight: "900" },
  sharedSecondaryButton: { minHeight: 48, paddingHorizontal: 20, alignItems: "center", justifyContent: "center", marginTop: 8 },
  sharedSecondaryText: { color: colors.ink, fontSize: 13, fontWeight: "800", textDecorationLine: "underline" },
  sharedAvailabilityTitle: { color: colors.ink, fontSize: 14, fontWeight: "900", marginTop: 20, marginBottom: 10 },
  sharedAvailabilityGrid: { width: "100%", maxWidth: 420, flexDirection: "row", gap: 8 },
  sharedAvailabilityButton: { minHeight: 72, flex: 1, borderRadius: 14, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  sharedAvailabilityValue: { color: colors.ink, fontSize: 20, fontWeight: "900" },
  sharedAvailabilityUnit: { color: colors.muted, fontSize: 12, fontWeight: "700", marginTop: 1 },
  profileSwitcher: { width: "100%", marginBottom: 18 },
  profileSwitcherLabel: { color: colors.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.6, marginBottom: 8 },
  profileSwitcherList: { gap: 8, paddingRight: 8 },
  profileSwitcherButton: { minHeight: 56, minWidth: 125, paddingHorizontal: 13, paddingVertical: 9, borderRadius: 13, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, justifyContent: "center" },
  profileSwitcherButtonActive: { backgroundColor: colors.ink, borderColor: colors.ink },
  profileSwitcherTitle: { color: colors.ink, fontSize: 13, fontWeight: "900" },
  profileSwitcherTitleActive: { color: colors.paper },
  profileSwitcherMeta: { color: colors.muted, fontSize: 12, marginTop: 2 },
  profileSwitcherMetaActive: { color: "#D5DDD7" },
  content: { width: "100%", maxWidth: 560, alignSelf: "center", paddingHorizontal: 20, paddingTop: 12, paddingBottom: 28, flexGrow: 1 },
  topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  back: { width: 44, height: 44, borderRadius: 12, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  stepLabel: { color: colors.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.7 },
  progress: { flexDirection: "row", gap: 6, marginTop: 14 },
  progressItem: { flex: 1, height: 4, borderRadius: 2, backgroundColor: colors.line },
  progressItemActive: { backgroundColor: "#347DB5" },
  title: { color: colors.ink, fontSize: 30, lineHeight: 36, fontWeight: "900", letterSpacing: -0.9, marginTop: 29 },
  subtitle: { color: colors.muted, fontSize: 14, lineHeight: 21, marginTop: 8, marginBottom: 23 },
  customSkillBox: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 17, padding: 14 },
  customSkillLabel: { color: colors.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.7, marginBottom: 9 },
  customSkillRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  customSkillInput: { flex: 1, minHeight: 52, borderRadius: 13, backgroundColor: colors.cream, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 13, color: colors.ink, fontSize: 15 },
  customSkillButton: { width: 52, height: 52, borderRadius: 13, backgroundColor: "#174E7A", alignItems: "center", justifyContent: "center" },
  customSkillHint: { color: colors.muted, fontSize: 13, lineHeight: 19, marginTop: 9 },
  customSkillFeedback: { color: colors.mintDark, backgroundColor: colors.mint, borderRadius: 11, padding: 10, fontSize: 13, lineHeight: 19, fontWeight: "700", marginTop: 10 },
  quickCategoryLabel: { color: colors.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.6, marginTop: 24, marginBottom: 10 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 99, paddingHorizontal: 12, paddingVertical: 10 },
  chipActive: { backgroundColor: "#174E7A", borderColor: "#174E7A" },
  chipText: { color: colors.ink, fontSize: 12, fontWeight: "800" },
  chipTextActive: { color: colors.paper },
  count: { color: colors.muted, fontSize: 12, textAlign: "right", marginTop: 8, marginBottom: 13 },
  legacyCapabilityWarning: { color: "#725814", backgroundColor: "#FFF2CE", borderRadius: 11, padding: 11, fontSize: 13, lineHeight: 19, fontWeight: "700", marginBottom: 12 },
  capability: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 14, padding: 12, marginBottom: 8 },
  capabilityHeader: { minHeight: 30, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, marginBottom: 8 },
  capabilityTitle: { flex: 1, color: colors.ink, fontSize: 14, fontWeight: "900" },
  capabilityRemove: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: colors.cream },
  levels: { flexDirection: "row", gap: 6 },
  level: { flex: 1, minHeight: 44, borderRadius: 9, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center", paddingHorizontal: 3 },
  levelActive: { backgroundColor: "#E3F0F9" },
  levelText: { color: colors.muted, fontSize: 12, fontWeight: "800", textAlign: "center" },
  levelTextActive: { color: "#174E7A" },
  fieldLabel: { color: colors.ink, fontSize: 13, fontWeight: "900", marginTop: 18, marginBottom: 9 },
  rateInput: { height: 58, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 14, flexDirection: "row", alignItems: "center", paddingHorizontal: 14 },
  rateText: { flex: 1, color: colors.ink, fontSize: 19, fontWeight: "800" },
  rateUnit: { color: colors.muted, fontSize: 12, fontWeight: "900" },
  minimumOptions: { flexDirection: "row", gap: 7 },
  minimum: { flex: 1, minHeight: 44, borderRadius: 11, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  minimumActive: { backgroundColor: "#174E7A", borderColor: "#174E7A" },
  minimumText: { color: colors.muted, fontSize: 12, fontWeight: "800" },
  minimumTextActive: { color: colors.paper },
  equipmentGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  equipment: { width: "48%", minHeight: 72, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 13, padding: 11, justifyContent: "space-between" },
  equipmentActive: { backgroundColor: "#174E7A", borderColor: "#174E7A" },
  equipmentText: { color: colors.ink, fontSize: 12, fontWeight: "800", marginTop: 7 },
  equipmentTextActive: { color: colors.paper },
  bio: { minHeight: 102, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 13, padding: 12, color: colors.ink, fontSize: 14 },
  sectionTitle: { color: colors.muted, fontSize: 12, fontWeight: "900", letterSpacing: 0.7, marginTop: 14, marginBottom: 10 },
  locationHint: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 8 },
  radiusGrid: { flexDirection: "row", gap: 8 },
  radius: { flex: 1, minHeight: 44, borderRadius: 11, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  radiusActive: { backgroundColor: "#174E7A", borderColor: "#174E7A" },
  radiusText: { color: colors.muted, fontSize: 12, fontWeight: "900" },
  radiusTextActive: { color: colors.paper },
  availabilityGrid: { flexDirection: "row", gap: 8 },
  availability: { flex: 1, minHeight: 83, borderRadius: 15, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, alignItems: "center", justifyContent: "center" },
  availabilityActive: { backgroundColor: "#174E7A", borderColor: "#174E7A" },
  availabilityValue: { color: colors.ink, fontSize: 23, fontWeight: "900" },
  availabilityUnit: { color: colors.muted, fontSize: 12, fontWeight: "700", marginTop: 2 },
  availabilityValueActive: { color: colors.paper },
  notNow: { minHeight: 47, flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 4 },
  notNowText: { color: colors.muted, fontSize: 13, fontWeight: "700" },
  permanentAlerts: { minHeight: 92, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 17, padding: 13, flexDirection: "row", alignItems: "center", gap: 11 },
  permanentAlertsActive: { backgroundColor: "#E7F2FC", borderColor: "#94BFE0" },
  alertIcon: { width: 43, height: 43, borderRadius: 13, backgroundColor: colors.cream, alignItems: "center", justifyContent: "center" },
  alertIconActive: { backgroundColor: "#174E7A" },
  alertCopy: { flex: 1 },
  alertTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" },
  alertText: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 4 },
  profileList: { gap: 8, marginBottom: 7 },
  profileCard: { minHeight: 65, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 14, paddingHorizontal: 13, flexDirection: "row", alignItems: "center", gap: 10 },
  profileCardActive: { borderColor: "#347DB5", backgroundColor: "#EEF6FC" },
  profileCardCopy: { flex: 1 },
  profileCardTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" },
  profileCardText: { color: colors.muted, fontSize: 12, marginTop: 3 },
  newProfile: { minHeight: 46, borderWidth: 1, borderColor: colors.line, borderStyle: "dashed", borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  newProfileText: { color: colors.ink, fontSize: 13, fontWeight: "800" },
  identityHint: { color: colors.muted, backgroundColor: colors.paper, borderRadius: 12, padding: 11, fontSize: 13, lineHeight: 19, marginBottom: 8 },
  useExistingProfile: { minHeight: 44, alignItems: "center", justifyContent: "center", marginBottom: 8 },
  useExistingProfileText: { color: "#174E7A", fontSize: 13, fontWeight: "800" },
  entityList: { gap: 8 },
  entity: { minHeight: 65, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 14, padding: 12, flexDirection: "row", alignItems: "center", gap: 11 },
  entityActive: { borderColor: "#347DB5", backgroundColor: "#EEF6FC" },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: "#AEB5AF", alignItems: "center", justifyContent: "center" },
  radioActive: { borderColor: "#174E7A" },
  radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#174E7A" },
  entityCopy: { flex: 1 },
  entityTitle: { color: colors.ink, fontSize: 14, fontWeight: "900" },
  entityText: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 3 },
  input: { minHeight: 52, backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 13, paddingHorizontal: 13, color: colors.ink, fontSize: 13, marginTop: 9 },
  verificationNote: { backgroundColor: "#FFF2CE", borderRadius: 12, padding: 11, flexDirection: "row", gap: 8, marginTop: 10 },
  verificationText: { color: "#725814", fontSize: 12, lineHeight: 18, flex: 1 },
  summary: { backgroundColor: colors.paper, borderWidth: 1, borderColor: colors.line, borderRadius: 18, paddingHorizontal: 16 },
  summaryRow: { minHeight: 57, flexDirection: "row", alignItems: "center", gap: 12, borderBottomWidth: 1, borderBottomColor: colors.line },
  summaryLabel: { width: 72, color: colors.muted, fontSize: 12, fontWeight: "800" },
  summaryValue: { flex: 1, color: colors.ink, fontSize: 14, lineHeight: 19, fontWeight: "700", textAlign: "right" },
  activationNote: { backgroundColor: colors.mint, borderRadius: 14, padding: 13, flexDirection: "row", gap: 9, marginTop: 16 },
  activationText: { flex: 1, color: colors.mintDark, fontSize: 12, lineHeight: 18 },
  footer: { width: "100%", maxWidth: 560, alignSelf: "center", paddingHorizontal: 20, paddingTop: 10, paddingBottom: 14, backgroundColor: colors.cream, borderTopWidth: 1, borderTopColor: colors.line },
  error: { color: colors.accentDark, backgroundColor: colors.dangerSoft, borderRadius: 11, padding: 10, fontSize: 12, lineHeight: 18, fontWeight: "700", marginBottom: 9 },
  primary: { minHeight: 57, backgroundColor: "#174E7A", borderRadius: 15, paddingHorizontal: 17, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  primaryText: { color: colors.paper, fontSize: 15, fontWeight: "900" },
  pressed: { opacity: 0.76 },
});
