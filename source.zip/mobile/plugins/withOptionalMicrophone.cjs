/* eslint-disable @typescript-eslint/no-require-imports -- Expo loads local config plugins as CommonJS in this ESM project. */
const { withAndroidManifest } = require('expo/config-plugins');

const MICROPHONE_FEATURE = 'android.hardware.microphone';

function setOptionalMicrophone(manifest) {
  const features = manifest['uses-feature'] || [];
  const microphone = features.find(
    (feature) => feature.$?.['android:name'] === MICROPHONE_FEATURE
  );

  if (microphone) {
    microphone.$['android:required'] = 'false';
  } else {
    features.push({
      $: {
        'android:name': MICROPHONE_FEATURE,
        'android:required': 'false',
      },
    });
  }

  manifest['uses-feature'] = features;
  return manifest;
}

const withOptionalMicrophone = (config) =>
  withAndroidManifest(config, (config) => {
    config.modResults.manifest = setOptionalMicrophone(config.modResults.manifest);
    return config;
  });

module.exports = withOptionalMicrophone;
module.exports.setOptionalMicrophone = setOptionalMicrophone;
