# RezolvatAzi Pro

Provider-first Expo app for receiving urgent local requests and sending price + arrival-time offers.

## Run

```powershell
cd mobile
npm install
npm run start
```

Development builds can use isolated demo fixtures, but distributable builds default to the public RezolvatAzi API and never merge demo requests into live feeds. Copy `.env.example` to `.env.local` only when you need to point a local development build at a different API.

Phone sign-in, onboarding, authenticated offers, persisted availability and push-token registration all require a reachable API. Demo requests cannot receive real offers.

Native sessions are stored with Expo SecureStore. Push registration requires a physical-device native build and an EAS project ID before tokens can be issued.

## Installable Android preview

Sign into your own Expo account locally, connect the app to an EAS project, then start the APK build:

```powershell
cd mobile
npm run eas:login
npx eas-cli@21.0.2 init
npm run build:android:preview
```

The `preview` profile produces an installable APK. The first `eas init` writes the Expo project ID into the app configuration; that ID is also used when registering device push tokens. Do not paste Expo, Google or Twilio credentials into chat or commit them to Git.

Both cloud build profiles point to the hosted RezolvatAzi API. That deployment must be public before an installed app can reach it.

For a Play Store build, use `npm run build:android:production`. That profile produces the store artifact and increments the Android version code.

## Local authentication

Copy the root `.dev.vars.example` to `.dev.vars`, set a development session pepper and keep `AUTH_DEV_OTP_CODE` local-only. The bypass works only for localhost/private-network requests. Public hosts always require Twilio Verify credentials.

Production secrets required by the API:

- `SESSION_PEPPER`
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_VERIFY_SERVICE_SID`
- `ADMIN_API_TOKEN` for manual provider approval
- `PUSH_RECEIPT_SECRET` for the protected push-receipt checker
- `GOOGLE_MAPS_API_KEY` with Places API (New) and Geocoding API enabled; it stays on the API server and powers Romanian address suggestions

When a customer publishes a request, the API matches verified, available providers by category and service area, then sends Expo push notifications. Configure a scheduled call to `POST /api/internal/push-receipts` roughly 15 minutes after dispatch so invalid device tokens are disabled based on Expo receipts.
